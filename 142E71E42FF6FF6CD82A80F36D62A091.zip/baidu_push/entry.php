<?php
if(!defined('IN_ROOT')){exit('Access denied');}
include 'source/plugin/baidu_push/config.php';
include 'source/admincp/include/function.php';
Administrator(1);
@set_time_limit(0);
ini_set('memory_limit', '-1');
?>
<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=<?php echo IN_CHARSET; ?>" />
<meta http-equiv="x-ua-compatible" content="ie=7" />
<title>百度主动推送</title>
<link href="<?php echo IN_PATH; ?>static/admincp/css/main.css" rel="stylesheet" type="text/css" />
<script type="text/javascript">
function baidu_pushing(type, sizes, num, size, nums, success){
        var percent = Math.round(nums * 100 / num);
        document.getElementById("status").innerHTML = sizes + "/" + size;
        document.getElementById("success").innerHTML = success;
        document.getElementById("num").innerHTML = num;
        document.getElementById("progressbar").style.width = percent + "%";
        if(percent > 0){
                document.getElementById("progressbar").innerHTML = percent + "%";
                document.getElementById("progressText").innerHTML = "";
        }
        if(sizes < size){
                location.href = '<?php echo $_SERVER['PHP_SELF']; ?>?type=' + type + '&sizes=' + (Number(sizes) + 1) + '&nums=' + nums + '&success=' + success;
        }
}
</script>
</head>
<body>
<?php
        global $db;
        $type = SafeRequest("type","get");
        $sizes = isset($_GET['sizes']) ? SafeRequest("sizes","get") : 1;
        if($type == 1){
                $text = '专辑';
                $table = 'special';
        }elseif($type == 2){
                $text = '歌手';
                $table = 'singer';
        }elseif($type == 3){
                $text = '视频';
                $table = 'video';
        }else{
                $text = '音乐';
                $table = 'music';
        }
        echo "<div class=\"container\"><h3>Ear Music 提示</h3><div class=\"infobox\"><br />";
        echo "<table class=\"tb tb2\" style=\"border:1px solid #09C\">";
        echo "<tr><td>分批状态</td><td><div id=\"status\">0/0</div></td></tr>";
        echo "<tr><td>成功推送</td><td><div id=\"success\">0</div></td></tr>";
        echo "<tr><td>{$text}链接</td><td><div id=\"num\">0</div></td></tr>";
        echo "<tr><td>推送进度</td><td><div id=\"progressbar\" style=\"float:left;width:1px;text-align:center;color:#FFFFFF;background-color:#09C\"></div><div id=\"progressText\" style=\"float:left\">0%</div></td></tr>";
        echo "</table>";
        echo "<br /><p class=\"margintop\"><input type=\"button\" class=\"btn\" value=\"撤销\" onclick=\"history.go(-1);\"></p><br /></div></div>";
        $sql = "select * from ".tname($table);
        $info = $db->query($sql);
        $num = $db->num_rows($db->query(str_replace('*', 'count(*)', $sql)));
        $size = $num > in_plugin_baidu_push_size ? ceil($num / in_plugin_baidu_push_size) : 1;
        if($size > 1){
                $info = $db->query("select * from ".tname($table)." LIMIT ".(($sizes - 1) * in_plugin_baidu_push_size).",".in_plugin_baidu_push_size);
        }
        $nums = isset($_GET['nums']) ? SafeRequest("nums","get") : 0;
        $links = "";
        while($row = $db->fetch_array($info)){
                $nums = $nums + 1;
                $links .= "http://".$_SERVER['HTTP_HOST'].getlink($row['in_id'], $table)."|";
        }
        $links = str_replace('|]', '', $links.']');
        $urls = preg_split('/\|/', $links);
        $api = 'http://data.zz.baidu.com/urls?site='.$_SERVER['HTTP_HOST'].'&token='.in_plugin_baidu_push_token;
        $ch = curl_init();
        $options = array(
                CURLOPT_URL => $api,
                CURLOPT_POST => true,
                CURLOPT_RETURNTRANSFER => true,
                CURLOPT_POSTFIELDS => implode("\n", $urls),
                CURLOPT_HTTPHEADER => array('Content-Type:text/plain')
        );
        curl_setopt_array($ch, $options);
        $result = curl_exec($ch);
        $success = isset($_GET['success']) ? SafeRequest("success","get") : 0;
        preg_match('/\{"remain":1,"success":(\d+)\}/', $result, $array);
        $success = !empty($array) ? ($success + $array[1]) : $success;
        echo "<script type=\"text/javascript\">baidu_pushing($type, $sizes, $num, $size, $nums, $success);</script>";
?>
</body>
</html>