<?php
if(!defined('IN_ROOT')){exit('Access denied');}
include 'source/admincp/include/function.php';
Administrator(1);
ini_set('memory_limit', '-1');
$setup=SafeRequest("setup","get");
?>
<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=<?php echo IN_CHARSET; ?>" />
<meta http-equiv="x-ua-compatible" content="ie=7" />
<title>音悦台采集[全站]</title>
<link href="<?php echo IN_PATH; ?>static/admincp/css/main.css" rel="stylesheet" type="text/css" />
<link href="<?php echo IN_PATH; ?>static/pack/asynctips/asynctips.css" rel="stylesheet" type="text/css" />
<script type="text/javascript" src="<?php echo IN_PATH; ?>static/pack/asynctips/jquery.min.js"></script>
<script type="text/javascript" src="<?php echo IN_PATH; ?>static/pack/asynctips/asyncbox.v1.4.5.js"></script>
<script type="text/javascript">
function caiji_ing(_num, _classid, _set, _values){
        var list = Number(_classid) + 1;
        var percent = Math.round(_num * 100 / 2000);
        document.getElementById("set").innerHTML = _set;
        document.getElementById("values").innerHTML = _values;
        document.getElementById("num").innerHTML = _num + "/2000[" + _classid + "/7]";
        document.getElementById("progressbar").style.width = percent + "%";
        if(percent > 0){
                document.getElementById("progressbar").innerHTML = percent + "%";
                document.getElementById("progressText").innerHTML = "";
        }else{
                document.getElementById("progressText").innerHTML = percent + "%";
        }
        if(percent > 99 && list < 8){
                asyncbox.tips("第" + _classid + "栏采集完毕，即将采集第" + list + "栏！", "success", 10000);
                setTimeout("location.href='<?php echo $_SERVER['PHP_SELF']; ?>?setup=ing&classid=" + list + "';", 3000);
        }else if(percent > 99 && list > 7){
                asyncbox.tips("恭喜，所有栏目采集完毕！", "success", 2500);
                setTimeout("location.href='<?php echo $_SERVER['PHP_SELF']; ?>';", 3000);
        }
}
</script>
</head>
<body>
<div class="container">
<script type="text/javascript">parent.document.title = 'Ear Music Board 管理中心 - 音悦台采集[全站]';if(parent.$('admincpnav')) parent.$('admincpnav').innerHTML='音悦台采集[全站]';</script>
<div class="floattop"><div class="itemtitle"><h3>音悦台采集[全站]</h3></div></div><div class="floattopempty"></div>
<table class="tb tb2">
<tr><th class="partition">技巧提示</th></tr>
<tr><td class="tipsblock"><ul>
<li>7栏 x 每栏2000条 = 14000数据</li>
<li>采集后如需批量更改“所属会员”，请在 工具->执行语句 分两次执行以下语句</li>
<li><em class="lightnum">update <?php echo IN_DBTABLE; ?>video set in_uid=会员的ID;</em></li>
<li><em class="lightnum">update <?php echo IN_DBTABLE; ?>video set in_uname='会员的用户名';</em></li>
</ul></td></tr>
</table>
<h3>Ear Music 提示</h3>
<?php
switch($setup){
	case 'ing':
		caiji_opening();
		break;
	default:
		caiji_open();
		break;
	}
?>
</div>
</body>
</html>
<?php function caiji_open(){ ?>
<div class="infobox"><br />
<table class="tb tb2">
<tr>
<td><select onchange="window.open(this.options[this.selectedIndex].value);">
<option value="http://www.yinyuetai.com/">音悦台</option>
<option value="http://mv.yinyuetai.com/all.html#a=ML">内地</option>
<option value="http://mv.yinyuetai.com/all.html#a=HT">港台</option>
<option value="http://mv.yinyuetai.com/all.html#a=US">欧美</option>
<option value="http://mv.yinyuetai.com/all.html#a=KR">韩语</option>
<option value="http://mv.yinyuetai.com/all.html#a=JP">日语</option>
<option value="http://mv.yinyuetai.com/all.html#a=ACG">二次元</option>
<option value="http://mv.yinyuetai.com/all.html#a=Other">其他</option>
</select></td>
</tr>
</table>
<br /><p class="margintop"><input type="button" class="btn" value="一键录入一万四千数据" onclick="location.href='<?php echo $_SERVER['PHP_SELF']; ?>?setup=ing&classid=1';"></p><br /></div>
<?php } function caiji_opening(){
        echo "<div class=\"infobox\"><br />";
        echo "<table class=\"tb tb2\" style=\"border:1px solid #09C\">";
        echo "<tr><td>重复更新</td><td><div id=\"set\">0</div></td></tr>";
        echo "<tr><td>采集入库</td><td><div id=\"values\">0</div></td></tr>";
        echo "<tr><td>完成状态</td><td><div id=\"num\">0/2000[1/7]</div></td></tr>";
        echo "<tr><td>完成进度</td><td><div id=\"progressbar\" style=\"float:left;width:1px;text-align:center;color:#FFFFFF;background-color:#09C\"></div><div id=\"progressText\" style=\"float:left\">0%</div></td></tr>";
        echo "</table>";
        echo "<br /><p class=\"margintop\"><input type=\"button\" class=\"btn\" value=\"撤销\" onclick=\"history.go(-1);\"></p><br /></div>";
        ob_start();
        @set_time_limit(0);
	$num = 0;
	$set = 0;
	$values = 0;
	$classid = SafeRequest("classid","get");
	$pagenums = 100;
	if($classid == 1){
	        $classname = "ML";
        }elseif($classid == 2){
	        $classname = "HT";
        }elseif($classid == 3){
	        $classname = "US";
        }elseif($classid == 4){
	        $classname = "KR";
        }elseif($classid == 5){
	        $classname = "JP";
        }elseif($classid == 6){
	        $classname = "ACG";
	        $pagenums = 4;
        }elseif($classid == 7){
	        $classname = "Other";
        }
        for($p = 1; $p <= $pagenums; $p++){
                $page = @file_get_contents('http://mvapi.yinyuetai.com/mvchannel/so?tid=17%3B57&a='.$classname.'&page='.$p);
                preg_match_all('/\{"videoId":(\d+),"title":"(.*?)","description":"(.*?)","image":"(.*?)","artists":(.*?)"dateCreated":"(.*?)"\}/', $page, $arr);
                for($l = 0; $l < count($arr[0]); $l++){
                        $num = $num + 1;
                        $json = @file_get_contents('http://www.yinyuetai.com/api/info/get-video-urls?callback=callback&videoId='.$arr[1][$l]);
                        if(preg_match('/heVideoUrl/', $json)){
                                $play = preg_replace_callback('/callback\(\{(.*?)heVideoUrl":"(.*?)\?sc(.*?)\}\)/', array(new callback('return $match[2];'), 'matches'), $json);
                        }elseif(preg_match('/hdVideoUrl/', $json)){
                                $play = preg_replace_callback('/callback\(\{(.*?)hdVideoUrl":"(.*?)\?sc(.*?)\}\)/', array(new callback('return $match[2];'), 'matches'), $json);
                        }else{
                                $play = preg_replace_callback('/callback\(\{(.*?)hcVideoUrl":"(.*?)\?sc(.*?)\}\)/', array(new callback('return $match[2];'), 'matches'), $json);
                        }
                        $dir = 'http:'.$arr[4][$l];
                        $name = IN_CHARSET == 'gbk' ? iconv('UTF-8', 'GBK//IGNORE', $arr[2][$l]) : $arr[2][$l];
                        $intro = IN_CHARSET == 'gbk' ? iconv('UTF-8', 'GBK//IGNORE', $arr[3][$l]) : $arr[3][$l];
                        global $db;
                        if($one = $db->getone("select in_id from ".tname('video')." where in_cover='".$dir."'")){
                                $set = $set + 1;
                                updatetable('video', array('in_name' => $name,'in_classid' => $classid,'in_play' => $play,'in_intro' => $intro,'in_addtime' => date('Y-m-d H:i:s')), array('in_id' => $one));
                        }else{
                                $values = $values + 1;
                                inserttable('video', array('in_name' => $name,'in_classid' => $classid,'in_singerid' => 0,'in_uid' => 1,'in_uname' => $_COOKIE['in_adminname'],'in_play' => $play,'in_cover' => $dir,'in_intro' => $intro,'in_hits' => 0,'in_passed' => 0,'in_addtime' => date('Y-m-d H:i:s')), 1);
                        }
                        echo "<script type=\"text/javascript\">caiji_ing($num, $classid, $set, $values);</script>";
                        ob_flush();
                        flush();
                }
        }
}
?>