<?php
include '../../system/db.class.php';
include '../../system/user.php';
header("Expires: Mon, 26 Jul 1997 05:00:00 GMT");
header("Cache-Control: no-cache, must-revalidate");
header("Pragma: no-cache");
header("Content-type: text/html;charset=".IN_CHARSET);
global $db,$userlogined,$erduo_in_userid,$erduo_in_username;
$row = $db->getrow("select in_id,in_grade from ".tname('plugin_mouse')." where in_uid=".intval($erduo_in_userid));
$grade = SafeRequest("grade","get");
if(!$userlogined){
	echo 'return_0';
}elseif(!$row){
	$setarr = array(
		'in_uid' => $erduo_in_userid,
		'in_uname' => $erduo_in_username,
		'in_grade' => $grade,
		'in_addtime' => date('Y-m-d H:i:s')
	);
	inserttable('plugin_mouse', $setarr, 1);
	echo 'return_2';
}elseif($grade < $row['in_grade']){
	echo 'return_1';
}else{
	updatetable('plugin_mouse', array('in_grade' => $grade), array('in_id' => $row['in_id']));
	echo 'return_2';
}
?>