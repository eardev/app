var no1, no2, no3, no4;
var button1, button2;
var time;
var sum = 0;
var mouse = 0;
function onGame() {
        init();
        no1 = setInterval("showTime()", 1e3);
        no2 = setInterval("showImage()", 1e3);
}
function init() {
        button1 = document.getElementById("button1");
        button2 = document.getElementById("button2");
        button1.style.cursor = "wait";
        button1.onclick = function() {
                void 0;
        };
        button2.style.cursor = "pointer";
        button2.onclick = function() {
                esc();
        };
        layer.tips("开始游戏", "#button1", {
                tips:[ 3, "#99C521" ],
                time:3e3
        });
        time = in_sec;
        sum = 0;
        mouse = 0;
}
function showTime() {
        document.getElementById("time").innerHTML = time;
        time -= 1;
        if (time <= 0) {
                esc();
        }
        document.getElementById("score1").innerHTML = mouse * 100 - (sum - mouse) * 100;
        document.getElementById("score2").innerHTML = sum * 100;
        document.getElementById("score3").innerHTML = sum - mouse;
        document.getElementById("score4").innerHTML = mouse;
}
function showImage() {
        var images = document.getElementsByName("_image");
        var index = Math.floor(Math.random() * 25);
        images[index].src = in_path + "source/plugin/mouse/01.jpg";
        sum += 1;
        no3 = setTimeout("stopImage(" + index + ")", in_msec);
}
function stopImage(index) {
        var images = document.getElementsByName("_image");
        images[index].src = in_path + "source/plugin/mouse/00.jpg";
}
function leaveImage(o) {
        document.getElementById(o).src = in_path + "source/plugin/mouse/00.jpg";
}
function clickMouse(o) {
        var str = document.getElementById(o).src;
        str = str.substr(str.length - 6, 6);
        if (str == "01.jpg") {
                document.getElementById(o).src = in_path + "source/plugin/mouse/02.jpg";
                mouse += 1;
                no4 = setInterval("leaveImage('" + o + "')", 500);
        }
}
function esc() {
        clearInterval(no1);
        clearInterval(no2);
        clearTimeout(no3);
        clearInterval(no4);
        button1.style.cursor = "pointer";
        button1.onclick = function() {
                onGame();
        };
        button2.style.cursor = "wait";
        button2.onclick = function() {
                void 0;
        };
        plugin_mouse(document.getElementById("score1").innerHTML);
        var images = document.getElementsByName("_image");
        for (var i = 0; i < images.length; i++) {
                images[i].src = in_path + "source/plugin/mouse/00.jpg";
        }
}
function plugin_mouse(_grade) {
        var XMLHttpReq = getHttpObject();
        XMLHttpReq.open("GET", in_path + "source/plugin/mouse/ajax.php?grade=" + _grade, true);
        XMLHttpReq.onreadystatechange = function() {
                if (XMLHttpReq.readyState == 4) {
                        if (XMLHttpReq.status == 200) {
                                if (XMLHttpReq.responseText == "return_0") {
                                        layer.tips("登录可保存纪录", "#button2", {
                                                tips:[ 1, "#0FA6D8" ],
                                                time:3e3
                                        });
                                } else if (XMLHttpReq.responseText == "return_1") {
                                        layer.tips("暂未破最高纪录", "#button2", {
                                                tips:[ 3, "#3595CC" ],
                                                time:3e3
                                        });
                                } else if (XMLHttpReq.responseText == "return_2") {
                                        layer.tips("已刷新最高纪录", "#button2", {
                                                tips:[ 3, "#FF8901" ],
                                                time:3e3
                                        });
                                } else {
                                        layer.msg("内部出现错误，请稍后再试！", {
                                                icon:5
                                        });
                                }
                        } else {
                                layer.msg("通讯异常，请检查网络设置！", {
                                        icon:3
                                });
                        }
                }
        };
        XMLHttpReq.send(null);
}