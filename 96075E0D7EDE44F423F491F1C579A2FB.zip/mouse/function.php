<?php
function plugin_install(){
        $DROP = "DROP TABLE IF EXISTS `".IN_DBTABLE."plugin_mouse`";
        $CREATE = "CREATE TABLE `".IN_DBTABLE."plugin_mouse` (`in_id` int(11) NOT NULL AUTO_INCREMENT, `in_uid` int(11) NOT NULL, `in_uname` varchar(255) NOT NULL, `in_grade` int(11) NOT NULL, `in_addtime` datetime DEFAULT NULL, PRIMARY KEY (`in_id`)) ENGINE=MyISAM AUTO_INCREMENT=1 DEFAULT CHARSET=".IN_DBCHARSET;
        if(!mysql_query($DROP) || !mysql_query($CREATE)){
                exit("<div class=\"infobox\"><br /><h4 class=\"infotitle3\">".mysql_error()."</h4><br /></div></div></body></html>");
        }
}
function plugin_uninstall(){
        $DROP = "DROP TABLE IF EXISTS `".IN_DBTABLE."plugin_mouse`";
        if(!mysql_query($DROP)){
                ShowMessage(mysql_error(),$_SERVER['HTTP_REFERER'],"infotitle3",3000,1);
        }
}
?>