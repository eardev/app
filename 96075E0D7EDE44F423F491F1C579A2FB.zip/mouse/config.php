<?php
define('in_plugin_mouse_open', '1');
define('in_plugin_mouse_sec', '60');
define('in_plugin_mouse_msec', '1000');
?>