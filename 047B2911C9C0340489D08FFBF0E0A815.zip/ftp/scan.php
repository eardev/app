<?php
if(!defined('IN_ROOT')){exit('Access denied');}
include 'source/admincp/include/function.php';
Administrator(1);
$setup=SafeRequest("setup","get");
?>
<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=<?php echo IN_CHARSET; ?>" />
<meta http-equiv="x-ua-compatible" content="ie=7" />
<title>FTPɨ�����</title>
<link href="<?php echo IN_PATH; ?>static/admincp/css/main.css" rel="stylesheet" type="text/css" />
<link href="<?php echo IN_PATH; ?>static/pack/asynctips/asynctips.css" rel="stylesheet" type="text/css" />
<script type="text/javascript" src="<?php echo IN_PATH; ?>static/pack/asynctips/jquery.min.js"></script>
<script type="text/javascript" src="<?php echo IN_PATH; ?>static/pack/asynctips/asyncbox.v1.4.5.js"></script>
<script type="text/javascript" src="<?php echo IN_PATH; ?>static/pack/layer/jquery.js"></script>
<script type="text/javascript" src="<?php echo IN_PATH; ?>static/pack/layer/lib.js"></script>
<script type="text/javascript">
var pop = {
	up: function(scrolling, text, url, width, height, top) {
		layer.open({
			type: 2,
			maxmin: true,
			title: text,
			content: [url, scrolling],
			area: [width, height],
			offset: top,
			shade: false
		});
	}
}
function CheckForm(){
        if(document.form.uname.value==""){
            asyncbox.tips("������Ա����Ϊ�գ�����д��", "wait", 1000);
            document.form.uname.focus();
            return false;
        }
        else if(document.form.ext.value==""){
            asyncbox.tips("�ļ����Ͳ���Ϊ�գ�����д��", "wait", 1000);
            document.form.ext.focus();
            return false;
        }
        else {
            return true;
        }
}
</script>
</head>
<body>
<?php
switch($setup){
	case 'ing':
		$conn = @ftp_connect(IN_REMOTEHOST, IN_REMOTEPORT, 20) or ShowMessage("FTP����������ʧ�ܣ�����ȫ�����ã�","history.back(1);","infotitle3",3000,2);
		IN_REMOTEOUT && function_exists('ftp_set_option') && @ftp_set_option($conn, FTP_TIMEOUT_SEC, IN_REMOTEOUT);
		@ftp_login($conn, IN_REMOTEUSER, IN_REMOTEPW) or ShowMessage("FTP��������¼ʧ�ܣ�����ȫ�����ã�","history.back(1);","infotitle3",3000,2);
		@ftp_pasv($conn, IN_REMOTEPASV ? true : false);
		ftp_scanning($conn);
		@ftp_close($conn);
		break;
	default:
		ftp_scan();
		break;
}
?>
</body>
</html>
<?php function ftp_scan(){ ?>
<div class="container">
<script type="text/javascript">parent.document.title = 'Ear Music Board �������� - FTPɨ�����';if(parent.$('admincpnav')) parent.$('admincpnav').innerHTML='FTPɨ�����';</script>
<div class="floattop"><div class="itemtitle"><h3>FTPɨ�����</h3></div></div><div class="floattopempty"></div>
<form action="<?php echo $_SERVER['PHP_SELF']; ?>?setup=ing" method="post" name="form">
<table class="tb tb2">
<tr>
<td>������Ŀ��<select name="classid" id="classid">
<?php
global $db;
$res=$db->query("select * from ".tname('class')." order by in_id asc");
if($res){
        while ($row = $db->fetch_array($res)){
                echo "<option value=\"".$row['in_id']."\">".$row['in_name']."</option>";
        }
}
?>
</select></td>
<td>����ר����<select name="specialid" id="specialid">
<option value="0">��ѡ��</option>
<?php
$res=$db->query("select * from ".tname('special')." order by in_addtime desc");
if($res){
        while ($row = $db->fetch_array($res)){
                echo "<option value=\"".$row['in_id']."\">".getlenth($row['in_name'], 10)."</option>";
        }
}
?>
</select>&nbsp;&nbsp;<a href="javascript:void(0)" onclick="pop.up('yes', 'ѡ��ר��', '<?php echo IN_PATH; ?>source/pack/tag/special_opt.php?so=form.specialid', '500px', '400px', '65px');" class="addtr">ѡ��</a></td>
</tr>
<tr>
<td>�������֣�<select name="singerid" id="singerid">
<option value="0">��ѡ��</option>
<?php
$res=$db->query("select * from ".tname('singer')." order by in_addtime desc");
if($res){
        while ($row = $db->fetch_array($res)){
                echo "<option value=\"".$row['in_id']."\">".getlenth($row['in_name'], 10)."</option>";
        }
}
?>
</select>&nbsp;&nbsp;<a href="javascript:void(0)" onclick="pop.up('yes', 'ѡ�����', '<?php echo IN_PATH; ?>source/pack/tag/singer_opt.php?so=form.singerid', '500px', '400px', '65px');" class="addtr">ѡ��</a></td>
<td>������Ա��<input type="text" class="txt" value="<?php echo getfield('user', 'in_userid', 'in_username', $_COOKIE['in_adminname']) ? $_COOKIE['in_adminname'] : ''; ?>" name="uname" id="uname"></td>
</tr>
<tr>
<td>����Ȩ�ޣ�<select name="grade" id="grade">
<option value="3">�ο�����</option>
<option value="2">��ͨ�û�</option>
<option value="1">�����Ա</option>
</select></td>
<td>���ؿ۵㣺<input type="text" class="txt" value="0" name="points" id="points" onkeyup="this.value=this.value.replace(/[^\d]/g,'')" onbeforepaste="clipboardData.setData('text',clipboardData.getData('text').replace(/[^\d]/g,''))"></td>
</tr>
<tr>
<td class="td29 lightnum">����·����<input type="text" class="txt" value="http://127.0.0.1/audio/mp3" name="path" id="path" onfocus="javascript:if('http://127.0.0.1/audio/mp3'==this.value)this.value=''" onblur="javascript:if(''==this.value)this.value='http://127.0.0.1/audio/mp3'"></td>
<td>�ļ����ͣ�<input type="text" class="txt" value="mp3|m4a" name="ext" id="ext"></td>
</tr>
<tr><td class="longtxt lightnum">ɨ��Ŀ¼��<input type="text" class="txt" value="audio/mp3" name="urlget" id="urlget" onfocus="javascript:if('audio/mp3'==this.value)this.value=''" onblur="javascript:if(''==this.value)this.value='audio/mp3'"></td></tr>
</table>
<table class="tb tb2">
<tr><td><input type="submit" class="btn" value="�ύ" onclick="return CheckForm();" /></td></tr>
</table>
</form>
</div>
<?php } function ftp_scanning($conn){
	$classid = SafeRequest("classid","post");
	$specialid = SafeRequest("specialid","post");
	$singerid = SafeRequest("singerid","post");
	$uname = SafeRequest("uname","post");
	$uid = getfield('user', 'in_userid', 'in_username', $uname);
	$uid or ShowMessage("������Ա�����ڣ�����ģ�","history.back(1);","infotitle3",3000,2);
	$grade = SafeRequest("grade","post");
	$points = intval(SafeRequest("points","post"));
	$ext = strtolower(SafeRequest("ext","post"));
	$dir = str_replace('\\'.'\\', '/', empty($_POST['urlget']) || $_POST['urlget'] == '.' ? '/' : SafeRequest("urlget","post"));
	$num = 0;
        echo '<div class="container">';
        echo '<script type="text/javascript">parent.document.title = \'Ear Music Board �������� - FTPɨ�����\';if(parent.$(\'admincpnav\')) parent.$(\'admincpnav\').innerHTML=\'FTPɨ�����\';</script>';
        echo '<div class="floattop"><div class="itemtitle"><h3>FTPɨ�����</h3></div></div><div class="floattopempty"></div>';
        echo '<table class="tb tb2">';
        echo '<tr><th class="partition">'.$dir.'</th></tr>';
        echo '</table>';
        echo '<table class="tb tb2">';
        echo '<tr class="header">';
        echo '<th>���</th>';
        echo '<th>����</th>';
        echo '<th>״̬</th>';
        echo '</tr>';
        foreach(@ftp_nlist($conn, $dir) as $list){
                $list = htmlspecialchars(trim(detect_encoding($list)), ENT_QUOTES, set_chars());
                $list = preg_match('/\//', $list) ? str_replace(substr($list, 0, strrpos($list, '/') + 1), '', $list) : $list;
                echo '<tr class="hover">';
		if(in_array(strtolower(substr($list, -3)), preg_split('/\|/', $ext))){
                        $num = $num + 1;
                        echo '<td>'.$num.'</td>';
                        echo '<td>'.$list.'</td>';
                        $name = substr($list, 0, strrpos($list, '.'));
                        $audio = SafeRequest("path","post").'/'.$list;
                        if(!getfield('music', 'in_id', 'in_audio', $audio)){
                                $setarr = array(
			                'in_name' => $name,
			                'in_classid' => $classid,
			                'in_specialid' => $specialid,
			                'in_singerid' => $singerid,
			                'in_uid' => $uid,
			                'in_uname' => $uname,
			                'in_audio' => $audio,
			                'in_lyric' => '',
			                'in_text' => '',
			                'in_cover' => '',
			                'in_tag' => '',
			                'in_color' => '',
			                'in_hits' => 0,
			                'in_downhits' => 0,
			                'in_favhits' => 0,
			                'in_goodhits' => 0,
			                'in_badhits' => 0,
			                'in_points' => $points,
			                'in_grade' => $grade,
			                'in_best' => 0,
			                'in_passed' => 0,
			                'in_wrong' => 0,
			                'in_addtime' => date('Y-m-d H:i:s')
                                );
                                inserttable('music', $setarr, 1);
                                echo '<td>���</td>';
                        }else{
                                echo '<td>�ظ�</td>';
                        }
		}
                echo '</tr>';
        }
        echo '</table>';
        echo '</div>';
}
?>