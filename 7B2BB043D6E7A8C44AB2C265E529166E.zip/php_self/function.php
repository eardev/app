<?php
function plugin_install(){
	$config = file_get_contents('source/system/config.inc.php');
	if(!preg_match('/\$_SERVER\[\'PHP_SELF\'\] =/', $config)){
	        $replace = "<?php\r\n";
	        $replace = $replace."\$_SERVER['PHP_SELF'] = preg_replace('/\?([\S]+)/', '', \$_SERVER['REQUEST_URI']);";
	        $config = preg_replace('/^<\?php/', $replace, $config);
	        $ifile = new iFile('source/system/config.inc.php', 'w');
	        $ifile->WriteFile($config, 3);
	}
}
function plugin_uninstall(){
	$config = file_get_contents('source/system/config.inc.php');
	if(preg_match('/\$_SERVER\[\'PHP_SELF\'\] =/', $config)){
	        $search = "<?php\r\n";
	        $search = $search."\$_SERVER['PHP_SELF'] = preg_replace('/\?([\S]+)/', '', \$_SERVER['REQUEST_URI']);";
	        $config = str_replace($search, '<?php', $config);
	        $ifile = new iFile('source/system/config.inc.php', 'w');
	        $ifile->WriteFile($config, 3);
	}
}
?>