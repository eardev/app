<?php
function plugin_install(){
}
function plugin_uninstall(){
}
?>