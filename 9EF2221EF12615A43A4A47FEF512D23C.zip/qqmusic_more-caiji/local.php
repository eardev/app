<?php
if(!defined('IN_ROOT')){exit('Access denied');}
include 'source/admincp/include/function.php';
Administrator(1);
ini_set('memory_limit', '-1');
?>
<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=<?php echo IN_CHARSET; ?>" />
<meta http-equiv="x-ua-compatible" content="ie=7" />
<title>QQ音乐采集[专辑]</title>
<link href="<?php echo IN_PATH; ?>static/admincp/css/main.css" rel="stylesheet" type="text/css" />
<script type="text/javascript">
function caiji_local(_num, _nums, _number, _pagenum, _uname, _uid, _s, _a, _m, _p, _set, _values){
        var percent = Math.round(_num * 100 / _nums);
        document.getElementById("set").innerHTML = _set;
        document.getElementById("values").innerHTML = _values;
        document.getElementById("nums").innerHTML = _nums;
        document.getElementById("status").innerHTML = (Number(_number) + 1) + "/" + _pagenum;
        document.getElementById("progressbar").style.width = percent + "%";
        if(percent > 0){
                document.getElementById("progressbar").innerHTML = percent + "%";
                document.getElementById("progressText").innerHTML = "";
        }else{
                document.getElementById("progressText").innerHTML = percent + "%";
        }
        if((Number(_number) + 1) < _pagenum && percent > 99){
                location.href = '<?php echo $_SERVER['PHP_SELF']; ?>?number=' + (Number(_number) + 1) + '&uname=' + _uname + '&uid=' + _uid + '&s=' + _s + '&a=' + _a + '&m=' + _m + '&p=' + _p;
        }
}
</script>
</head>
<body>
<div class="container">
<div class="floattop"><div class="itemtitle"><h3>QQ音乐采集[专辑]</h3></div></div><div class="floattopempty"></div>
<?php
        echo "<h3>Ear Music 提示</h3><div class=\"infobox\"><br />";
        echo "<table class=\"tb tb2\" style=\"border:1px solid #09C\">";
        echo "<tr><td>重复更新</td><td><div id=\"set\">0</div></td></tr>";
        echo "<tr><td>采集入库</td><td><div id=\"values\">0</div></td></tr>";
        echo "<tr><td>专辑曲目</td><td><div id=\"nums\">0</div></td></tr>";
        echo "<tr><td>专辑张数</td><td><div id=\"status\">0/0</div></td></tr>";
        echo "<tr><td>单张进度</td><td><div id=\"progressbar\" style=\"float:left;width:1px;text-align:center;color:#FFFFFF;background-color:#09C\"></div><div id=\"progressText\" style=\"float:left\">0%</div></td></tr>";
        echo "</table>";
        echo "<br /><p class=\"margintop\"><input type=\"button\" class=\"btn\" value=\"撤销\" onclick=\"history.go(-1);\"></p><br /></div>";
        ob_start();
        @set_time_limit(0);
        global $db;
        $uname = SafeRequest("uname","get");
        $uid = SafeRequest("uid","get");
        $singerid = SafeRequest("s","get");
        $sclassid = SafeRequest("a","get");
        $mclassid = SafeRequest("m","get");
        $page = SafeRequest("p","get");
        $pages = explode('|', $page);
        $pagenum = count($pages);
        $number = SafeRequest("number","get");
        $albumcode = @file_get_contents('http://y.qq.com/n/yqq/album/'.$pages[$number].'.html');
        $albumcode = IN_CHARSET == 'gbk' ? iconv('UTF-8', 'GBK//IGNORE', $albumcode) : $albumcode;
        $cget = explode('<img id="albumImg" src="', $albumcode);
        $cget = explode('" onerror="', $cget[1]);
        $cdown = 'http:'.$cget[0];
        $nget = explode('<h1 class="data__name_txt" title="', $cget[1]);
        $nget = explode('">', $nget[1]);
        $sname = $nget[0];
        $lget = explode('</li>', $cget[1]);
        $lget = explode('">', $lget[1]);
        $lget = str_replace('语种：', '', $lget[1]);
        $slang = in_array($lget, array("国语", "粤语", "闽语", "英语", "日语", "韩语")) ? $lget : "其它";
        $fget = explode('</li>', $cget[1]);
        $fget = explode('发行公司：<a', $fget[3]);
        $fget = explode('">', $fget[1]);
        $sfirm = str_replace('</a>', '', $fget[1]);
        $iget = explode('专辑简介</h3>', $albumcode);
        $iget = explode('</div>', $iget[1]);
        $sintro = trim(preg_replace('/<p>(.*?)<\/p>/', '\1'."\r\n", $iget[0]));
        $scover = 'data/attachment/special/cover/qqmusic_'.$pages[$number].'.jpg';
        fwrite(fopen($scover, 'wb'), @file_get_contents($cdown));
        if($one = $db->getone("select in_id from ".tname('special')." where in_cover='".$scover."'")){
		updatetable('special', array('in_name' => $sname,'in_classid' => $sclassid,'in_singerid' => $singerid,'in_uid' => $uid,'in_uname' => $uname,'in_lang' => $slang,'in_firm' => $sfirm,'in_intro' => $sintro,'in_addtime' => date('Y-m-d H:i:s')), array('in_id' => $one));
        }else{
		inserttable('special', array('in_name' => $sname,'in_classid' => $sclassid,'in_singerid' => $singerid,'in_uid' => $uid,'in_uname' => $uname,'in_cover' => $scover,'in_intro' => $sintro,'in_firm' => $sfirm,'in_lang' => $slang,'in_hits' => 0,'in_passed' => 0,'in_addtime' => date('Y-m-d H:i:s')), 1);
        }
        $sid = $db->getone("select in_id from ".tname('special')." where in_cover='".$scover."'");
        preg_match_all('/\{"albumdesc"(.*?)"songid":(\d+),"songmid":"(.*?)","songname":"(.*?)","songorig"(.*?)"singers":"(.*?)"\}/', $albumcode, $array);
        if(!empty($array)){
        	$nums = count($array[0]) / 2;
        	$num = 0;
        	$set = 0;
        	$values = 0;
        	for($i = 0; $i < $nums; $i++){
                        $num = $num + 1;
			$adown = 'http://ws.stream.qqmusic.qq.com/C100'.$array[3][$i].'.m4a?fromtag=38';
			$lyric = 'http://lyric.music.qq.com/fcgi-bin/fcg_query_lyric.fcg?nobase64=1&musicid='.$array[2][$i];
			$n_ame = $array[4][$i];
			$option = array('http' => array('header' => 'Referer:http://y.qq.com/'));
			$ltext = @file_get_contents($lyric, false, stream_context_create($option));
			$ltext = IN_CHARSET == 'gbk' ? iconv('UTF-8', 'GBK//IGNORE', $ltext) : $ltext;
			$ltext = preg_replace_callback('/MusicJsonCallback\(\{(.*?)"lyric":"(.*?)"\}\)/', array(new callback('return $match[2];'), 'matches'), $ltext);
			$lrc = html_entity_decode(str_replace("&#10;", "\r\n", $ltext), ENT_COMPAT, set_chars());
			$w_ord = trim(preg_replace('/\[(.*?)\]/', '', $lrc));
			$a_udio = "data/attachment/music/audio/qqmusic_".$array[3][$i].".m4a";
			$l_yric = "data/attachment/music/lyric/qqmusic_".$array[3][$i].".lrc";
			$c_over = "data/attachment/music/cover/qqmusic_".$array[3][$i].".jpg";
                        copy($scover, $c_over);
                        fwrite(fopen($l_yric, 'wb+'), $lrc);
                        if($one = $db->getone("select in_id from ".tname('music')." where in_audio='".$a_udio."'")){
                                $set = $set + 1;
                                updatetable('music', array('in_name' => $n_ame,'in_classid' => $mclassid,'in_specialid' => $sid,'in_singerid' => $singerid,'in_uid' => $uid,'in_uname' => $uname,'in_text' => $w_ord,'in_addtime' => date('Y-m-d H:i:s')), array('in_id' => $one));
                        }else{
                                $values = $values + 1;
                                inserttable('music', array('in_name' => $n_ame,'in_classid' => $mclassid,'in_specialid' => $sid,'in_singerid' => $singerid,'in_uid' => $uid,'in_uname' => $uname,'in_audio' => $a_udio,'in_lyric' => $l_yric,'in_text' => $w_ord,'in_cover' => $c_over,'in_hits' => 0,'in_downhits' => 0,'in_favhits' => 0,'in_goodhits' => 0,'in_badhits' => 0,'in_points' => 0,'in_grade' => 3,'in_best' => 0,'in_passed' => 0,'in_wrong' => 0,'in_addtime' => date('Y-m-d H:i:s')), 1);
                        }
                        $file = fopen($adown, 'rb');
                        $newf = fopen($a_udio, 'wb');
                        while(!feof($file)){
                                $data = fread($file, 1024*8);
                                fwrite($newf, $data, 1024*8);
                                echo "<script type=\"text/javascript\">caiji_local($num, $nums, $number, $pagenum, '$uname', $uid, $singerid, $sclassid, $mclassid, '$page', $set, $values);</script>";
                                ob_flush();
                                flush();
                        }
                        fclose($file);
                        fclose($newf);
                }
        }
?>
</div>
</body>
</html>