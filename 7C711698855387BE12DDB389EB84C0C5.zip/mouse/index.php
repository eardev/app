<?php
if(!defined('IN_ROOT')){exit('Access denied');}
include 'source/plugin/mouse/config.php';
global $db,$userlogined,$erduo_in_userid;
?>
<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=<?php echo IN_CHARSET; ?>" />
<meta http-equiv="x-ua-compatible" content="ie=7" />
<title>����� - <?php echo IN_NAME; ?></title>
<meta name="Keywords" content="<?php echo IN_KEYWORDS; ?>" />
<meta name="Description" content="<?php echo IN_DESCRIPTION; ?>" />
<link href="<?php echo IN_PATH; ?>static/pack/asynctips/asynctips.css" rel="stylesheet" type="text/css" />
<script type="text/javascript" src="<?php echo IN_PATH; ?>static/pack/asynctips/jquery.min.js"></script>
<script type="text/javascript" src="<?php echo IN_PATH; ?>static/pack/asynctips/asyncbox.v1.4.5.js"></script>
<script type="text/javascript" src="<?php echo IN_PATH; ?>static/pack/layer/jquery.js"></script>
<script type="text/javascript" src="<?php echo IN_PATH; ?>static/pack/layer/lib.js"></script>
<script type="text/javascript" src="<?php echo IN_PATH; ?>static/user/js/lib.js"></script>
<script type="text/javascript" src="<?php echo IN_PATH; ?>source/plugin/mouse/lib.js"></script>
<script type="text/javascript">
function $(obj) {return document.getElementById(obj);}
var in_sec = '<?php echo in_plugin_mouse_sec; ?>';
var in_msec = '<?php echo in_plugin_mouse_msec; ?>';
var in_path = '<?php echo IN_PATH; ?>';
var guide_url = '<?php echo rewrite_mode('user.php/people/home/'); ?>';
var pop = {
	up: function(scrolling, text, url, width, height, top) {
		layer.open({
			type: 2,
			maxmin: true,
			title: text,
			content: [url, scrolling],
			area: [width, height],
			offset: top,
			shade: false
		});
	}
}
function qzone_return(type){
        layer.closeAll();
        if(type==1){
            uc_syn('login');
            location.href = guide_url;
        }else{
            location.href = '<?php echo rewrite_mode('user.php/people/connect/'); ?>';
        }
}
function update_seccode(){
	$('img_seccode').src = '<?php echo rewrite_mode('user.php/people/seccode/\' + Math.random() + \'/'); ?>';
}
</script>
<style type="text/css">
@import url(<?php echo IN_PATH; ?>static/user/css/style.css);
</style>
</head>
<body>
<?php include 'source/user/people/top.php'; ?>
<div id="main">
<?php include 'source/user/people/left.php'; ?>
<div id="mainarea">
<h2 class="title"><img src="<?php echo IN_PATH; ?>source/plugin/mouse/icon.jpg">�����</h2>
<?php if(in_plugin_mouse_open){ ?>
<div id="content">
<div class="c_mgs"><div class="ye_r_t"><div class="ye_l_t"><div class="ye_r_b"><div class="ye_l_b">
<table cellspacing="0" cellpadding="0" width="100%" class="task_notice">
<tr>
<td width="70"><img src="<?php echo getavatar($erduo_in_userid); ?>" width="64" height="64" /></td>
<td>
<h3>�ұ��ֵ���߼�¼</h3>
<p>�ǲ����е����������ˣ��Ͻ����������߼�¼�ɣ�</p>
<p>��ս�÷֣�<strong class="num"><?php echo $userlogined ? getfield('plugin_mouse', 'in_grade', 'in_uid', $erduo_in_userid, 'δ��ս') : 'δ��¼'; ?></strong></p></td>
</tr>
</table>
</div></div></div></div></div>
<div class="c_mgs"><div class="ye_r_t"><div class="ye_l_t"><div class="ye_r_b"><div class="ye_l_b" align="center">
<table border="1" cellspacing="3" bgcolor="white">
<tr>
<td><img src="<?php echo IN_PATH; ?>source/plugin/mouse/00.jpg" name="_image" id="img_1" onclick="clickMouse(this.id)"></td>
<td><img src="<?php echo IN_PATH; ?>source/plugin/mouse/00.jpg" name="_image" id="img_2" onclick="clickMouse(this.id)"></td>
<td><img src="<?php echo IN_PATH; ?>source/plugin/mouse/00.jpg" name="_image" id="img_3" onclick="clickMouse(this.id)"></td>
<td><img src="<?php echo IN_PATH; ?>source/plugin/mouse/00.jpg" name="_image" id="img_4" onclick="clickMouse(this.id)"></td>
<td><img src="<?php echo IN_PATH; ?>source/plugin/mouse/00.jpg" name="_image" id="img_5" onclick="clickMouse(this.id)"></td>
</tr>
<tr>
<td><img src="<?php echo IN_PATH; ?>source/plugin/mouse/00.jpg" name="_image" id="img_6" onclick="clickMouse(this.id)"></td>
<td><img src="<?php echo IN_PATH; ?>source/plugin/mouse/00.jpg" name="_image" id="img_7" onclick="clickMouse(this.id)"></td>
<td><img src="<?php echo IN_PATH; ?>source/plugin/mouse/00.jpg" name="_image" id="img_8" onclick="clickMouse(this.id)"></td>
<td><img src="<?php echo IN_PATH; ?>source/plugin/mouse/00.jpg" name="_image" id="img_9" onclick="clickMouse(this.id)"></td>
<td><img src="<?php echo IN_PATH; ?>source/plugin/mouse/00.jpg" name="_image" id="img_10" onclick="clickMouse(this.id)"></td>
</tr>
<tr>
<td><img src="<?php echo IN_PATH; ?>source/plugin/mouse/00.jpg" name="_image" id="img_11" onclick="clickMouse(this.id)"></td>
<td><img src="<?php echo IN_PATH; ?>source/plugin/mouse/00.jpg" name="_image" id="img_12" onclick="clickMouse(this.id)"></td>
<td><img src="<?php echo IN_PATH; ?>source/plugin/mouse/00.jpg" name="_image" id="img_13" onclick="clickMouse(this.id)"></td>
<td><img src="<?php echo IN_PATH; ?>source/plugin/mouse/00.jpg" name="_image" id="img_14" onclick="clickMouse(this.id)"></td>
<td><img src="<?php echo IN_PATH; ?>source/plugin/mouse/00.jpg" name="_image" id="img_15" onclick="clickMouse(this.id)"></td>
</tr>
<tr>
<td><img src="<?php echo IN_PATH; ?>source/plugin/mouse/00.jpg" name="_image" id="img_16" onclick="clickMouse(this.id)"></td>
<td><img src="<?php echo IN_PATH; ?>source/plugin/mouse/00.jpg" name="_image" id="img_17" onclick="clickMouse(this.id)"></td>
<td><img src="<?php echo IN_PATH; ?>source/plugin/mouse/00.jpg" name="_image" id="img_18" onclick="clickMouse(this.id)"></td>
<td><img src="<?php echo IN_PATH; ?>source/plugin/mouse/00.jpg" name="_image" id="img_19" onclick="clickMouse(this.id)"></td>
<td><img src="<?php echo IN_PATH; ?>source/plugin/mouse/00.jpg" name="_image" id="img_20" onclick="clickMouse(this.id)"></td>
</tr>
<tr>
<td><img src="<?php echo IN_PATH; ?>source/plugin/mouse/00.jpg" name="_image" id="img_21" onclick="clickMouse(this.id)"></td>
<td><img src="<?php echo IN_PATH; ?>source/plugin/mouse/00.jpg" name="_image" id="img_22" onclick="clickMouse(this.id)"></td>
<td><img src="<?php echo IN_PATH; ?>source/plugin/mouse/00.jpg" name="_image" id="img_23" onclick="clickMouse(this.id)"></td>
<td><img src="<?php echo IN_PATH; ?>source/plugin/mouse/00.jpg" name="_image" id="img_24" onclick="clickMouse(this.id)"></td>
<td><img src="<?php echo IN_PATH; ?>source/plugin/mouse/00.jpg" name="_image" id="img_25" onclick="clickMouse(this.id)"></td>
</tr>
</table>
</div></div></div></div></div>
<div class="space_list">
<table cellspacing="0" cellpadding="0" width="100%">
<thead><tr>
<td>�÷�</td>
<td align="center">�ܷ�</td>
<td align="center">©��</td>
<td align="center">����</td>
</tr></thead>
<tr>
<td id="score1">0</td>
<td align="center" id="score2">0</td>
<td align="center" id="score3">0</td>
<td align="center" id="score4">0</td>
</tr>
</table>
<div class="page"><a id="button1" onclick="onGame()" class="first" style="cursor:pointer">��ʼ��Ϸ</a><em id="time">0</em><strong id="button2" onclick="void(0)" style="cursor:wait">ֹͣ��Ϸ</strong></div>
</div>
</div>
<div id="sidebar">
<div class="sidebox">
<h2 class="title">��߼�¼TOP15</h2>
<ul class="avatar_list">
<?php
$query = $db->query("select * from ".tname('plugin_mouse')." order by in_grade desc LIMIT 0,15");
while ($row = $db->fetch_array($query)){
$invisible = $db->getone("select in_invisible from ".tname('session')." where in_uid=".$row['in_uid']);
$online = is_numeric($invisible) && $invisible == 0 ? '<p class="online_icon_p">' : '<p>';
?>
<li>
<div class="avatar48"><a href="<?php echo getlink($row['in_uid']); ?>"><img src="<?php echo getavatar($row['in_uid']); ?>" /></a></div>
<?php echo $online; ?><a href="<?php echo getlink($row['in_uid']); ?>" title="<?php echo $row['in_uname']; ?>"><?php echo $row['in_uname']; ?></a></p>
<p class="gray"><?php echo $row['in_grade']; ?></p>
</li>
<?php } ?>
</ul>
</div>
</div>
<?php }else{ ?>
<div class="showmessage"><div class="ye_r_t"><div class="ye_l_t"><div class="ye_r_b"><div class="ye_l_b">
<caption><h2>��Ϣ��ʾ</h2></caption>
<p>��Ǹ���ò����δ������</p>
</div></div></div></div></div>
<?php } ?>
</div>
<div id="bottom"></div>
</div>
<?php include 'source/user/people/bottom.php'; ?>
</body>
</html>