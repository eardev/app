<?php
include '../../system/db.class.php';
include '../../system/user.php';
require_once 'config.php';
require_once 'Epay.class.php';
error_reporting(0);
header("Expires: Mon, 26 Jul 1997 05:00:00 GMT");
header("Cache-Control: no-cache, must-revalidate");
header("Pragma: no-cache");
header("Content-type: text/html;charset=".IN_CHARSET);
global $db,$userlogined,$erduo_in_userid,$erduo_in_username;
$userlogined or exit('-1');
$tid = intval(SafeRequest("tid","get"));
$text = $tid > 1 ? $tid > 2 ? '包年密钥' : '包季密钥' : '包月密钥';
$money = $tid > 1 ? $tid > 2 ? IN_SIGN * 12 : IN_SIGN * 3 : IN_SIGN;
$db->query("delete from ".tname('buylog')." where in_lock=1 and in_uid=".$erduo_in_userid);
$setarr = array(
	'in_uid' => $erduo_in_userid,
	'in_uname' => $erduo_in_username,
	'in_title' => $erduo_in_userid.'|'.time(),
	'in_tid' => $tid,
	'in_money' => $money,
	'in_lock' => 1,
	'in_addtime' => date('Y-m-d H:i:s')
);
inserttable('buylog', $setarr, 1);
$EpayClient = new EpayClientAop($config);
$EpayClient->setOutTradeNo($setarr['in_title']);
$EpayClient->setSubject($erduo_in_username.' | '.convert_charset($text));
$EpayClient->setTradeAmount($setarr['in_money']);
$EpayClient->setTimeOut('5m');
$EpayClient->setMobile(0);
$result = json_decode($EpayClient->create(in_plugin_Epay_way));
echo $result->pay_url;
?>