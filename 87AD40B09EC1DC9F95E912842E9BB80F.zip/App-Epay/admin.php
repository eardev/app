<?php
if(!defined('IN_ROOT')){exit('Access denied');}
include 'source/plugin/App-Epay/config.php';
include 'source/admincp/include/function.php';
Administrator(1);
$action=SafeRequest("action","get");
?>
<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=<?php echo IN_CHARSET; ?>" />
<meta http-equiv="x-ua-compatible" content="ie=7" />
<title>E交易</title>
<link href="<?php echo IN_PATH; ?>static/admincp/css/main.css" rel="stylesheet" type="text/css" />
<script type="text/javascript">function $(obj) {return document.getElementById(obj);}</script>
</head>
<body>
<?php
switch($action){
	case 'save':
		save();
		break;
	default:
		main($config['notify_url']);
		break;
	}
?>
</body>
</html>
<?php function main($notify_url){ ?>
<form method="post" action="<?php echo $_SERVER['PHP_SELF']; ?>?action=save">
<div class="container">
<script type="text/javascript">parent.document.title = 'EarCMS Board 管理中心 - E交易';if(parent.$('admincpnav')) parent.$('admincpnav').innerHTML='E交易';</script>
<div class="floattop"><div class="itemtitle"><h3>E交易</h3></div></div><div class="floattopempty"></div>
<table class="tb tb2">
<tr><th class="partition">技巧提示</th></tr>
<tr><td class="tipsblock"><ul>
<li>官方网站：<a href="http://www.payonline.xin/" target="_blank">www.payonline.xin</a></li>
<li>获取配置：应用管理->添加应用->订单式支付->应用配置</li>
<li>响应地址：<em class="lightnum"><?php echo $notify_url; ?></em></li>
</ul></td></tr>
</table>
<table class="tb tb2">
<tr><th colspan="15" class="partition">插件设置</th></tr>
<tr><td colspan="2" class="td27">支付通道:</td></tr>
<tr><td class="vtop rowform">
<select name="in_plugin_Epay_way">
<option value="wx">微信</option>
<option value="qq"<?php if(in_plugin_Epay_way == 'qq'){echo ' selected';} ?>>QQ钱包</option>
<option value="zfb"<?php if(in_plugin_Epay_way == 'zfb'){echo ' selected';} ?>>支付宝</option>
</select>
</td></tr>
<tr><td colspan="2" class="td27">AppID:</td></tr>
<tr><td class="vtop rowform"><input type="text" class="txt" value="<?php echo in_plugin_Epay_app; ?>" name="in_plugin_Epay_app"></td></tr>
<tr><td colspan="2" class="td27">secret key:</td></tr>
<tr><td class="vtop rowform"><input type="text" class="txt" value="<?php echo in_plugin_Epay_key; ?>" name="in_plugin_Epay_key"></td></tr>
<tr><td colspan="15"><div class="fixsel"><input type="submit" name="submit" class="btn" value="提交" /></div></td></tr>
</table>
</div>
</form>
<?php } function save(){
        if(!submitcheck('submit')){ShowMessage("表单验证不符，无法提交！",$_SERVER['PHP_SELF'],"infotitle3",3000,1);}
        $way = SafeRequest("in_plugin_Epay_way","post");
        $app = SafeRequest("in_plugin_Epay_app","post");
        $key = SafeRequest("in_plugin_Epay_key","post");
        $str = file_get_contents('source/plugin/App-Epay/config.php');
        $str = preg_replace("/'in_plugin_Epay_way', '(.*?)'/", "'in_plugin_Epay_way', '".$way."'", $str);
        $str = preg_replace("/'in_plugin_Epay_app', '(.*?)'/", "'in_plugin_Epay_app', '".$app."'", $str);
        $str = preg_replace("/'in_plugin_Epay_key', '(.*?)'/", "'in_plugin_Epay_key', '".$key."'", $str);
        $ifile = new iFile('source/plugin/App-Epay/config.php', 'w');
        $ifile->WriteFile($str, 3);
        $search = $way !== 'wx' ? $way !== 'qq' ? array('微信', 'QQ钱包') : array('微信', '支付宝') : array('QQ钱包', '支付宝');
        $replace = $way !== 'wx' ? $way !== 'qq' ? array('支付宝', '支付宝') : array('QQ钱包', 'QQ钱包') : array('微信', '微信');
        $strs = file_get_contents('source/index/sign.php');
        $strs = str_replace($search, $replace, $strs);
        $ifiles = new iFile('source/index/sign.php', 'w');
        $ifiles->WriteFile($strs, 3);
        $strss = file_get_contents('source/index/install.php');
        $strss = str_replace($search, $replace, $strss);
        $ifiless = new iFile('source/index/install.php', 'w');
        $ifiless->WriteFile($strss, 3);
        ShowMessage("恭喜您，设置保存成功！",$_SERVER['HTTP_REFERER'],"infotitle2",1000,1);
}
?>