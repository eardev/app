<?php
include '../../system/config.inc.php';
require_once 'autoload.php';
use Qiniu\Auth;
use Qiniu\Storage\UploadManager;
$auth = new Auth(IN_REMOTEAK, IN_REMOTESK);
$token = $auth->uploadToken(IN_REMOTEBK);
$uploadMgr = new UploadManager();
$data = empty($GLOBALS['HTTP_RAW_POST_DATA']) ? file_get_contents('php://input') : $GLOBALS['HTTP_RAW_POST_DATA'];
if($data){
	$src = IN_ROOT.'./data/tmp/oss_'.date('YmdHis').rand(2,pow(2,24)).'_record.mp3';
        $file = @fopen($src, 'w');
	@fwrite($file, $data);
        @fclose($file);
	$dst = $_SERVER['HTTP_HOST'].'/music/audio';
	$object = $dst.'/'.date('YmdHis').rand(2,pow(2,24)).'.mp3';
	list($ret, $err) = $uploadMgr->putFile($token, $object, $src);
	if($err !== null){
        	echo 'error';
	}else{
        	echo IN_REMOTEDK.$object;
	}
        @unlink($src);
}else{
        echo 'error';
}
?>