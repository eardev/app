<?php

require_once '../../system/config.inc.php';
require_once 'autoload.php';
use Qiniu\Auth;
use Qiniu\Storage\UploadManager;
$auth = new Auth(IN_REMOTEAK, IN_REMOTESK);
$token = $auth->uploadToken(IN_REMOTEBK);
$uploadMgr = new UploadManager();
if(!empty($_FILES)){
        $dst = $_SERVER['HTTP_HOST'].'/'.str_replace('_', '/', $_GET['type']);
        $object = $dst.'/'.date('YmdHis').rand(2,pow(2,24)).'.'.strtolower(trim(substr(strrchr($_FILES['Filedata']['name'],'.'),1)));
        list($ret, $err) = $uploadMgr->putFile($token, $object, $_FILES['Filedata']['tmp_name']);
        if($err !== null){
                echo '0';
        }else{
                echo IN_REMOTEDK.$object;
        }
}
?>