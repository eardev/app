<?php
define('in_plugin_weixin_open', '1');
define('in_plugin_weixin_user', '');
define('in_plugin_weixin_token', '');
?>