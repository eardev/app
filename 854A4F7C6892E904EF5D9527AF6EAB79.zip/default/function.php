<?php
function style_install(){
}
function style_uninstall(){
}
?>