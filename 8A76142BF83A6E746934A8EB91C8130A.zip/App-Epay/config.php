<?php
define('in_plugin_Epay_way', 'wx');
define('in_plugin_Epay_app', 'z3rMQ8ELfIRKpSu');
define('in_plugin_Epay_key', 'vZVYkeUuNradQfb');
$ssl = is_ssl() ? 'https://' : 'http://';
$config = array(
	'sign_type' => 'md5',
	'app_id' => in_plugin_Epay_app,
	'merchant_private_key' => in_plugin_Epay_key,
	'charset' => 'UTF-8',
	'notify_url' => $ssl.$_SERVER['HTTP_HOST'].IN_PATH.'source/plugin/App-Epay/notify.php',
	'MaxQueryRetry' => '10',
	'QueryDuration' => '3'
);
?>