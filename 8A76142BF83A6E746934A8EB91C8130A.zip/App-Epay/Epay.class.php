<?php
class EpayClientAop {
    private static $gateway_url = "https://www.payonline.xin/create.request";
    private static $notify_url;
    private static $sign_type;
    private static $private_key;
    private static $appid;
    private static $sign_data;
    private static $charset = "UTF-8";
    private static $MaxQueryRetry;
    private static $QueryDuration;
    private static $type = 1;
    private $order_no;
    private $mobile = 0;
    private $subject;
    private $order_amount;
    private $time_expire = "5m";
    public function __construct($config) {
        self::$appid = $config['app_id'];
        self::$sign_type = $config['sign_type'];
        self::$private_key = $config['merchant_private_key'];
        self::$charset = $config['charset'];
        self::$MaxQueryRetry = $config['MaxQueryRetry'];
        self::$QueryDuration = $config['QueryDuration'];
        self::$notify_url = $config['notify_url'];
        self::$sign_data = array(
            "app_id" => self::$appid,
            "sign_type" => self::$sign_type,
            "charset" => self::$charset
        );
        if (empty(self::$appid) || trim(self::$appid) == "") {
            throw new Exception("appid should not be NULL!");
        }
        if (empty(self::$private_key) || trim(self::$private_key) == "") {
            throw new Exception("private_key should not be NULL!");
        }
        if (empty(self::$charset) || trim(self::$charset) == "") {
            throw new Exception("charset should not be NULL!");
        }
        if (empty(self::$QueryDuration) || trim(self::$QueryDuration) == "") {
            throw new Exception("QueryDuration should not be NULL!");
        }
        if (empty(self::$gateway_url) || trim(self::$gateway_url) == "") {
            throw new Exception("gateway_url should not be NULL!");
        }
        if (empty(self::$MaxQueryRetry) || trim(self::$MaxQueryRetry) == "") {
            throw new Exception("MaxQueryRetry should not be NULL!");
        }
        if (empty(self::$sign_type) || trim(self::$sign_type) == "") {
            throw new Exception("sign_type should not be NULL");
        }
    }
    public function create($type = "wx") {
        $param["app_id"] = self::$appid;
        $param["charset"] = self::$charset;
        $param["notify"] = self::$notify_url;
        $param["type"] = $type;
        $param["sign"] = $this->setSign();
        $param["mobile"] = $this->mobile;
        $param["order_no"] = $this->order_no;
        $param["order_amount"] = $this->order_amount;
        $param["time_expire"] = $this->time_expire;
        $param["subject"] = $this->subject;
        foreach ($param as $key => $value) {
            if ($value === null || $value === "" || $value === false) {
                throw new Exception("�����������!" . $key . "=>" . $value);
            }
        }
        return $this->request_post(self::$gateway_url, $param);
    }
    public function WxMobilePay() {
        $param["notify"] = self::$notify_url;
        $param["app_id"] = self::$appid;
        $param["type"] = "wx";
        $param["sign"] = $this->setSign();
        $param["mobile"] = $this->mobile;
        $param["order_no"] = $this->order_no;
        $param["order_amount"] = $this->order_amount;
        $param["time_expire"] = $this->time_expire;
        $param["subject"] = $this->subject;
        $url = "https://www.payonline.xin/create.request?";
        foreach ($param as $key => $value) {
            if ($value === null || $value === "" || $value === false) {
                throw new Exception("�����������!" . $key . "=>" . $value);
            } else {
                $url.= (String)$key . "=" . (String)$value . "&";
            }
        }
        $url = substr($url, 0, strlen($url) - 1);
        return $url;
    }
    public function acceptNotify($config) {
        $state = $_POST["state"];
        $data["out_trade_no"] = $_POST["order_no"];
        $data["order_amount"] = $_POST["order_amount"];
        $sign = md5("app_id=" . $config["app_id"] . "&order_amount=" . $data["order_amount"] . "&order_no=" . $data["out_trade_no"] . "&sign_type=md5&state=SUCCESS&key=" . $config["merchant_private_key"]);
        if ($state == "SUCCESS" && $sign == $_POST["sign"]) {
            return $data;
        } else {
            throw new Exception("֧��ʧ�ܣ�");
        }
    }
    public function getAllparam() {
        $param["app_id"] = self::$appid;
        $param["charset"] = self::$charset;
        $param["notify"] = self::$notify_url;
        $param["sign"] = $this->setSign();
        $param["mobile"] = $this->mobile;
        $param["order_no"] = $this->order_no;
        $param["order_amount"] = $this->order_amount;
        $param["time_expire"] = $this->time_expire;
        $param["subject"] = $this->subject;
        return $param;
    }
    protected function setSign() {
        $sign = "";
        self::$sign_data["order_no"] = $this->order_no;
        self::$sign_data["order_amount"] = $this->order_amount;
        ksort(self::$sign_data);
        foreach (self::$sign_data as $key => $value) {
            if ($key != "sign") {
                $sign.= $key . "=" . $value . "&";
            }
        }
        $sign.= "key=" . self::$private_key;
        return md5($sign);
    }
    public function setWayUrl($url) {
        self::$gateway_url = $url;
    }
    public function setTimeOut($time) {
        $this->time_expire = $time;
    }
    public function setOutTradeNo($order_sn) {
        $this->order_no = $order_sn;
    }
    public function setTradeAmount($order_amount) {
        $this->order_amount = $order_amount;
    }
    public function setNotifyUrl($notify) {
        self::$notify_url = $notify;
    }
    public function setCharset($charset) {
        self::$charset = $charset;
    }
    public function setSubject($subject) {
        $this->subject = $subject;
    }
    public function setMobile($mobile) {
        $this->mobile = $mobile;
        if (!is_numeric($this->mobile)) {
            throw new Exception("�ֻ������������!");
        }
    }
    public function request_post($url = '', $data = '') {
        $curl = curl_init();
        curl_setopt($curl, CURLOPT_URL, $url);
        curl_setopt($curl, CURLOPT_SSL_VERIFYPEER, 0);
        curl_setopt($curl, CURLOPT_SSL_VERIFYHOST, 1);
        curl_setopt($curl, CURLOPT_USERAGENT, $_SERVER['HTTP_USER_AGENT']);
        curl_setopt($curl, CURLOPT_FOLLOWLOCATION, 1);
        curl_setopt($curl, CURLOPT_AUTOREFERER, 1);
        curl_setopt($curl, CURLOPT_POST, 1);
        curl_setopt($curl, CURLOPT_POSTFIELDS, $data);
        curl_setopt($curl, CURLOPT_TIMEOUT, 30);
        curl_setopt($curl, CURLOPT_HEADER, 0);
        curl_setopt($curl, CURLOPT_RETURNTRANSFER, 1);
        $tmpInfo = curl_exec($curl);
        if (curl_errno($curl)) {
            echo 'Errno' . curl_error($curl);
        }
        curl_close($curl);
        return $tmpInfo;
    }
}
?>