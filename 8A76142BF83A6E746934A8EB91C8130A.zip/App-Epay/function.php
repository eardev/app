<?php
function plugin_install(){
	copy('static/index/lib.js', 'source/plugin/App-Epay/lib.js');
	$str = file_get_contents('static/index/lib.js');
	$str = str_replace('pack/weixin/buy', 'plugin/App-Epay/buy', $str);
	$str = str_replace('pack/weixin/pay', 'plugin/App-Epay/pay', $str);
	$ifile = new iFile('static/index/lib.js', 'w');
	$ifile->WriteFile($str, 3);
	copy('source/index/sign.php', 'source/plugin/App-Epay/sign.php');
	$strs = file_get_contents('source/index/sign.php');
	$strs = str_replace('static/index/lib.js', 'static/index/lib.js?v=<?php echo time(); ?>', $strs);
	$ifiles = new iFile('source/index/sign.php', 'w');
	$ifiles->WriteFile($strs, 3);
	copy('source/index/install.php', 'source/plugin/App-Epay/install.php');
	$strss = file_get_contents('source/index/install.php');
	$strss = str_replace('static/index/lib.js', 'static/index/lib.js?v=<?php echo time(); ?>', $strss);
	$ifiless = new iFile('source/index/install.php', 'w');
	$ifiless->WriteFile($strss, 3);
}
function plugin_uninstall(){
	$str = file_get_contents('source/plugin/App-Epay/lib.js');
	$ifile = new iFile('static/index/lib.js', 'w');
	$ifile->WriteFile($str, 3);
	$strs = file_get_contents('source/plugin/App-Epay/sign.php');
	$ifiles = new iFile('source/index/sign.php', 'w');
	$ifiles->WriteFile($strs, 3);
	$strss = file_get_contents('source/plugin/App-Epay/install.php');
	$ifiless = new iFile('source/index/install.php', 'w');
	$ifiless->WriteFile($strss, 3);
}
?>