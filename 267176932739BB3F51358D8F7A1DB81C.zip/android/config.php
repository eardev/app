<?php
define('in_plugin_android_open', '1');
define('in_plugin_android_apk', 'http://'.$_SERVER['HTTP_HOST'].IN_PATH.'source/plugin/android/api/erduo.apk');
define('in_plugin_android_guide', 'http://'.$_SERVER['HTTP_HOST'].IN_PATH.'source/plugin/android/api/guide.jpg');
define('in_plugin_android_list1id', '1');
define('in_plugin_android_list1cover', 'http://'.$_SERVER['HTTP_HOST'].IN_PATH.'source/plugin/android/api/list1.jpg');
define('in_plugin_android_list2id', '2');
define('in_plugin_android_list2cover', 'http://'.$_SERVER['HTTP_HOST'].IN_PATH.'source/plugin/android/api/list2.jpg');
define('in_plugin_android_list3id', '3');
define('in_plugin_android_list3cover', 'http://'.$_SERVER['HTTP_HOST'].IN_PATH.'source/plugin/android/api/list3.jpg');
define('in_plugin_android_list4id', '4');
define('in_plugin_android_list4cover', 'http://'.$_SERVER['HTTP_HOST'].IN_PATH.'source/plugin/android/api/list4.jpg');
define('in_plugin_android_list5id', '5');
define('in_plugin_android_list5cover', 'http://'.$_SERVER['HTTP_HOST'].IN_PATH.'source/plugin/android/api/list5.jpg');
?>