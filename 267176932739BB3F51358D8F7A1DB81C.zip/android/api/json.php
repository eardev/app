<?php
include '../../../system/db.class.php';
include '../config.php';
header("Expires: Mon, 26 Jul 1997 05:00:00 GMT");
header("Cache-Control: no-cache, must-revalidate");
header("Pragma: no-cache");
header("Content-type: text/html;charset=".IN_CHARSET);
$method = SafeRequest("method","get");
if($method == 'guide'){
        echo '{"text":"'.IN_NAME.'","img":"'.in_plugin_android_guide.'"}';
}elseif($method == 'list'){
        $type = SafeRequest("type","get");
        $size = intval(SafeRequest("size","get"));
        $offset = intval(SafeRequest("offset","get"));
        $str = '{"song_list":[';
        if(is_numeric($type)){
                if($type == 1){
                        $cid = in_plugin_android_list1id;
                        $pic = in_plugin_android_list1cover;
                }elseif($type == 2){
                        $cid = in_plugin_android_list2id;
                        $pic = in_plugin_android_list2cover;
                }elseif($type == 3){
                        $cid = in_plugin_android_list3id;
                        $pic = in_plugin_android_list3cover;
                }elseif($type == 4){
                        $cid = in_plugin_android_list4id;
                        $pic = in_plugin_android_list4cover;
                }elseif($type == 5){
                        $cid = in_plugin_android_list5id;
                        $pic = in_plugin_android_list5cover;
                }
                $count = $GLOBALS['db']->num_rows($GLOBALS['db']->query("select count(*) from ".tname('music')." where in_passed=0 and in_classid=".$cid));
                $query = $GLOBALS['db']->query("select * from ".tname('music')." where in_passed=0 and in_classid=".$cid." order by in_addtime desc LIMIT ".$offset.",".$size);
                while($row = $GLOBALS['db']->fetch_array($query)){
                        $scover = geturl(getfield('singer', 'in_cover', 'in_id', $row['in_singerid']), 'cover');
                        $album = getfield('special', 'in_name', 'in_id', $row['in_specialid'], 'δ֪ר��');
                        $artist = getfield('singer', 'in_name', 'in_id', $row['in_singerid'], 'δ֪����');
                        $str .= '{"pic_url":"'.$scover.'","song_id":"'.$row['in_id'].'","title":"'.$row['in_name'].'","ting_uid":"'.$row['in_singerid'].'","album_title":"'.$album.'","artist_name":"'.$artist.'"},';
                }
                $str = str_replace('},],', '}],', $str.'],');
                $str = $str.'"billboard":{"update_date":"'.$count.'","name":"'.getfield('class', 'in_name', 'in_id', $cid).'","comment":"ʵʱչ��'.getfield('class', 'in_name', 'in_id', $cid).'���¸���","pic_link":"'.$pic.'"}}';
        }else{
                $text = $type == 'new' ? '�¸��' : '�ȸ��';
                $sort = $type == 'new' ? 'in_addtime' : 'in_hits';
                $pic = 'http://'.$_SERVER['HTTP_HOST'].IN_PATH.'source/plugin/android/api/'.$type.'.jpg';
                $count = $GLOBALS['db']->num_rows($GLOBALS['db']->query("select count(*) from ".tname('music')." where in_passed=0"));
                $query = $GLOBALS['db']->query("select * from ".tname('music')." where in_passed=0 order by ".$sort." desc LIMIT ".$offset.",".$size);
                while($row = $GLOBALS['db']->fetch_array($query)){
                        $scover = geturl(getfield('singer', 'in_cover', 'in_id', $row['in_singerid']), 'cover');
                        $album = getfield('special', 'in_name', 'in_id', $row['in_specialid'], 'δ֪ר��');
                        $artist = getfield('singer', 'in_name', 'in_id', $row['in_singerid'], 'δ֪����');
                        $str .= '{"pic_url":"'.$scover.'","song_id":"'.$row['in_id'].'","title":"'.$row['in_name'].'","ting_uid":"'.$row['in_singerid'].'","album_title":"'.$album.'","artist_name":"'.$artist.'"},';
                }
                $str = str_replace('},],', '}],', $str.'],');
                $str = $str.'"billboard":{"update_date":"'.$count.'","name":"'.$text.'","comment":"ʵʱչ��'.$text.'���и���","pic_link":"'.$pic.'"}}';
        }
        echo $str;
}elseif($method == 'search'){
        $query = SafeSql(convert_xmlcharset(stripslashes(SafeRequest("query","get",1))));
        $str = '{"song":[';
        $result = $GLOBALS['db']->query("select * from ".tname('music')." where in_passed=0 and in_name like '%".$query."%' order by in_hits desc LIMIT 0,100");
        while($row = $GLOBALS['db']->fetch_array($result)){
                $scover = geturl(getfield('singer', 'in_cover', 'in_id', $row['in_singerid']), 'cover');
                $album = getfield('special', 'in_name', 'in_id', $row['in_specialid'], 'δ֪ר��');
                $artist = getfield('singer', 'in_name', 'in_id', $row['in_singerid'], 'δ֪����');
                $str .= '{"pic_url":"'.$scover.'","songname":"'.$row['in_name'].'","ting_uid":"'.$row['in_singerid'].'","album_title":"'.$album.'","artistname":"'.$artist.'","songid":"'.$row['in_id'].'"},';
        }
        echo str_replace('},]}', '}]}', $str.']}');
}elseif($method == 'singer'){
        $tinguid = SafeRequest("tinguid","get");
        echo '{"style":"'.getfield('singer_class', 'in_name', 'in_id', getfield('singer', 'in_classid', 'in_id', $tinguid), '�������').'","url":"http://'.$_SERVER['HTTP_HOST'].getlink($tinguid, 'singer').'","intro":"'.getfield('singer', 'in_intro', 'in_id', $tinguid, '���޼��').'","avatar_s1000":"'.geturl(getfield('singer', 'in_cover', 'in_id', $tinguid), 'cover').'","name":"'.getfield('singer', 'in_name', 'in_id', $tinguid, 'δ֪����').'","nick":"'.getfield('singer', 'in_nick', 'in_id', $tinguid, '���ޱ���').'"}';
}elseif($method == 'lyric'){
        $songid = SafeRequest("songid","get");
        $lyric = geturl(getfield('music', 'in_lyric', 'in_id', $songid), 'lyric');
        $content = detect_encoding(@file_get_contents($lyric));
        echo '{"lrcContent":"'.$content.'"}';
}elseif($method == 'player'){
        $songid = SafeRequest("songid","get");
        $audio = getfield('music', 'in_audio', 'in_id', $songid);
	if(preg_match('/mp3$/', $audio) && is_file(IN_ROOT.$audio)){
		include_once IN_ROOT.'./source/pack/mp3/class.mp3.php';
                $MP3 = new MP3(IN_ROOT.$audio);
                $Meta = $MP3->get_metadata();
		$duration = $Meta['Length'];
	}else{
		$duration = 0;
	}
        echo '{"bitrate":{"file_duration":"'.$duration.'","file_link":"'.geturl($audio).'","file_url":"http://'.$_SERVER['HTTP_HOST'].getlink($songid, 'music').'"}}';
}
?>