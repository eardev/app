<?php
if(!defined('IN_ROOT')){exit('Access denied');}
include 'source/admincp/include/function.php';
Administrator(1);
@set_time_limit(0);
ini_set('memory_limit', '-1');
?>
<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=<?php echo IN_CHARSET; ?>" />
<meta http-equiv="x-ua-compatible" content="ie=7" />
<title>邮件群发</title>
<link href="<?php echo IN_PATH; ?>static/admincp/css/main.css" rel="stylesheet" type="text/css" />
<script type="text/javascript">
function mail_sending(type, sec, title, content, ing, num, no, yes){
        var percent = Math.round(ing * 100 / num);
        document.getElementById("no").innerHTML = no;
        document.getElementById("yes").innerHTML = yes;
        document.getElementById("num").innerHTML = num;
        document.getElementById("progressbar").style.width = percent + "%";
        if(percent > 0){
                document.getElementById("progressbar").innerHTML = percent + "%";
                document.getElementById("progressText").innerHTML = "";
        }else{
                document.getElementById("progressText").innerHTML = percent + "%";
        }
        if(ing < num){
                setTimeout("location.href='<?php echo $_SERVER['PHP_SELF']; ?>?type=" + type + "&sec=" + sec + "&title=" + title + "&content=" + content + "&ing=" + (Number(ing) + 1) + "&no=" + no + "&yes=" + yes + "';", sec * 1000);
        }
}
</script>
</head>
<body>
<?php
        echo "<div class=\"container\"><h3>Ear Music 提示</h3><div class=\"infobox\"><br />";
        echo "<table class=\"tb tb2\" style=\"border:1px solid #09C\">";
        echo "<tr><td>发送失败</td><td><div id=\"no\">0</div></td></tr>";
        echo "<tr><td>成功送达</td><td><div id=\"yes\">0</div></td></tr>";
        echo "<tr><td>邮件封数</td><td><div id=\"num\">0</div></td></tr>";
        echo "<tr><td>群发进度</td><td><div id=\"progressbar\" style=\"float:left;width:1px;text-align:center;color:#FFFFFF;background-color:#09C\"></div><div id=\"progressText\" style=\"float:left\">0%</div></td></tr>";
        echo "</table>";
        echo "<br /><p class=\"margintop\"><input type=\"button\" class=\"btn\" value=\"撤销\" onclick=\"history.go(-1);\"></p><br /></div></div>";
        global $db;
        $type = SafeRequest("type","get");
        $sec = SafeRequest("sec","get");
        $title = SafeRequest("title","get");
        $content = SafeRequest("content","get");
        $ing = isset($_GET['ing']) ? SafeRequest("ing","get") : 1;
        if($type == 1){
                $num = $db->num_rows($db->query("select count(*) from ".tname('user')." where in_grade=1"));
                $row = $db->getrow("select * from ".tname('user')." where in_grade=1 order by in_logintime asc LIMIT ".($ing - 1).",1");
        }elseif($type == 2){
                $num = $db->num_rows($db->query("select count(*) from ".tname('user')." where in_isstar=1"));
                $row = $db->getrow("select * from ".tname('user')." where in_isstar=1 order by in_logintime asc LIMIT ".($ing - 1).",1");
        }elseif($type == 3){
                $num = $db->num_rows($db->query("select count(*) from ".tname('user')." where in_ismail=1"));
                $row = $db->getrow("select * from ".tname('user')." where in_ismail=1 order by in_logintime asc LIMIT ".($ing - 1).",1");
        }else{
                $num = $db->num_rows($db->query("select count(*) from ".tname('user')));
                $row = $db->getrow("select * from ".tname('user')." order by in_logintime asc LIMIT ".($ing - 1).",1");
        }
	include_once 'source/pack/mail/mail.php';
	$mail = new PHPMailer();
	$mail->IsSMTP();
	$mail->CharSet = 'utf-8';
	$mail->SMTPAuth = true;
	$mail->Host = IN_MAILSMTP;
	$mail->Username = IN_MAIL;
	$mail->Password = IN_MAILPW;
	$mail->From = IN_MAIL;
	$mail->FromName = convert_xmlcharset(IN_NAME, 2);
	$mail->Subject = convert_xmlcharset($title, 2);
	$mail->AddAddress($row['in_mail'], convert_xmlcharset($row['in_username'], 2));
	$html = convert_xmlcharset($content, 2);
	$mail->MsgHTML($html);
	$mail->IsHTML(true);
        $no = isset($_GET['no']) ? SafeRequest("no","get") : 0;
        $yes = isset($_GET['yes']) ? SafeRequest("yes","get") : 0;
	if(!$mail->Send()){
		echo "<script type=\"text/javascript\">mail_sending($type, $sec, '$title', '$content', $ing, $num, ".($no + 1).", $yes);</script>";
	}else{
		echo "<script type=\"text/javascript\">mail_sending($type, $sec, '$title', '$content', $ing, $num, $no, ".($yes + 1).");</script>";
	}
?>
</body>
</html>