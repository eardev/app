<?php
if(!defined('IN_ROOT')){exit('Access denied');}
include 'source/admincp/include/function.php';
Administrator(1);
$setup=SafeRequest("setup","get");
?>
<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=<?php echo IN_CHARSET; ?>" />
<meta http-equiv="x-ua-compatible" content="ie=7" />
<title>邮件群发</title>
<link href="<?php echo IN_PATH; ?>static/admincp/css/main.css" rel="stylesheet" type="text/css" />
<link href="<?php echo IN_PATH; ?>static/pack/asynctips/asynctips.css" rel="stylesheet" type="text/css" />
<script type="text/javascript" src="<?php echo IN_PATH; ?>static/pack/asynctips/jquery.min.js"></script>
<script type="text/javascript" src="<?php echo IN_PATH; ?>static/pack/asynctips/asyncbox.v1.4.5.js"></script>
<script type="text/javascript">
function CheckForm(){
        if(document.form.in_sec.value==""){
            asyncbox.tips("发送间隔不能为空，请填写！", "wait", 1000);
            document.form.in_sec.focus();
            return false;
        }
        else if(document.form.in_title.value==""){
            asyncbox.tips("邮件标题不能为空，请填写！", "wait", 1000);
            document.form.in_title.focus();
            return false;
        }
        else if(document.form.in_content.value==""){
            asyncbox.tips("邮件内容不能为空，请填写！", "wait", 1000);
            document.form.in_content.focus();
            return false;
        }
        else {
            return true;
        }
}
</script>
</head>
<body>
<?php
switch($setup){
	case 'ing':
		mail_sending();
		break;
	default:
		mail_send();
		break;
	}
?>
</body>
</html>
<?php function mail_send(){ ?>
<div class="container">
<script type="text/javascript">parent.document.title = 'Ear Music Board 管理中心 - 邮件群发';if(parent.$('admincpnav')) parent.$('admincpnav').innerHTML='邮件群发';</script>
<div class="floattop"><div class="itemtitle"><h3>邮件群发</h3></div></div><div class="floattopempty"></div>
<form action="<?php echo $_SERVER['PHP_SELF']; ?>?setup=ing" method="post" name="form">
<table class="tb tb2">
<tr><td>发送群体：<select name="in_type" id="in_type"><option value="0">所有用户</option><option value="1">绿钻会员</option><option value="2">明星认证</option><option value="3">验证用户</option></select></td></tr>
<tr><td>发送间隔：<input type="text" class="txt" value="3" name="in_sec" id="in_sec" onkeyup="this.value=this.value.replace(/[^\d]/g,'')" onbeforepaste="clipboardData.setData('text',clipboardData.getData('text').replace(/[^\d]/g,''))">秒</td></tr>
<tr><td class="longtxt">邮件标题：<input type="text" class="txt" name="in_title" id="in_title"></td></tr>
<tr><td><div style="height:100px;line-height:100px;float:left;">邮件内容：</div><textarea rows="6" cols="50" id="in_content" name="in_content" style="width:400px;height:100px;"></textarea></td></tr>
</table>
<table class="tb tb2">
<tr><td><input type="submit" class="btn" value="开始群发" onclick="return CheckForm();" /></td></tr>
</table>
</form>
</div>
<?php } function mail_sending(){
        if(IN_MAILOPEN == 1){
                $type = SafeRequest("in_type","post");
                $sec = SafeRequest("in_sec","post");
                $title = SafeRequest("in_title","post");
                $content = SafeRequest("in_content","post");
        }else{
                ShowMessage("请先在 全局->站点信息->基本设置->邮件服务开关 选择“开启”","history.back(1);","infotitle1",3000,2);
        }
        echo "<script type=\"text/javascript\">location.href='".IN_PATH."plugin.php/mail_list/entry/?type=$type&sec=$sec&title=$title&content=$content';</script>";
}
?>