<?php
include '../../system/db.class.php';
include '../../system/user.php';
include 'config.php';
header("Expires: Mon, 26 Jul 1997 05:00:00 GMT");
header("Cache-Control: no-cache, must-revalidate");
header("Pragma: no-cache");
header("Content-type: text/html;charset=".IN_CHARSET);
global $userlogined,$erduo_in_userid,$erduo_in_username,$erduo_in_userpassword,$erduo_in_rank,$erduo_in_points;
$ac=SafeRequest("ac","get");
if($ac == 'credit'){
	$password = substr(md5(unescape(SafeRequest("pwd","get"))), 8, 16);
	$type = SafeRequest("type","get");
	$num = intval(SafeRequest("num","get"));
	if(!$userlogined){
		echo 'return_1';
	}elseif($password !== $erduo_in_userpassword){
		echo 'return_2';
	}else{
	        if($type){
		        $points = $num > 0 ? ceil($num / in_plugin_bank_points_rank) : 0;
		        $rank = $num > 0 ? $num : 0;
		        $points <= $erduo_in_points or exit('return_3');
		        updatetable('user', array('in_points' => ($erduo_in_points - $points),'in_rank' => ($erduo_in_rank + $rank)), array('in_userid' => $erduo_in_userid));
	        }else{
		        $rank = $num > 0 ? ($num * in_plugin_bank_points_rank) : 0;
		        $points = $num > 0 ? $num : 0;
		        $rank <= $erduo_in_rank or exit('return_4');
		        updatetable('user', array('in_points' => ($erduo_in_points + $points),'in_rank' => ($erduo_in_rank - $rank)), array('in_userid' => $erduo_in_userid));
	        }
		echo 'return_5';
	}
}elseif($ac == 'cash'){
	$password = substr(md5(unescape(SafeRequest("pwd","get"))), 8, 16);
	$rmb = intval(SafeRequest("rmb","get"));
	$account = unescape(SafeRequest("account","get"));
	$type = unescape(SafeRequest("type","get"));
	$nick = unescape(SafeRequest("nick","get"));
	if(!$userlogined){
		echo 'return_1';
	}elseif($password !== $erduo_in_userpassword){
		echo 'return_2';
	}elseif(!in_plugin_bank_rmb){
		echo 'return_3';
	}elseif($rmb > 0){
		$points = $rmb * in_plugin_bank_rmb_points;
		$points <= $erduo_in_points or exit('return_4');
		inserttable('plugin_bank', array('in_uid' => $erduo_in_userid,'in_uname' => $erduo_in_username,'in_nick' => $nick,'in_type' => $type,'in_account' => $account,'in_points' => $points,'in_money' => $rmb,'in_status' => 0,'in_addtime' => date('Y-m-d H:i:s')), 1);
		updatetable('user', array('in_points' => ($erduo_in_points - $points)), array('in_userid' => $erduo_in_userid));
		echo 'return_5';
	}
}
?>