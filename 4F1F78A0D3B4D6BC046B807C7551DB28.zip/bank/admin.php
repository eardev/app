<?php
if(!defined('IN_ROOT')){exit('Access denied');}
include 'source/plugin/bank/config.php';
include 'source/admincp/include/function.php';
Administrator(1);
$action=SafeRequest("action","get");
?>
<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=<?php echo IN_CHARSET; ?>" />
<meta http-equiv="x-ua-compatible" content="ie=7" />
<title>��������</title>
<link href="<?php echo IN_PATH; ?>static/admincp/css/main.css" rel="stylesheet" type="text/css" />
<script type="text/javascript" src="<?php echo IN_PATH; ?>static/pack/layer/jquery.js"></script>
<script type="text/javascript" src="<?php echo IN_PATH; ?>static/pack/layer/confirm-lib.js"></script>
<script type="text/javascript">
layer.use('confirm-ext.js');
function s(){
        var k=document.getElementById("search").value;
        if(k==""){
                layer.msg('������Ҫ��ѯ�Ĺؼ��ʣ�', 1, 0);
                document.getElementById("search").focus();
                return false;
        }else{
                document.btnsearch.submit();
        }
}
function change(type){
        if(type==1){
            document.getElementById("bank_open").style.display='';
        }else{
            document.getElementById("bank_open").style.display='none';
        }
}
function cash_msg(href){
	$.layer({
		shade: [0],
		area: ['auto', 'auto'],
		dialog: {
			msg: 'ȷ����ת�˸��Է���',
			btns: 2,
			type: 4,
			btn: ['ȷ��', 'ȡ��'],
			yes: function() {
				location.href = href;
			},
			no: function() {
				layer.msg('��ȡ������', 1, 0);
			}
		}
	});
}
</script>
</head>
<body>
<script type="text/javascript">parent.document.title = 'Ear Music Board �������� - ��������';if(parent.$('admincpnav')) parent.$('admincpnav').innerHTML='��������';</script>
<?php
switch($action){
	case 'keyword':
		$key=SafeRequest("key","get");
		$sql="select * from ".tname('plugin_bank')." where in_uname like '%".$key."%' or in_account like '%".$key."%' order by in_addtime desc";
		cash($sql,20);
		break;
	case 'cash':
		$status=SafeRequest("status","get");
		if(!is_numeric($status)){
		        $sql="select * from ".tname('plugin_bank')." order by in_addtime desc";
		}else{
		        $sql="select * from ".tname('plugin_bank')." where in_status=".intval($status)." order by in_addtime desc";
		}
		cash($sql,20);
		break;
	case 'status':
		status();
		break;
	case 'save':
		save();
		break;
	default:
		main();
		break;
	}
?>
</body>
</html>
<?php
function cash($sql,$size){
	global $db;
	$Arr=getpagerow($sql,$size);
	$result=$Arr[1];
	$count=$Arr[2];
?>
<div class="container">
<div class="floattop"><div class="itemtitle"><h3>���ֹ���</h3><ul class="tab1">
<li><a href="<?php echo $_SERVER['PHP_SELF']; ?>"><span>��������</span></a></li>
<li class="current"><a href="<?php echo $_SERVER['PHP_SELF']; ?>?action=cash"><span>���ֹ���</span></a></li>
</ul></div></div><div class="floattopempty"></div>
<table class="tb tb2">
<tr><th class="partition">������ʾ</th></tr>
<tr><td class="tipsblock"><ul>
<li>�������������û��������˻��ȹؼ��ʽ�������</li>
</ul></td></tr>
</table>
<table class="tb tb2">
<form name="btnsearch" method="get" action="<?php echo $_SERVER['PHP_SELF']; ?>">
<tr><td>
<input type="hidden" name="action" value="keyword">
�ؼ��ʣ�<input class="txt" x-webkit-speech type="text" name="key" id="search" value="" />
<select onchange="location.href=this.options[this.selectedIndex].value;">
<option value="<?php echo $_SERVER['PHP_SELF']; ?>?action=cash">����״̬</option>
<option value="<?php echo $_SERVER['PHP_SELF']; ?>?action=cash&status=0"<?php if(isset($_GET['status']) && $_GET['status']==0){echo " selected";} ?>>������</option>
<option value="<?php echo $_SERVER['PHP_SELF']; ?>?action=cash&status=1"<?php if(isset($_GET['status']) && $_GET['status']==1){echo " selected";} ?>>����</option>
<option value="<?php echo $_SERVER['PHP_SELF']; ?>?action=cash&status=2"<?php if(isset($_GET['status']) && $_GET['status']==2){echo " selected";} ?>>�˻�</option>
</select>
<input type="button" value="����" class="btn" onclick="s()" />
</td></tr>
</form>
</table>
<table class="tb tb2">
<tr class="header">
<th>�˻���Ϣ</th>
<th>���</th>
<th>���</th>
<th>״̬</th>
<th>�����û�</th>
<th>����ʱ��</th>
<th>�༭����</th>
</tr>
<?php
if($count==0){
?>
<tr><td colspan="2" class="td27">û�����ּ�¼</td></tr>
<?php
}
if($result){
while($row = $db->fetch_array($result)){
?>
<tr class="hover">
<td><?php echo $row['in_type'].'['.$row['in_nick'].':'.$row['in_account'].']'; ?></td>
<td><b><?php echo $row['in_money']; ?></b></td>
<td><?php echo $row['in_points']; ?></td>
<td><?php echo $row['in_status'] > 0 ? $row['in_status'] > 1 ? '�˻�' : '����' : '<em class="lightnum">������</em>'; ?></td>
<td><a href="<?php echo $_SERVER['PHP_SELF']; ?>?action=keyword&key=<?php echo $row['in_uname']; ?>" class="act"><?php echo ReplaceStr($row['in_uname'],SafeRequest("key","get"),"<em class=\"lightnum\">".SafeRequest("key","get")."</em>"); ?></a></td>
<td><?php if(date('Y-m-d',strtotime($row['in_addtime']))==date('Y-m-d')){echo "<em class=\"lightnum\">".datetime($row['in_addtime'])."</em>";}else{echo datetime($row['in_addtime']);} ?></td>
<?php if($row['in_status'] > 0){ ?>
<td>�Ѵ���</td>
<?php }else{ ?>
<td><a class="act" style="cursor:pointer" onclick="cash_msg('<?php echo $_SERVER['PHP_SELF']; ?>?action=status&id=<?php echo $row['in_id']; ?>&status=1');">����</a><a class="act" style="cursor:pointer" onclick="layer.prompt({title:'�ܾ�����',type:3},function(msg){location.href='<?php echo $_SERVER['PHP_SELF']; ?>?action=status&id=<?php echo $row['in_id']; ?>&msg=' + msg + '&status=2';});">�˻�</a></td>
<?php } ?>
</tr>
<?php
}
}
?>
</table>
<table class="tb tb2">
<?php echo $Arr[0]; ?>
</table>
</div>
<?php } function main(){ ?>
<form method="post" action="<?php echo $_SERVER['PHP_SELF']; ?>?action=save">
<div class="container">
<div class="floattop"><div class="itemtitle"><h3>��������</h3><ul class="tab1">
<li class="current"><a href="<?php echo $_SERVER['PHP_SELF']; ?>"><span>��������</span></a></li>
<li><a href="<?php echo $_SERVER['PHP_SELF']; ?>?action=cash"><span>���ֹ���</span></a></li>
</ul></div></div><div class="floattopempty"></div>
<table class="tb tb2">
<tr><th colspan="15" class="partition">�������</th></tr>
<tr><td colspan="2" class="td27">�������:</td></tr>
<tr><td class="vtop rowform">
<ul>
<?php if(in_plugin_bank_open==1){echo "<li class=\"checked\">";}else{echo "<li>";} ?><input class="radio" type="radio" name="in_plugin_bank_open" value="1" onclick="change(1);"<?php if(in_plugin_bank_open==1){echo " checked";} ?>>&nbsp;����</li>
<?php if(in_plugin_bank_open==0){echo "<li class=\"checked\">";}else{echo "<li>";} ?><input class="radio" type="radio" name="in_plugin_bank_open" value="0" onclick="change(0);"<?php if(in_plugin_bank_open==0){echo " checked";} ?>>&nbsp;�ر�</li>
</ul>
</td><td class="vtop tips2">�رպ��޷����ʸò��</td></tr>
<tbody class="sub" id="bank_open"<?php if(in_plugin_bank_open<>1){echo " style=\"display:none;\"";} ?>>
<tr><td colspan="2" class="td27">������ֻ��ʻ���:</td></tr>
<tr><td class="vtop rowform"><input type="text" class="txt" value="<?php echo in_plugin_bank_rmb_points; ?>" name="in_plugin_bank_rmb_points" onkeyup="this.value=this.value.replace(/[^\d]/g,'')" onbeforepaste="clipboardData.setData('text',clipboardData.getData('text').replace(/[^\d]/g,''))"></td><td class="vtop tips2"><ul><?php if(in_plugin_bank_rmb){echo "<li class=\"checked\">";}else{echo "<li>";} ?>���/ÿԪ<input class="checkbox" type="checkbox" name="in_plugin_bank_rmb" id="bank_rmb" value="1"<?php if(in_plugin_bank_rmb){echo " checked";} ?>><label for="bank_rmb">����</label></li></ul></td></tr>
<tr><td colspan="2" class="td27">���ֶһ����ʻ���:</td></tr>
<tr><td class="vtop rowform"><input type="text" class="txt" value="<?php echo in_plugin_bank_points_rank; ?>" name="in_plugin_bank_points_rank" onkeyup="this.value=this.value.replace(/[^\d]/g,'')" onbeforepaste="clipboardData.setData('text',clipboardData.getData('text').replace(/[^\d]/g,''))"></td><td class="vtop tips2">����/ÿ���</td></tr>
</tbody>
<tr><td colspan="15"><div class="fixsel"><input type="submit" name="submit" class="btn" value="�ύ" /></div></td></tr>
</table>
</div>
</form>
<?php } function status(){
	global $db;
	$id=intval(SafeRequest("id","get"));
	$status=intval(SafeRequest("status","get"));
	if($status==2){
		$msg=SafeRequest("msg","get");
		$row=$db->getrow("select * from ".tname('plugin_bank')." where in_id=".$id);
		$db->query("update ".tname('user')." set in_points=in_points+".$row['in_points']." where in_userid=".$row['in_uid']);
		$setarr = array(
			'in_uid' => 0,
			'in_uname' => 'ϵͳ�û�',
			'in_uids' => $row['in_uid'],
			'in_unames' => $row['in_uname'],
			'in_content' => '[�����˻�]'.$msg,
			'in_isread' => 0,
			'in_addtime' => date('Y-m-d H:i:s')
		);
		inserttable('message', $setarr, 1);
	}
	$sql="update ".tname('plugin_bank')." set in_status=".$status." where in_id=".$id;
	if($db->query($sql)){
		ShowMessage("��ϲ�������ִ����ɹ���",$_SERVER['HTTP_REFERER'],"infotitle2",3000,1);
	}
} function save(){
        if(!submitcheck('submit')){ShowMessage("������֤�������޷��ύ��",$_SERVER['PHP_SELF'],"infotitle3",3000,1);}
        $str=file_get_contents('source/plugin/bank/config.php');
        $str=preg_replace("/'in_plugin_bank_open', '(.*?)'/", "'in_plugin_bank_open', '".SafeRequest("in_plugin_bank_open","post")."'", $str);
        $str=preg_replace("/'in_plugin_bank_rmb', '(.*?)'/", "'in_plugin_bank_rmb', '".(SafeRequest("in_plugin_bank_rmb","post")==1 ? 1 : 0)."'", $str);
        $str=preg_replace("/'in_plugin_bank_rmb_points', '(.*?)'/", "'in_plugin_bank_rmb_points', '".SafeRequest("in_plugin_bank_rmb_points","post")."'", $str);
        $str=preg_replace("/'in_plugin_bank_points_rank', '(.*?)'/", "'in_plugin_bank_points_rank', '".SafeRequest("in_plugin_bank_points_rank","post")."'", $str);
	$ifile = new iFile('source/plugin/bank/config.php', 'w');
	$ifile->WriteFile($str, 3);
	ShowMessage("��ϲ�������ñ���ɹ���",$_SERVER['HTTP_REFERER'],"infotitle2",1000,1);
}
?>