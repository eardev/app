<?php
function getstylepage($sqlstr, $pagesok){
	global $db;
	$url = $_SERVER['QUERY_STRING'];
	if(stristr($url, '&pages')){
		$url = preg_replace('/&pages=([\S]+?)$/', '', $url);
	}
	$page = intval(SafeRequest("pages","get"));
	$pages = $page <= 0 ? 1 : $page;
 	$nums = $db->num_rows($db->query(str_replace('*', 'count(*)', $sqlstr)));
	$num = $nums == 0 ? 1 : $nums;
  	$pagejs = ceil($num / $pagesok);
	if($pages > $pagejs){
		$pages = $pagejs;
	}
	$result = $db->query($sqlstr." LIMIT ".$pagesok * ($pages - 1).",".$pagesok);
 	$str = '';
	if($nums > 0){
 		$str .= "<a>��<strong>".$nums."</strong>������</a> ";
		if($pages == 1){
			$str .= "<a>��ҳ</a> ";
		}else{
			$str .= "<a style=\"cursor:pointer\" onclick=\"location.href='?".$url."&pages=1';\">��ҳ</a> ";
		}
		if($pages > 1){
			$str .= "<a style=\"cursor:pointer\" onclick=\"location.href='?".$url."&pages=".($pages - 1)."';\">��һҳ</a> ";
		}else{
			$str .= "<a>��һҳ</a> ";
		}
		if($pages < $pagejs){
			$str .= "<a style=\"cursor:pointer\" onclick=\"location.href='?".$url."&pages=".($pages + 1)."';\">��һҳ</a> ";
		}else{
			$str .= "<a>��һҳ</a> ";
		}
		if($pages == $pagejs){
			$str .= "<a>βҳ</a> ";
		}else{
			$str .= "<a style=\"cursor:pointer\" onclick=\"location.href='?".$url."&pages=".$pagejs."';\">βҳ</a> ";
		}
 		$str .= "<a><strong>".$pages."</strong>/<strong>".$pagejs."</strong></a> ";
	}
	$arr = array($str, $result, $nums);
	return $arr;
}
?>