<?php
include '../../../source/system/db.class.php';
header("Expires: Mon, 26 Jul 1997 05:00:00 GMT");
header("Cache-Control: no-cache, must-revalidate");
header("Pragma: no-cache");
header("Content-type: text/html;charset=".IN_CHARSET);
switch($_GET['id']){
	case 'video':
		echo "<cmp
		name = \"������Ƶ\"
		skins = \"video/video.swf\"
		video = \"video/video.php?id=\"
		auto_play = \"1\"
		play_mode = \"1\"
		context_menu = \"0\"
		/>";
		break;
	case 'box':
		echo "<cmp
		name = \"��������\"
		skins = \"box/box.swf\"
		box = \"box/box.php?id=\"
		auto_play = \"1\"
		context_menu = \"0\"
		/>";
		break;
	case 'lrc':
		echo "<cmp
		description = \"���޸��\"
		skins = \"box/lrc.swf\"
		_lrc = \"box/lrc.php?id=\"
		volume = \"0\"
		auto_play = \"1\"
		context_menu = \"0\"
		/>";
		break;
	case 'share':
		echo "<cmp
		name = \"��������\"
		skins = \"share/share.swf\"
		share = \"share/share.php?id=\"
		auto_play = \"1\"
		play_mode = \"1\"
		context_menu = \"0\"
		/>";
		break;
	case 'fm':
		echo "<cmp
		name = \"��������\"
		description = \"���޸��\"
		skins = \"radio/fm.swf\"
		fm = \"radio/fm.php?id=\"
		auto_play = \"1\"
		list_delete = \"1\"
		mixer_id = \"10\"
		play_mode = \"2\"
		context_menu = \"0\"
		/>";
		break;
	case 'song':
		echo "<cmp
		name = \"��������\"
		description = \"���޸��\"
		skins = \"player/song.swf\"
		song = \"player/url.php?id=\"
		auto_play = \"1\"
		play_mode = \"1\"
		context_menu = \"0\"
		/>";
		break;
	case 'play':
		echo "<cmp
		name = \"��������\"
		description = \"���޸��\"
		skins = \"player/play.swf\"
		play = \"player/url.php?id=\"
		auto_play = \"1\"
		list_delete = \"1\"
		context_menu = \"0\"
		/>";
		break;
}
?>