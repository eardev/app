<?php
include '../../../source/system/db.class.php';
header("Expires: Mon, 26 Jul 1997 05:00:00 GMT");
header("Cache-Control: no-cache, must-revalidate");
header("Pragma: no-cache");
header("Content-type: text/html;charset=".IN_CHARSET);
global $db;
$id = SafeRequest("id","get");
$type = SafeRequest("type","get");
if($type == 'lyric'){
        $lyric = geturl(getfield('music', 'in_lyric', 'in_id', $id), 'lyric');
        $text = trim(detect_encoding(@file_get_contents($lyric)));
        echo $text;
}elseif($type == 'download'){
        $mode = SafeRequest("mode","get");
        if($mode == 'lrc'){
                $file = geturl(getfield('music', 'in_lyric', 'in_id', $id), 'lyric');
        }else{
                $file = geturl(getfield('music', 'in_audio', 'in_id', $id));
        }
        $headers = get_headers($file, 1);
        if(array_key_exists('Content-Length', $headers)){
                $filesize = $headers['Content-Length'];
        }else{
                $filesize = strlen(@file_get_contents($file));
        }
        header("Content-Type: application/force-download");
        header("Content-Disposition: attachment; filename=".basename($file));
        header("Content-Length: ".$filesize);
        readfile($file);
}elseif($type == 'list'){
        $str = 'var musicList = [{name:"搜索结果",cover:"",creatorName:"",creatorAvatar:"",item:[]},{name:"正在播放",cover:"",creatorName:"",creatorAvatar:"",item:[]},{name:"播放历史",cover:"",creatorName:"",creatorAvatar:"",item:[]}';
        $query = $db->query("select * from ".tname('special')." where in_passed=0 order by rand() desc LIMIT 0,22");
        while($row = $db->fetch_array($query)){
                $str .= ',{name:"'.$row['in_name'].'",cover:"'.geturl($row['in_cover'], 'cover').'",creatorName:"",creatorAvatar:"",item:[';
                $result = $db->query("select * from ".tname('music')." where in_specialid=".$row['in_id']." and in_passed=0 order by in_addtime desc");
                while($rows = $db->fetch_array($result)){
                        $str .= '{musicName:"'.$rows['in_name'].'",artistsName:"'.getfield('singer', 'in_name', 'in_id', $row['in_singerid'], '未知歌手').'",albumName:"'.$row['in_name'].'",albumPic:"'.geturl($row['in_cover'], 'cover').'",musicId:'.$rows['in_id'].',mp3Url:"'.geturl($rows['in_audio']).'"},';
                }
                $str = str_replace(array(',>', '>'), array('', ''), $str.'>').']}';
        }
        echo $str.'];';
}elseif($type == 'search'){
        $key = unescape(SafeRequest("key","get"));
        $page = intval(SafeRequest("page","get"));
        $str = '{song:[';
        $query = $db->query("select * from ".tname('music')." where in_passed=0 and in_name like '%".$key."%' order by in_addtime desc LIMIT ".(($page - 1) * 22).",22");
        while($row = $db->fetch_array($query)){
                $str .= '{id:'.$row['in_id'].',name:"'.$row['in_name'].'",singer:"'.getfield('singer', 'in_name', 'in_id', $row['in_singerid'], '未知歌手').'",special:"'.getfield('special', 'in_name', 'in_id', $row['in_specialid'], '未知专辑').'",audio:"'.geturl($row['in_audio']).'",cover:"'.geturl(getfield('special', 'in_cover', 'in_id', $row['in_specialid']), 'cover').'"},';
        }
        echo str_replace(array(',>', '>'), array('', ''), $str.'>').']}';
}
?>