function ajaxSearch() {
    if (rem.loadPage == 1) {
        var tmpLoading = layer.msg("搜索中", {
            icon:16,
            shade:.01
        });
    }
    $.ajax({
        type:mkPlayer.method,
        url:mkPlayer.api,
        data:"type=search&page=" + rem.loadPage + "&key=" + escape(rem.wd),
        dataType:"text",
        complete:function(XMLHttpRequest, textStatus) {
            if (tmpLoading) layer.close(tmpLoading);
        },
        success:function(jsonData) {
            if (rem.loadPage == 1) {
                musicList[0].item = [];
                rem.mainList.html("");
                addListhead();
            } else {
                $("#list-foot").remove();
            }
            var tempItem = [], no = musicList[0].item.length, jsonData = eval('(' + jsonData + ')');
            for (var i = 0; i < jsonData.song.length; i++) {
                no++;
                tempItem = {
                    musicName:jsonData.song[i].name,
                    artistsName:jsonData.song[i].singer,
                    albumName:jsonData.song[i].special,
                    albumPic:jsonData.song[i].cover,
                    musicId:jsonData.song[i].id,
                    mp3Url:jsonData.song[i].audio
                };
                musicList[0].item.push(tempItem);
                addItem(no, tempItem.musicName, tempItem.artistsName, tempItem.albumName);
            }
            rem.dislist = 0;
            rem.loadPage++;
            dataBox("list");
            refreshList();
            if (jsonData.song.length < 1) {
                addListbar("nomore");
            } else if (no < mkPlayer.loadcount) {
                addListbar("nomore");
            } else {
                addListbar("more");
            }
        },
        error:function(XMLHttpRequest, textStatus, errorThrown) {
            layer.msg("搜索结果获取失败 - " + XMLHttpRequest.status);
        }
    });
}
function ajaxUrl(music, callback) {
    if (music.mp3Url !== null && music.mp3Url !== "err") {
        callback(music);
        return true;
    }
    if (music.musicId === null) {
        musicList[listID].item[musicID].mp3Url = "err";
        callback(music);
        return true;
    }
    $.ajax({
        type:mkPlayer.method,
        url:mkPlayer.api,
        data:"types=musicInfo&id=" + music.musicId,
        dataType:"jsonp",
        success:function(jsonData) {
            var mp3Url, picUrl;
            mp3Url = jsonData.url;
            if (mkPlayer.debug) {
                console.log("歌曲信息获取成功");
            }
            if (!mp3Url) mp3Url = "err";
            if (!picUrl) picUrl = null;
            music.mp3Url = mp3Url;
            updateMinfo(music);
            callback(music);
            return true;
        },
        error:function(XMLHttpRequest, textStatus, errorThrown) {
            layer.msg("歌曲信息获取失败 - " + XMLHttpRequest.status);
        }
    });
}
function ajaxPlayList(lid, id, callback) {
    if (!lid) return false;
    if (musicList[id].isloading === true) {
        layer.msg("列表读取中...", {
            icon:16,
            shade:.01,
            time:500
        });
        return true;
    }
    musicList[id].isloading = true;
    $.ajax({
        type:mkPlayer.method,
        url:mkPlayer.api,
        data:"types=playlist&id=" + lid,
        dataType:"jsonp",
        complete:function(XMLHttpRequest, textStatus) {
            musicList[id].isloading = false;
        },
        success:function(jsonData) {
            var tempList = {
                id:lid,
                name:jsonData.playlist.name,
                cover:jsonData.playlist.coverImgUrl,
                creatorName:jsonData.playlist.creator.nickname,
                creatorAvatar:jsonData.playlist.creator.avatarUrl,
                item:[]
            };
            if (jsonData.playlist.coverImgUrl !== "") {
                tempList.cover = jsonData.playlist.coverImgUrl;
            } else {
                tempList.cover = musicList[id].cover;
            }
            if (typeof jsonData.playlist.tracks !== undefined || jsonData.playlist.tracks.length !== 0) {
                for (var i = 0; i < jsonData.playlist.tracks.length; i++) {
                    tempList.item[i] = {
                        musicName:jsonData.playlist.tracks[i].name,
                        artistsName:jsonData.playlist.tracks[i].ar[0].name,
                        albumName:jsonData.playlist.tracks[i].al.name,
                        albumPic:jsonData.playlist.tracks[i].al.picUrl,
                        musicId:jsonData.playlist.tracks[i].id,
                        mp3Url:null
                    };
                }
            }
            if (musicList[id].creatorID) {
                tempList.creatorID = musicList[id].creatorID;
                if (musicList[id].creatorID === rem.uid) {
                    var tmpUlist = playerReaddata("ulist");
                    if (tmpUlist) {
                        for (i = 0; i < tmpUlist.length; i++) {
                            if (tmpUlist[i].id == lid) {
                                tmpUlist[i] = tempList;
                                playerSavedata("ulist", tmpUlist);
                                break;
                            }
                        }
                    }
                }
            }
            musicList[id] = tempList;
            if (id == mkPlayer.defaultlist) loadList(id);
            if (callback) callback(id);
            $(".sheet-item[data-no='" + id + "'] .sheet-cover").attr("src", tempList.cover);
            $(".sheet-item[data-no='" + id + "'] .sheet-name").html(tempList.name);
            if (mkPlayer.debug) {
                console.log("歌单 [" + tempList.name + "] 中的音乐获取成功");
            }
        },
        error:function(XMLHttpRequest, textStatus, errorThrown) {
            layer.msg("歌单读取失败 - " + XMLHttpRequest.status);
            $(".sheet-item[data-no='" + id + "'] .sheet-name").html('<span style="color: #EA8383">读取失败</span>');
        }
    });
}
function ajaxLyric(mid, callback) {
    lyricTip("歌词载入中...");
    if (!mid) callback("歌词载入出错！");
    $.ajax({
        type:mkPlayer.method,
        url:mkPlayer.api,
        data:"type=lyric&id=" + mid,
        dataType:"text",
        success:function(Data) {
            callback(Data);
        },
        error:function(XMLHttpRequest, textStatus, errorThrown) {
            callback("歌词读取失败 - " + XMLHttpRequest.status);
        }
    });
}
function ajaxUserList(uid) {
    var tmpLoading = layer.msg("加载中...", {
        icon:16,
        shade:.01
    });
    $.ajax({
        type:mkPlayer.method,
        url:mkPlayer.api,
        data:"types=userlist&uid=" + uid,
        dataType:"jsonp",
        complete:function(XMLHttpRequest, textStatus) {
            if (tmpLoading) layer.close(tmpLoading);
        },
        success:function(jsonData) {
            if (jsonData.code == "-1" || jsonData.code == 400) {
                layer.msg("用户 uid 输入有误");
                return false;
            }
            if (jsonData.playlist.length === 0 || typeof jsonData.playlist.length === "undefined") {
                layer.msg("没找到用户 " + uid + " 的歌单");
                return false;
            } else {
                var tempList, userList = [];
                $("#sheet-bar").remove();
                rem.uid = uid;
                rem.uname = jsonData.playlist[0].creator.nickname;
                layer.msg("欢迎您 " + rem.uname);
                playerSavedata("uid", rem.uid);
                playerSavedata("uname", rem.uname);
                for (var i = 0; i < jsonData.playlist.length; i++) {
                    tempList = {
                        id:jsonData.playlist[i].id,
                        name:jsonData.playlist[i].name,
                        cover:jsonData.playlist[i].coverImgUrl,
                        creatorID:uid,
                        creatorName:jsonData.playlist[i].creator.nickname,
                        creatorAvatar:jsonData.playlist[i].creator.avatarUrl,
                        item:[]
                    };
                    addSheet(musicList.push(tempList) - 1, tempList.name, tempList.cover);
                    userList.push(tempList);
                }
                playerSavedata("ulist", userList);
                sheetBar();
            }
            if (mkPlayer.debug) {
                console.log("用户歌单获取成功 [用户网易云ID：" + uid + "]");
            }
        },
        error:function(XMLHttpRequest, textStatus, errorThrown) {
            layer.msg("歌单同步失败 - " + XMLHttpRequest.status);
            console.log(XMLHttpRequest + textStatus + errorThrown);
        }
    });
    return true;
}