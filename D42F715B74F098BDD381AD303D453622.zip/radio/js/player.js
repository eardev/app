var mkPlayer = {
    api:temp_url + "source/api.php",
    wd:"吻别",
    loadcount:22,
    method:"GET",
    defaultlist:3,
    autoplay:false,
    coverbg:true,
    dotshine:true,
    volume:.6,
    version:"v2.21",
    debug:false
};
var rem = [];
function audioErr() {
    if (rem.playlist === undefined) return true;
    layer.msg("当前歌曲播放失败，自动播放下一首");
    nextMusic();
}
function pause() {
    if (rem.paused === false) {
        rem.audio.pause();
    } else {
        if (rem.playlist === undefined) {
            rem.playlist = rem.dislist;
            musicList[1].item = musicList[rem.playlist].item;
            playerSavedata("playing", musicList[1].item);
            listClick(0);
        }
        rem.audio.play();
    }
}
function audioPlay() {
    rem.paused = false;
    refreshList();
    $(".btn-play").addClass("btn-state-paused");
    if (mkPlayer.dotshine === true) $("#music-progress .mkpgb-dot").addClass("dot-move");
}
function audioPause() {
    rem.paused = true;
    $(".list-playing").removeClass("list-playing");
    $(".btn-play").removeClass("btn-state-paused");
    $("#music-progress .dot-move").removeClass("dot-move");
}
function prevMusic() {
    playList(rem.playid - 1);
}
function nextMusic() {
    playList(rem.playid + 1);
}
function updateProgress() {
    if (rem.paused !== false) return true;
    music_bar.goto(rem.audio.currentTime / rem.audio.duration);
    scrollLyric(rem.audio.currentTime);
}
function listClick(no) {
    var tmpid = no;
    if (mkPlayer.debug) {
        console.log("点播了列表中的第 " + (no + 1) + " 首歌 " + musicList[rem.dislist].item[no].musicName);
    }
    if (rem.dislist === 0) {
        if (rem.playlist === undefined) {
            rem.playlist = 1;
            rem.playid = musicList[1].item.length - 1;
        }
        for (var i = 0; i < musicList[1].item.length; i++) {
            if (musicList[1].item[i].musicId == musicList[0].item[no].musicId) {
                tmpid = i;
                playList(tmpid);
                return true;
            }
        }
        musicList[1].item.splice(rem.playid + 1, 0, musicList[0].item[no]);
        tmpid = rem.playid + 1;
        playerSavedata("playing", musicList[1].item);
    } else {
        if (rem.dislist !== rem.playlist && rem.dislist !== 1 || rem.playlist === undefined) {
            rem.playlist = rem.dislist;
            musicList[1].item = musicList[rem.playlist].item;
            playerSavedata("playing", musicList[1].item);
            refreshSheet();
        }
    }
    playList(tmpid);
    return true;
}
function playList(id) {
    if (rem.playlist === undefined) {
        pause();
        return true;
    }
    if (musicList[1].item.length <= 0) return true;
    if (id >= musicList[1].item.length) id = 0;
    if (id < 0) id = musicList[1].item.length - 1;
    rem.playid = id;
    play(musicList[1].item[id]);
}
function play(music) {
    if (mkPlayer.debug) {
        console.log("开始播放 - " + music.musicName + "\n" + 'musicName: "' + music.musicName + '",\n' + 'artistsName: "' + music.artistsName + '",\n' + 'albumName: "' + music.albumName + '",\n' + 'albumPic: "' + music.albumPic + '",\n' + "musicId: " + music.musicId + ",\n" + 'mp3Url: "' + music.mp3Url + '"');
    }
    if (music.mp3Url == "err") {
        audioErr();
        return false;
    }
    music_bar.goto(0);
    addHis(music);
    if (rem.dislist == 2 && rem.playlist !== 2) {
        loadList(2);
    } else {
        refreshList();
    }
    changeCover(music.albumPic);
    ajaxLyric(music.musicId, lyricCallback);
    $("audio").remove();
    var newaudio = $('<audio><source src="' + music.mp3Url + '"></audio>').appendTo("body");
    rem.audio = newaudio[0];
    rem.audio.volume = volume_bar.percent;
    rem.audio.addEventListener("timeupdate", updateProgress);
    rem.audio.addEventListener("play", audioPlay);
    rem.audio.addEventListener("pause", audioPause);
    rem.audio.addEventListener("ended", nextMusic);
    rem.audio.addEventListener("error", audioErr);
    rem.audio.play();
    window.setTimeout("delayCheck()", 5e3);
    music_bar.lock(false);
}
function delayCheck() {
    if (isNaN(rem.audio.duration) || rem.audio.duration === undefined || rem.audio.duration === 0) {
        audioErr();
    } else {
        if (mkPlayer.debug) {
            console.log("超时检测 - 歌曲播放正常");
        }
    }
}
function mBcallback(newVal) {
    var newTime = rem.audio.duration * newVal;
    rem.audio.currentTime = newTime;
    refreshLyric(newTime);
}
function vBcallback(newVal) {
    if (rem.audio !== undefined) {
        rem.audio.volume = newVal;
    }
    if ($(".btn-quiet").is(".btn-state-quiet")) {
        $(".btn-quiet").removeClass("btn-state-quiet");
    }
    if (newVal === 0) $(".btn-quiet").addClass("btn-state-quiet");
    playerSavedata("volume", newVal);
}
var initProgress = function() {
    music_bar = new mkpgb("#music-progress", 0, mBcallback);
    music_bar.lock(true);
    var tmp_vol = playerReaddata("volume");
    tmp_vol = tmp_vol != null ? tmp_vol :isMobile.any() ? 1 :mkPlayer.volume;
    if (tmp_vol < 0) tmp_vol = 0;
    if (tmp_vol > 1) tmp_vol = 1;
    if (tmp_vol == 0) $(".btn-quiet").addClass("btn-state-quiet");
    volume_bar = new mkpgb("#volume-progress", tmp_vol, vBcallback);
};
mkpgb = function(bar, percent, callback) {
    this.bar = bar;
    this.percent = percent;
    this.callback = callback;
    this.locked = false;
    this.init();
};
mkpgb.prototype = {
    init:function() {
        var mk = this, mdown = false;
        $(mk.bar).html('<div class="mkpgb-bar"></div><div class="mkpgb-cur"></div><div class="mkpgb-dot"></div>');
        mk.minLength = $(mk.bar).offset().left;
        mk.maxLength = $(mk.bar).width() + mk.minLength;
        $(window).resize(function() {
            mk.minLength = $(mk.bar).offset().left;
            mk.maxLength = $(mk.bar).width() + mk.minLength;
        });
        $(mk.bar + " .mkpgb-dot").mousedown(function(e) {
            e.preventDefault();
        });
        $(mk.bar).mousedown(function(e) {
            if (!mk.locked) mdown = true;
            barMove(e);
        });
        $("html").mousemove(function(e) {
            barMove(e);
        });
        $("html").mouseup(function(e) {
            mdown = false;
        });
        function barMove(e) {
            if (!mdown) return;
            var percent = 0;
            if (e.clientX < mk.minLength) {
                percent = 0;
            } else if (e.clientX > mk.maxLength) {
                percent = 1;
            } else {
                percent = (e.clientX - mk.minLength) / (mk.maxLength - mk.minLength);
            }
            mk.callback(percent);
            mk.goto(percent);
            return true;
        }
        mk.goto(mk.percent);
        return true;
    },
    "goto":function(percent) {
        if (percent > 1) percent = 1;
        if (percent < 0) percent = 0;
        this.percent = percent;
        $(this.bar + " .mkpgb-dot").css("left", percent * 100 + "%");
        $(this.bar + " .mkpgb-cur").css("width", percent * 100 + "%");
        return true;
    },
    lock:function(islock) {
        if (islock) {
            this.locked = true;
            $(this.bar).addClass("mkpgb-locked");
        } else {
            this.locked = false;
            $(this.bar).removeClass("mkpgb-locked");
        }
        return true;
    }
};
initProgress();