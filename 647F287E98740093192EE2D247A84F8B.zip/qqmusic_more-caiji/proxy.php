<?php
function curl_proxy($url, $text=false){
        if(function_exists('curl_init')){
                $ch = curl_init();
                curl_setopt($ch, CURLOPT_URL, $url);
                curl_setopt($ch, CURLOPT_RETURNTRANSFER, $text);
                curl_setopt($ch, CURLOPT_REFERER, 'http://y.qq.com/');
                $content = curl_exec($ch);
                curl_close($ch);
        }else{
                $option = array('http' => array('header' => 'Referer:http://y.qq.com/'));
                $content = @file_get_contents($url, false, stream_context_create($option));
        }
        return $content;
}
$proxy = explode('/', $_SERVER['PATH_INFO']);
$type = isset($proxy[3]) ? $proxy[3] : NULL;
$path = isset($proxy[4]) ? $proxy[4] : NULL;
if($type == 'audio'){
        $url = 'http://ws.stream.qqmusic.qq.com/C100'.$path.'?fromtag=38';
        $content = curl_proxy($url);
}elseif($type == 'cover'){
        $url = 'http://y.gtimg.cn/music/photo_new/'.$path.'?max_age=2592000';
        $content = curl_proxy($url);
}else{
        $url = 'http://lyric.music.qq.com/fcgi-bin/fcg_query_lyric.fcg?nobase64=1&musicid='.str_replace('.lrc', '', $path);
        $content = curl_proxy($url, true);
        $content = IN_CHARSET == 'gbk' ? iconv('UTF-8', 'GBK//IGNORE', $content) : $content;
        $content = preg_replace_callback('/MusicJsonCallback\(\{(.*?)"lyric":"(.*?)"\}\)/', array(new callback('return $match[2];'), 'matches'), $content);
        $content = html_entity_decode(str_replace("&#10;", "\r\n", $content), ENT_COMPAT, set_chars());
}
echo $content;
?>