<?php
if(!defined('IN_ROOT')){exit('Access denied');}
include 'source/admincp/include/function.php';
Administrator(1);
$setup=SafeRequest("setup","get");
?>
<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=<?php echo IN_CHARSET; ?>" />
<meta http-equiv="x-ua-compatible" content="ie=7" />
<title>QQ���ֲɼ�[ר��]</title>
<link href="<?php echo IN_PATH; ?>static/admincp/css/main.css" rel="stylesheet" type="text/css" />
<link href="<?php echo IN_PATH; ?>static/pack/asynctips/asynctips.css" rel="stylesheet" type="text/css" />
<script type="text/javascript" src="<?php echo IN_PATH; ?>static/pack/asynctips/jquery.min.js"></script>
<script type="text/javascript" src="<?php echo IN_PATH; ?>static/pack/asynctips/asyncbox.v1.4.5.js"></script>
<script type="text/javascript" src="<?php echo IN_PATH; ?>static/pack/layer/jquery.js"></script>
<script type="text/javascript" src="<?php echo IN_PATH; ?>static/pack/layer/lib.js"></script>
<script type="text/javascript">
var pop = {
	up: function(scrolling, text, url, width, height, top) {
		layer.open({
			type: 2,
			maxmin: true,
			title: text,
			content: [url, scrolling],
			area: [width, height],
			offset: top,
			shade: false
		});
	}
}
function is_urlget(url){
	if(url.match(/^(https?:\/\/y\.qq\.com\/n\/yqq\/album\/)+(([a-zA-Z0-9])+\.html)+(.*\r\n|.*\n)+$/gm)){
	        return true;
	}
	return false;
}
function CheckForm(){
        if(document.form.in_uname.value==""){
            asyncbox.tips("������Ա����Ϊ�գ�����д��", "wait", 1000);
            document.form.in_uname.focus();
            return false;
        }
        else if(document.form.urlget.value==""){
            asyncbox.tips("ר����ַ����Ϊ�գ�����д��", "wait", 1000);
            document.form.urlget.focus();
            return false;
        }
        else if(is_urlget(document.form.urlget.value+"\n")==false){
            asyncbox.tips("ר����ַ���淶����������д��", "error", 1000);
            document.form.urlget.focus();
            return false;
        }
        else {
            $("#urlget").val($("#urlget").val().replace(/https/g, 'http'));
            return true;
        }
}
</script>
</head>
<body>
<div class="container">
<script type="text/javascript">parent.document.title = 'Ear Music Board �������� - QQ���ֲɼ�[ר��]';if(parent.$('admincpnav')) parent.$('admincpnav').innerHTML='QQ���ֲɼ�[ר��]';</script>
<div class="floattop"><div class="itemtitle"><h3>QQ���ֲɼ�[ר��]</h3></div></div><div class="floattopempty"></div>
<?php
switch($setup){
	case 'ing':
		caiji_opening();
		break;
	default:
		caiji_open();
		break;
	}
?>
</div>
</body>
</html>
<?php function caiji_open(){
global $db;
$one = $db->getone("select in_userid from ".tname('user')." where in_username='".$_COOKIE['in_adminname']."'");
$in_uname = $one ? $_COOKIE['in_adminname'] : NULL;
?>
<form action="<?php echo $_SERVER['PHP_SELF']; ?>?setup=ing" method="post" name="form">
<table class="tb tb2">
<tr>
<td>ר����Ŀ��<select name="in_sclassid" id="in_sclassid">
<?php
$res=$db->query("select * from ".tname('special_class')." order by in_id asc");
if($res){
        while ($row = $db->fetch_array($res)){
                echo "<option value=\"".$row['in_id']."\">".$row['in_name']."</option>";
        }
}
?>
</select></td>
<td>������Ŀ��<select name="in_mclassid" id="in_mclassid">
<?php
$res=$db->query("select * from ".tname('class')." order by in_id asc");
if($res){
        while ($row = $db->fetch_array($res)){
                echo "<option value=\"".$row['in_id']."\">".$row['in_name']."</option>";
        }
}
?>
</select></td>
</tr>
<tr>
<td>�������֣�<select name="in_singerid" id="in_singerid">
<option value="0">��ѡ��</option>
<?php
$res=$db->query("select * from ".tname('singer')." order by in_addtime desc");
if($res){
        while ($row = $db->fetch_array($res)){
                echo "<option value=\"".$row['in_id']."\">".getlenth($row['in_name'], 10)."</option>";
        }
}
?>
</select>&nbsp;&nbsp;<a href="javascript:void(0)" onclick="pop.up('yes', 'ѡ�����', '<?php echo IN_PATH; ?>source/pack/tag/singer_opt.php?so=form.in_singerid', '500px', '400px', '65px');" class="addtr">ѡ��</a></td>
<td>������Ա��<input type="text" class="txt" value="<?php echo $in_uname; ?>" name="in_uname" id="in_uname"></td>
</tr>
<tr><td class="lightnum"><div style="height:100px;line-height:100px;float:left">ר����ַ��</div><textarea rows="6" cols="50" id="urlget" name="urlget" onfocus="javascript:if('������������ַ��ÿ��һ��'==this.value)this.value=''" onblur="javascript:if(''==this.value)this.value='������������ַ��ÿ��һ��'" style="width:400px;height:100px">������������ַ��ÿ��һ��</textarea></td></tr>
</table>
<table class="tb tb2">
<tr><td><input type="submit" class="btn" value="�ύ" onclick="return CheckForm();" /><input class="checkbox" type="checkbox" name="remote" id="remote" value="1"><label for="remote" class="lightnum">����</label></td></tr>
</table>
</form>
<?php } function caiji_opening(){
        global $db;
        $uname = SafeRequest("in_uname","post");
        if($one = $db->getone("select in_userid from ".tname('user')." where in_username='".$uname."'")){
                $uid = $one;
                $sid = SafeRequest("in_singerid","post");
                $aid = SafeRequest("in_sclassid","post");
                $mid = SafeRequest("in_mclassid","post");
                $remote = SafeRequest("remote","post") == 1 ? 'remote' : 'local';
                $urlget = SafeRequest("urlget","post");
                $arr = explode("\n", $urlget);
                $pages = '';
		for($i = 0; $i < count($arr); $i++){
		        $pages .= preg_replace('/(.html.*)/', '', substr(strrchr(trim($arr[$i]), '/'), 1)).'|';
		}
                $pages = str_replace('|]', '', $pages.']');
        }else{
                exit("<h3>Ear Music ��ʾ</h3><div class=\"infobox\"><br /><h4 class=\"marginbot normal\" style=\"color:#C00\">������Ա�����ڣ���������д��</h4><br /><p class=\"margintop\"><input type=\"button\" class=\"btn\" value=\"���ڷ���...\" disabled=\"disabled\"></p><br /></div></div><script type=\"text/javascript\">setTimeout(\"location.href='".$_SERVER['PHP_SELF']."';\", 3000);</script></body></html>");
        }
        echo "<script type=\"text/javascript\">location.href='".IN_PATH."plugin.php/qqmusic_more-caiji/$remote/?number=0&uname=$uname&uid=$uid&s=$sid&a=$aid&m=$mid&p=$pages';</script>";
}
?>