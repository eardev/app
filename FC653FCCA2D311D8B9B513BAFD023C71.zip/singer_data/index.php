<?php
if(!defined('IN_ROOT')){exit('Access denied');}
include 'source/admincp/include/function.php';
Administrator(1);
$setup=SafeRequest("setup","get");
?>
<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=<?php echo IN_CHARSET; ?>" />
<meta http-equiv="x-ua-compatible" content="ie=7" />
<title>歌手数据</title>
<link href="<?php echo IN_PATH; ?>static/admincp/css/main.css" rel="stylesheet" type="text/css" />
<script type="text/javascript">function $(obj) {return document.getElementById(obj);}</script>
</head>
<body>
<div class="container">
<script type="text/javascript">parent.document.title = 'Ear Music Board 管理中心 - 歌手数据';if(parent.$('admincpnav')) parent.$('admincpnav').innerHTML='歌手数据';</script>
<div class="floattop"><div class="itemtitle"><h3>歌手数据</h3></div></div><div class="floattopempty"></div>
<table class="tb tb2">
<tr><th class="partition">技巧提示</th></tr>
<tr><td class="tipsblock"><ul>
<li>导入后如需批量更改“所属会员”，请在 工具->执行语句 分两次执行以下语句</li>
<li><em class="lightnum">update <?php echo IN_DBTABLE; ?>singer set in_uid=会员的ID;</em></li>
<li><em class="lightnum">update <?php echo IN_DBTABLE; ?>singer set in_uname='会员的用户名';</em></li>
</ul></td></tr>
</table>
<h3>Ear Music 提示</h3>
<?php
switch($setup){
	case 'data':
		data_ing();
		break;
	case 'zip':
		zip_ing();
		break;
	default:
		singer_data();
		break;
	}
?>
</div>
</body>
</html>
<?php function singer_data(){ ?>
<div class="infobox"><br /><p class="margintop"><input type="button" class="btn" value="开始导入" onclick="location.href='<?php echo $_SERVER['PHP_SELF']; ?>?setup=data';"></p><br /></div>
<?php } function data_ing(){
	global $db;
	$data = file_get_contents('source/plugin/singer_data/data.sql');
	$data = str_replace('prefix_', IN_DBTABLE, $data);
	$dataarr = explode('INSERT INTO', $data);
	for($i = 1; $i < count($dataarr); $i++){
		$db->query('INSERT INTO'.$dataarr[$i]);
	}
        echo "<div class=\"infobox\"><h4 class=\"infotitle1\">正在解压图片包，请稍候......</h4><img src=\"".IN_PATH."static/admincp/css/loader.gif\" class=\"marginbot\" /></div>";
        echo "<script type=\"text/javascript\">setTimeout(\"location.href='".$_SERVER['PHP_SELF']."?setup=zip';\", 1000);</script>";
} function zip_ing(){
        include_once 'source/pack/zip/zip.php';
        $unzip="source/plugin/singer_data/cover.zip";
        if(is_file($unzip)){
                $zip=new PclZip($unzip);
                if(($list=$zip->listContent())==0){
                        exit("<div class=\"infobox\"><br /><h4 class=\"marginbot normal\" style=\"color:#C00\">".$zip->errorInfo(true)."</h4><br /><p class=\"margintop\"><input type=\"button\" class=\"btn\" value=\"重新导入\" onclick=\"history.back(1);\"></p><br /></div></div></body></html>");
                }
                $zip->extract(PCLZIP_OPT_PATH, 'data/attachment/singer/cover', PCLZIP_OPT_REPLACE_NEWER);
                echo "<div class=\"infobox\"><br /><h4 class=\"infotitle2\">恭喜，数据已经全部导入完成！</h4><br /></div>";
        }
}
?>