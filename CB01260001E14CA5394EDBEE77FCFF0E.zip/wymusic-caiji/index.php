<?php
if(!defined('IN_ROOT')){exit('Access denied');}
include 'source/admincp/include/function.php';
Administrator(1);
ini_set('memory_limit', '-1');
$setup=SafeRequest("setup","get");
?>
<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=<?php echo IN_CHARSET; ?>" />
<meta http-equiv="x-ua-compatible" content="ie=7" />
<title>网易音乐采集[单曲]</title>
<link href="<?php echo IN_PATH; ?>static/admincp/css/main.css" rel="stylesheet" type="text/css" />
<link href="<?php echo IN_PATH; ?>static/pack/asynctips/asynctips.css" rel="stylesheet" type="text/css" />
<script type="text/javascript" src="<?php echo IN_PATH; ?>static/pack/asynctips/jquery.min.js"></script>
<script type="text/javascript" src="<?php echo IN_PATH; ?>static/pack/asynctips/asyncbox.v1.4.5.js"></script>
<script type="text/javascript" src="<?php echo IN_PATH; ?>static/pack/layer/jquery.js"></script>
<script type="text/javascript" src="<?php echo IN_PATH; ?>static/pack/layer/lib.js"></script>
<script type="text/javascript">
var pop = {
	up: function(scrolling, text, url, width, height, top) {
		layer.open({
			type: 2,
			maxmin: true,
			title: text,
			content: [url, scrolling],
			area: [width, height],
			offset: top,
			shade: false
		});
	}
}
function is_urlget(url){
	if(url.match(/^(http:\/\/music\.163\.com\/#?\/?song\?id=)+([a-zA-Z0-9])+$/)){
	        return true;
	}
	return false;
}
function CheckForm(){
        if(document.form.in_uname.value==""){
            asyncbox.tips("所属会员不能为空，请填写！", "wait", 1000);
            document.form.in_uname.focus();
            return false;
        }
        else if(document.form.urlget.value==""){
            asyncbox.tips("单曲地址不能为空，请填写！", "wait", 1000);
            document.form.urlget.focus();
            return false;
        }
        else if(is_urlget(document.form.urlget.value)==false){
            asyncbox.tips("单曲地址不规范，请重新填写！", "error", 1000);
            document.form.urlget.focus();
            return false;
        }
}
var fsize = 0;
var _fsize = 0;
function set_size(filesize, _filesize){
        fsize = filesize;
        _fsize = _filesize;
}
function caiji_local(dlen, status, _dlen){
        if(fsize > 0){
                var _status = status == 1 ? "采集入库" : "重复更新";
                var percent = Math.round(dlen * 100 / fsize);
                document.getElementById("progressbar").style.width = percent + "%";
                if(percent > 0){
                        document.getElementById("progressbar").innerHTML = _dlen + "/" + _fsize + "[" + _status + "]";
                        document.getElementById("progressText").innerHTML = "";
                }else{
                        document.getElementById("progressText").innerHTML = percent + "%";
                }
                if(percent > 99){
                        document.getElementById("progressbar").innerHTML = "采集完毕，请稍等...";
                        setTimeout("location.href='<?php echo $_SERVER['PHP_SELF']; ?>';", 1000);
                }
        }
}
function caiji_remote(status){
        var _status = status == 1 ? "[采集入库]" : "[重复更新]";
        document.getElementById("progressbar").style.width = "100%";
        document.getElementById("progressbar").innerHTML = "100%" + _status;
        document.getElementById("progressText").innerHTML = "";
        setTimeout("location.href='<?php echo $_SERVER['PHP_SELF']; ?>';", 1000);
}
</script>
</head>
<body>
<div class="container">
<script type="text/javascript">parent.document.title = 'Ear Music Board 管理中心 - 网易音乐采集[单曲]';if(parent.$('admincpnav')) parent.$('admincpnav').innerHTML='网易音乐采集[单曲]';</script>
<div class="floattop"><div class="itemtitle"><h3>网易音乐采集[单曲]</h3></div></div><div class="floattopempty"></div>
<?php
switch($setup){
	case 'ing':
		caiji_opening();
		break;
	default:
		caiji_open();
		break;
	}
?>
</div>
</body>
</html>
<?php function caiji_open(){
global $db;
$one = $db->getone("select in_userid from ".tname('user')." where in_username='".$_COOKIE['in_adminname']."'");
$in_uname = $one ? $_COOKIE['in_adminname'] : NULL;
?>
<form action="<?php echo $_SERVER['PHP_SELF']; ?>?setup=ing" method="post" name="form">
<table class="tb tb2">
<tr>
<td>所属歌手：<select name="in_singerid" id="in_singerid">
<option value="0">不选择</option>
<?php
$res=$db->query("select * from ".tname('singer')." order by in_addtime desc");
if($res){
        while ($row = $db->fetch_array($res)){
                echo "<option value=\"".$row['in_id']."\">".getlenth($row['in_name'], 10)."</option>";
        }
}
?>
</select>&nbsp;&nbsp;<a href="javascript:void(0)" onclick="pop.up('yes', '选择歌手', '<?php echo IN_PATH; ?>source/pack/tag/singer_opt.php?so=form.in_singerid', '500px', '400px', '65px');" class="addtr">选择</a></td>
<td>所属栏目：<select name="in_classid" id="in_classid">
<?php
$res=$db->query("select * from ".tname('class')." order by in_id asc");
if($res){
        while ($row = $db->fetch_array($res)){
                echo "<option value=\"".$row['in_id']."\">".$row['in_name']."</option>";
        }
}
?>
</select></td>
</tr>
<tr>
<td>所属专辑：<select name="in_specialid" id="in_specialid">
<option value="0">不选择</option>
<?php
$res=$db->query("select * from ".tname('special')." order by in_addtime desc");
if($res){
        while ($row = $db->fetch_array($res)){
                echo "<option value=\"".$row['in_id']."\">".getlenth($row['in_name'], 10)."</option>";
        }
}
?>
</select>&nbsp;&nbsp;<a href="javascript:void(0)" onclick="pop.up('yes', '选择专辑', '<?php echo IN_PATH; ?>source/pack/tag/special_opt.php?so=form.in_specialid', '500px', '400px', '65px');" class="addtr">选择</a></td>
<td>所属会员：<input type="text" class="txt" value="<?php echo $in_uname; ?>" name="in_uname" id="in_uname"></td>
</tr>
<tr><td class="longtxt lightnum">单曲地址：<input type="text" class="txt" name="urlget" id="urlget"><input class="checkbox" type="checkbox" name="remote" id="remote" value="1"><label for="remote">外链</label></td></tr>
</table>
<table class="tb tb2">
<tr><td><input type="submit" class="btn" value="提交" onclick="return CheckForm();" /></td></tr>
</table>
</form>
<?php } function caiji_opening(){
        global $db;
        $uname = SafeRequest("in_uname","post");
        if($one = $db->getone("select in_userid from ".tname('user')." where in_username='".$uname."'")){
                $uid = $one;
                $singerid = SafeRequest("in_singerid","post");
                $classid = SafeRequest("in_classid","post");
                $specialid = SafeRequest("in_specialid","post");
                $remote = SafeRequest("remote","post");
        }else{
                exit("<h3>Ear Music 提示</h3><div class=\"infobox\"><br /><h4 class=\"marginbot normal\" style=\"color:#C00\">所属会员不存在，请重新填写！</h4><br /><p class=\"margintop\"><input type=\"button\" class=\"btn\" value=\"正在返回...\" disabled=\"disabled\"></p><br /></div></div><script type=\"text/javascript\">setTimeout(\"location.href='".$_SERVER['PHP_SELF']."';\", 3000);</script></body></html>");
        }
        echo "<h3>Ear Music 提示</h3><div class=\"infobox\"><br />";
        echo "<table class=\"tb tb2\" style=\"border:1px solid #09C\">";
        echo "<tr><td><div id=\"progressbar\" style=\"float:left;width:1px;text-align:center;color:#FFFFFF;background-color:#09C\"></div><div id=\"progressText\" style=\"float:left\">0%</div></td></tr>";
        echo "</table>";
        echo "<br /><p class=\"margintop\"><input type=\"button\" class=\"btn\" value=\"撤销\" onclick=\"history.go(-1);\"></p><br /></div>";
        ob_start();
        @set_time_limit(0);
        $url = SafeRequest("urlget","post");
        preg_match('/id=(\d+)/', $url, $arr);
        if(!empty($arr)){
		$lyric = 'http://music.163.com/api/song/lyric?os=pc&id='.$arr[1].'&lv=-1';
		$ltext = @file_get_contents($lyric);
		$ltext = IN_CHARSET == 'gbk' ? iconv('UTF-8', 'GBK//IGNORE', $ltext) : $ltext;
		preg_match('/"lyric":"(.*?)"\}/', $ltext, $larr);
		$l_rc = str_replace(array("\\n", "'", "\\"."\""), array("\r\n", "&#039;", "&#034;"), $larr[1]);
		$lrc = preg_replace_callback('/\[(\d+):(\d+).(\d+)\]/', array(new callback('return("[".$match[1].":".$match[2].".".substr(sprintf("%02d", $match[3]), 0, 2)."]");'), 'matches'), $l_rc);
		$w_ord = trim(preg_replace('/\[(.*?)\]/', '', $l_rc));
		$json = @file_get_contents('http://music.163.com/api/song/detail/?ids=['.$arr[1].']');
		preg_match('/\{"songs":\[\{"name":"(.*?)"(.*?)"blurPicUrl":"(.*?)"/', $json, $jarr);
		$title = str_replace(array("'", "\\"."\""), array("&#039;", "&#034;"), $jarr[1]);
		$n_ame = IN_CHARSET == 'gbk' ? iconv('UTF-8', 'GBK//IGNORE', $title) : $title;
                if(!$remote){
                        $a_udio = 'data/attachment/music/audio/wymusic_'.$arr[1].'.mp3';
                        $c_over = 'data/attachment/music/cover/wymusic_'.$arr[1].'.jpg';
                        $l_yric = 'data/attachment/music/lyric/wymusic_'.$arr[1].'.lrc';
                        $adown = 'http://music.163.com/song/media/outer/url?id='.$arr[1].'.mp3';
                        $cdown = $jarr[3];
                }else{
                        $a_udio = 'plugin.php/wymusic-caiji/proxy/audio/'.$arr[1].'.mp3';
                        $c_over = 'plugin.php/wymusic-caiji/proxy/cover/'.$arr[1].'.jpg';
                        $l_yric = 'plugin.php/wymusic-caiji/proxy/lyric/'.$arr[1].'.lrc';
                }
                if($one = $db->getone("select in_id from ".tname('music')." where in_audio='".$a_udio."'")){
                        $status = 0;
                        updatetable('music', array('in_name' => $n_ame,'in_classid' => $classid,'in_specialid' => $specialid,'in_singerid' => $singerid,'in_uid' => $uid,'in_uname' => $uname,'in_text' => $w_ord,'in_addtime' => date('Y-m-d H:i:s')), array('in_id' => $one));
                }else{
                        $status = 1;
                        inserttable('music', array('in_name' => $n_ame,'in_classid' => $classid,'in_specialid' => $specialid,'in_singerid' => $singerid,'in_uid' => $uid,'in_uname' => $uname,'in_audio' => $a_udio,'in_lyric' => $l_yric,'in_text' => $w_ord,'in_cover' => $c_over,'in_hits' => 0,'in_downhits' => 0,'in_favhits' => 0,'in_goodhits' => 0,'in_badhits' => 0,'in_points' => 0,'in_grade' => 3,'in_best' => 0,'in_passed' => 0,'in_wrong' => 0,'in_addtime' => date('Y-m-d H:i:s')), 1);
                }
                if(!$remote){
                        $file = fopen($adown, 'rb');
                        $newf = fopen($a_udio, 'wb');
                        $dlen = 0;
                        $headers = get_headers($adown, 1);
                        if(array_key_exists('Content-Length', $headers)){
                                $head = $headers['Content-Length'];
                                $fsize = is_array($head) ? empty($head[0]) ? $head[1] : $head[0] : $head;
                        }else{
                                $fsize = strlen(@file_get_contents($adown));
                        }
                        echo "<script type=\"text/javascript\">set_size($fsize, '".formatsize($fsize)."');</script>";
                        fwrite(fopen($c_over, 'wb'), @file_get_contents($cdown));
                        fwrite(fopen($l_yric, 'wb+'), $lrc);
                        while(!feof($file)){
                                $data = fread($file, 1024*8);
                                $dlen += strlen($data);
                                fwrite($newf, $data, 1024*8);
                                echo "<script type=\"text/javascript\">caiji_local($dlen, $status, '".formatsize($dlen)."');</script>";
                                ob_flush();
                                flush();
                        }
                        fclose($file);
                        fclose($newf);
                }else{
                        echo "<script type=\"text/javascript\">caiji_remote($status);</script>";
                }
        }
}
?>