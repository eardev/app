<?php
function curl_proxy($url, $text=false){
        if(function_exists('curl_init')){
                $ch = curl_init();
                curl_setopt($ch, CURLOPT_URL, $url);
                curl_setopt($ch, CURLOPT_RETURNTRANSFER, $text);
                $content = curl_exec($ch);
                curl_close($ch);
        }else{
                $content = @file_get_contents($url);
        }
        return $content;
}
$proxy = explode('/', $_SERVER['PATH_INFO']);
$type = isset($proxy[3]) ? $proxy[3] : NULL;
$path = isset($proxy[4]) ? $proxy[4] : NULL;
if($type == 'audio'){
        $url = 'http://music.163.com/song/media/outer/url?id='.$path;
        header("Content-Type: application/force-download");
        header("Content-Disposition: attachment; filename=".basename($url));
        readfile($url);
}elseif($type == 'cover'){
        $url = 'http://music.163.com/api/song/detail/?ids=['.str_replace('.jpg', '', $path).']';
        $content = curl_proxy($url, true);
        preg_match('/"blurPicUrl":"(.*?)"/', $content, $jarr);
        $content = curl_proxy($jarr[1]);
}else{
        $url = 'http://music.163.com/api/song/lyric?os=pc&id='.str_replace('.lrc', '', $path).'&lv=-1';
        $content = curl_proxy($url, true);
        $content = IN_CHARSET == 'gbk' ? iconv('UTF-8', 'GBK//IGNORE', $content) : $content;
	preg_match('/"lyric":"(.*?)"\}/', $content, $larr);
	$content = str_replace(array("\\n", "'", "\\"."\""), array("\r\n", "&#039;", "&#034;"), $larr[1]);
	$content = preg_replace_callback('/\[(\d+):(\d+).(\d+)\]/', array(new callback('return("[".$match[1].":".$match[2].".".substr(sprintf("%02d", $match[3]), 0, 2)."]");'), 'matches'), $content);
}
echo $content;
?>