<?php
define('in_plugin_baidu_push_size', '30');
define('in_plugin_baidu_push_token', '');
?>