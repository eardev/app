<?php
if(!defined('IN_ROOT')){exit('Access denied');}
include 'source/plugin/baidu_push/config.php';
include 'source/admincp/include/function.php';
Administrator(1);
$setup=SafeRequest("setup","get");
?>
<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=<?php echo IN_CHARSET; ?>" />
<meta http-equiv="x-ua-compatible" content="ie=7" />
<title>�ٶ���������</title>
<link href="<?php echo IN_PATH; ?>static/admincp/css/main.css" rel="stylesheet" type="text/css" />
<link href="<?php echo IN_PATH; ?>static/pack/asynctips/asynctips.css" rel="stylesheet" type="text/css" />
<script type="text/javascript" src="<?php echo IN_PATH; ?>static/pack/asynctips/jquery.min.js"></script>
<script type="text/javascript" src="<?php echo IN_PATH; ?>static/pack/asynctips/asyncbox.v1.4.5.js"></script>
<script type="text/javascript">
function CheckForm(){
        if(document.form.in_size.value==""){
            asyncbox.tips("���ͷ�������Ϊ�գ������ã�", "wait", 1000);
            document.form.in_size.focus();
            return false;
        }
        else if(document.form.in_token.value==""){
            asyncbox.tips("�����ܳײ���Ϊ�գ������ã�", "wait", 1000);
            document.form.in_token.focus();
            return false;
        }
        else {
            return true;
        }
}
</script>
</head>
<body>
<?php
switch($setup){
	case 'ing':
		baidu_pushing();
		break;
	default:
		baidu_push();
		break;
	}
?>
</body>
</html>
<?php function baidu_push(){ ?>
<div class="container">
<script type="text/javascript">parent.document.title = 'Ear Music Board �������� - �ٶ���������';if(parent.$('admincpnav')) parent.$('admincpnav').innerHTML='�ٶ���������';</script>
<div class="floattop"><div class="itemtitle"><h3>�ٶ���������</h3></div></div><div class="floattopempty"></div>
<table class="tb tb2">
<tr><th class="partition">������ʾ</th></tr>
<tr><td class="tipsblock"><ul>
<li>�ٶ��������ͣ�<a href="https://ziyuan.baidu.com" target="_blank">ziyuan.baidu.com</a></li>
<li>Site��<em class="lightnum"><?php echo $_SERVER['HTTP_HOST']; ?></em></li>
<li>Token���������������еġ�<em class="lightnum">�����ܳ�</em>������һ��</li>
</ul></td></tr>
</table>
<form action="<?php echo $_SERVER['PHP_SELF']; ?>?setup=ing" method="post" name="form">
<table class="tb tb2">
<tr><td>�������ݣ�<select name="in_type" id="in_type"><option value="0">��������</option><option value="1">����ר��</option><option value="2">���и���</option><option value="3">������Ƶ</option></select></td></tr>
<tr><td>���ͷ�����<input type="text" class="txt" value="<?php echo in_plugin_baidu_push_size; ?>" name="in_size" id="in_size" onkeyup="this.value=this.value.replace(/[^\d]/g,'')" onbeforepaste="clipboardData.setData('text',clipboardData.getData('text').replace(/[^\d]/g,''))"></td></tr>
<tr><td class="td29">�����ܳף�<input type="text" class="txt" value="<?php echo in_plugin_baidu_push_token; ?>" name="in_token" id="in_token"></td></tr>
</table>
<table class="tb tb2">
<tr><td><input type="submit" class="btn" value="��ʼ����" onclick="return CheckForm();" /></td></tr>
</table>
</form>
</div>
<?php } function baidu_pushing(){
        if(function_exists('curl_init')){
                $type = SafeRequest("in_type","post");
                $str = file_get_contents('source/plugin/baidu_push/config.php');
                $str = preg_replace("/'in_plugin_baidu_push_size', '(.*?)'/", "'in_plugin_baidu_push_size', '".SafeRequest("in_size","post")."'", $str);
                $str = preg_replace("/'in_plugin_baidu_push_token', '(.*?)'/", "'in_plugin_baidu_push_token', '".SafeRequest("in_token","post")."'", $str);
                $ifile = new iFile('source/plugin/baidu_push/config.php', 'w');
                $ifile->WriteFile($str, 3);
        }else{
                ShowMessage("��ǰPHP������֧��CURL��չ��","history.back(1);","infotitle3",3000,2);
        }
        echo "<script type=\"text/javascript\">location.href='".IN_PATH."plugin.php/baidu_push/entry/?type=$type';</script>";
}
?>