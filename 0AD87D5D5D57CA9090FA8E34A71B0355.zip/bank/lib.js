function convert_credit() {
	var password = $('_password').value;
	if (password == '') {
		layer.msg('登录密码不能为空！', {icon: 2});
		$('_password').focus();
		return;
	}
	var num = $('_num').value;
	if (num == '' || num < 1) {
		layer.msg('兑换数量不能为空！', {icon: 2});
		$('_num').focus();
		return;
	}
	createXMLHttpRequest();
	XMLHttpReq.open('GET', in_path + 'source/plugin/bank/ajax.php?ac=credit&pwd=' + escape(password) + '&type=' + $('_type').value + '&num=' + num, true);
	XMLHttpReq.onreadystatechange = function() {
		if (XMLHttpReq.readyState == 4) {
			if (XMLHttpReq.status == 200) {
				if (XMLHttpReq.responseText == 'return_1') {
					layer.msg('请先登录用户中心！', {icon: 2});
				} else if (XMLHttpReq.responseText == 'return_2') {
					layer.msg('登录密码有误，请重试！', {icon: 2});
				} else if (XMLHttpReq.responseText == 'return_3') {
					layer.msg('金币不足，请先充值！', {icon: 5});
				} else if (XMLHttpReq.responseText == 'return_4') {
					layer.msg('经验不足，请核对账户！', {icon: 5});
				} else if (XMLHttpReq.responseText == 'return_5') {
					layer.msg('恭喜，积分兑换成功！', {icon: 6});
					setTimeout("location.reload();", 3000);
				} else {
					layer.msg('内部出现错误，请稍后再试！', {icon: 5});
				}
			} else {
				layer.msg('通讯异常，请检查网络设置！', {icon: 3});
			}
		}
	}
	XMLHttpReq.send(null);
}
function points_cash() {
	var password = $('_password').value;
	if (password == '') {
		layer.msg('登录密码不能为空！', {icon: 2});
		$('_password').focus();
		return;
	}
	var rmb = $('_rmb').value;
	if (rmb == '' || rmb < 1) {
		layer.msg('提现金额不能为空！', {icon: 2});
		$('_rmb').focus();
		return;
	}
	var account = $('_account').value;
	if (account == '') {
		layer.msg('提现账户不能为空！', {icon: 2});
		$('_account').focus();
		return;
	}
	var nick = $('_nick').value;
	if (nick == '') {
		layer.msg('账户姓名不能为空！', {icon: 2});
		$('_nick').focus();
		return;
	}
	createXMLHttpRequest();
	XMLHttpReq.open('GET', in_path + 'source/plugin/bank/ajax.php?ac=cash&pwd=' + escape(password) + '&rmb=' + rmb + '&account=' + escape(account) + '&type=' + escape($('_type').value) + '&nick=' + escape(nick), true);
	XMLHttpReq.onreadystatechange = function() {
		if (XMLHttpReq.readyState == 4) {
			if (XMLHttpReq.status == 200) {
				if (XMLHttpReq.responseText == 'return_1') {
					layer.msg('请先登录用户中心！', {icon: 2});
				} else if (XMLHttpReq.responseText == 'return_2') {
					layer.msg('登录密码有误，请重试！', {icon: 2});
				} else if (XMLHttpReq.responseText == 'return_3') {
					layer.msg('抱歉，提现功能暂未启用！', {icon: 3});
				} else if (XMLHttpReq.responseText == 'return_4') {
					layer.msg('金币不足，请核对账户！', {icon: 5});
				} else if (XMLHttpReq.responseText == 'return_5') {
					layer.msg('恭喜，金币提现成功！', {icon: 6});
					setTimeout("location.reload();", 3000);
				} else {
					layer.msg('内部出现错误，请稍后再试！', {icon: 5});
				}
			} else {
				layer.msg('通讯异常，请检查网络设置！', {icon: 3});
			}
		}
	}
	XMLHttpReq.send(null);
}