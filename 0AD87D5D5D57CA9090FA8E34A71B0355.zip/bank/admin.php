<?php
if(!defined('IN_ROOT')){exit('Access denied');}
include 'source/plugin/bank/config.php';
include 'source/admincp/include/function.php';
Administrator(1);
$action=SafeRequest("action","get");
?>
<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=<?php echo IN_CHARSET; ?>" />
<meta http-equiv="x-ua-compatible" content="ie=7" />
<title>社区银行</title>
<link href="<?php echo IN_PATH; ?>static/admincp/css/main.css" rel="stylesheet" type="text/css" />
<script type="text/javascript" src="<?php echo IN_PATH; ?>static/pack/layer/jquery.js"></script>
<script type="text/javascript" src="<?php echo IN_PATH; ?>static/pack/layer/confirm-lib.js"></script>
<script type="text/javascript">
layer.use('confirm-ext.js');
function s(){
        var k=document.getElementById("search").value;
        if(k==""){
                layer.msg('请输入要查询的关键词！', 1, 0);
                document.getElementById("search").focus();
                return false;
        }else{
                document.btnsearch.submit();
        }
}
function change(type){
        if(type==1){
            document.getElementById("bank_open").style.display='';
        }else{
            document.getElementById("bank_open").style.display='none';
        }
}
function cash_msg(href){
	$.layer({
		shade: [0],
		area: ['auto', 'auto'],
		dialog: {
			msg: '确认已转账给对方？',
			btns: 2,
			type: 4,
			btn: ['确认', '取消'],
			yes: function() {
				location.href = href;
			},
			no: function() {
				layer.msg('已取消操作', 1, 0);
			}
		}
	});
}
</script>
</head>
<body>
<script type="text/javascript">parent.document.title = 'Ear Music Board 管理中心 - 社区银行';if(parent.$('admincpnav')) parent.$('admincpnav').innerHTML='社区银行';</script>
<?php
switch($action){
	case 'keyword':
		$key=SafeRequest("key","get");
		$sql="select * from ".tname('plugin_bank')." where in_uname like '%".$key."%' or in_account like '%".$key."%' order by in_addtime desc";
		cash($sql,20);
		break;
	case 'cash':
		$status=SafeRequest("status","get");
		if(!is_numeric($status)){
		        $sql="select * from ".tname('plugin_bank')." order by in_addtime desc";
		}else{
		        $sql="select * from ".tname('plugin_bank')." where in_status=".intval($status)." order by in_addtime desc";
		}
		cash($sql,20);
		break;
	case 'status':
		status();
		break;
	case 'save':
		save();
		break;
	default:
		main();
		break;
	}
?>
</body>
</html>
<?php
function cash($sql,$size){
	global $db;
	$Arr=getpagerow($sql,$size);
	$result=$Arr[1];
	$count=$Arr[2];
?>
<div class="container">
<div class="floattop"><div class="itemtitle"><h3>提现管理</h3><ul class="tab1">
<li><a href="<?php echo $_SERVER['PHP_SELF']; ?>"><span>社区银行</span></a></li>
<li class="current"><a href="<?php echo $_SERVER['PHP_SELF']; ?>?action=cash"><span>提现管理</span></a></li>
</ul></div></div><div class="floattopempty"></div>
<table class="tb tb2">
<tr><th class="partition">技巧提示</th></tr>
<tr><td class="tipsblock"><ul>
<li>可以输入提现用户、提现账户等关键词进行搜索</li>
</ul></td></tr>
</table>
<table class="tb tb2">
<form name="btnsearch" method="get" action="<?php echo $_SERVER['PHP_SELF']; ?>">
<tr><td>
<input type="hidden" name="action" value="keyword">
关键词：<input class="txt" x-webkit-speech type="text" name="key" id="search" value="" />
<select onchange="location.href=this.options[this.selectedIndex].value;">
<option value="<?php echo $_SERVER['PHP_SELF']; ?>?action=cash">不限状态</option>
<option value="<?php echo $_SERVER['PHP_SELF']; ?>?action=cash&status=0"<?php if(isset($_GET['status']) && $_GET['status']==0){echo " selected";} ?>>待处理</option>
<option value="<?php echo $_SERVER['PHP_SELF']; ?>?action=cash&status=1"<?php if(isset($_GET['status']) && $_GET['status']==1){echo " selected";} ?>>到账</option>
<option value="<?php echo $_SERVER['PHP_SELF']; ?>?action=cash&status=2"<?php if(isset($_GET['status']) && $_GET['status']==2){echo " selected";} ?>>退回</option>
</select>
<input type="button" value="搜索" class="btn" onclick="s()" />
</td></tr>
</form>
</table>
<table class="tb tb2">
<tr class="header">
<th>账户信息</th>
<th>金额</th>
<th>金币</th>
<th>状态</th>
<th>提现用户</th>
<th>提现时间</th>
<th>编辑操作</th>
</tr>
<?php
if($count==0){
?>
<tr><td colspan="2" class="td27">没有提现记录</td></tr>
<?php
}
if($result){
while($row = $db->fetch_array($result)){
?>
<tr class="hover">
<td><?php echo $row['in_type'].'['.$row['in_nick'].':'.$row['in_account'].']'; ?></td>
<td><b><?php echo $row['in_money']; ?></b></td>
<td><?php echo $row['in_points']; ?></td>
<td><?php echo $row['in_status'] > 0 ? $row['in_status'] > 1 ? '退回' : '到账' : '<em class="lightnum">待处理</em>'; ?></td>
<td><a href="<?php echo $_SERVER['PHP_SELF']; ?>?action=keyword&key=<?php echo $row['in_uname']; ?>" class="act"><?php echo ReplaceStr($row['in_uname'],SafeRequest("key","get"),"<em class=\"lightnum\">".SafeRequest("key","get")."</em>"); ?></a></td>
<td><?php if(date('Y-m-d',strtotime($row['in_addtime']))==date('Y-m-d')){echo "<em class=\"lightnum\">".datetime($row['in_addtime'])."</em>";}else{echo datetime($row['in_addtime']);} ?></td>
<?php if($row['in_status'] > 0){ ?>
<td>已处理</td>
<?php }else{ ?>
<td><a class="act" style="cursor:pointer" onclick="cash_msg('<?php echo $_SERVER['PHP_SELF']; ?>?action=status&id=<?php echo $row['in_id']; ?>&status=1');">到账</a><a class="act" style="cursor:pointer" onclick="layer.prompt({title:'拒绝理由',type:3},function(msg){location.href='<?php echo $_SERVER['PHP_SELF']; ?>?action=status&id=<?php echo $row['in_id']; ?>&msg=' + msg + '&status=2';});">退回</a></td>
<?php } ?>
</tr>
<?php
}
}
?>
</table>
<table class="tb tb2">
<?php echo $Arr[0]; ?>
</table>
</div>
<?php } function main(){ ?>
<form method="post" action="<?php echo $_SERVER['PHP_SELF']; ?>?action=save">
<div class="container">
<div class="floattop"><div class="itemtitle"><h3>社区银行</h3><ul class="tab1">
<li class="current"><a href="<?php echo $_SERVER['PHP_SELF']; ?>"><span>社区银行</span></a></li>
<li><a href="<?php echo $_SERVER['PHP_SELF']; ?>?action=cash"><span>提现管理</span></a></li>
</ul></div></div><div class="floattopempty"></div>
<table class="tb tb2">
<tr><th colspan="15" class="partition">插件设置</th></tr>
<tr><td colspan="2" class="td27">插件开关:</td></tr>
<tr><td class="vtop rowform">
<ul>
<?php if(in_plugin_bank_open==1){echo "<li class=\"checked\">";}else{echo "<li>";} ?><input class="radio" type="radio" name="in_plugin_bank_open" value="1" onclick="change(1);"<?php if(in_plugin_bank_open==1){echo " checked";} ?>>&nbsp;开启</li>
<?php if(in_plugin_bank_open==0){echo "<li class=\"checked\">";}else{echo "<li>";} ?><input class="radio" type="radio" name="in_plugin_bank_open" value="0" onclick="change(0);"<?php if(in_plugin_bank_open==0){echo " checked";} ?>>&nbsp;关闭</li>
</ul>
</td><td class="vtop tips2">关闭后将无法访问该插件</td></tr>
<tbody class="sub" id="bank_open"<?php if(in_plugin_bank_open<>1){echo " style=\"display:none;\"";} ?>>
<tr><td colspan="2" class="td27">金币提现汇率换算:</td></tr>
<tr><td class="vtop rowform"><input type="text" class="txt" value="<?php echo in_plugin_bank_rmb_points; ?>" name="in_plugin_bank_rmb_points" onkeyup="this.value=this.value.replace(/[^\d]/g,'')" onbeforepaste="clipboardData.setData('text',clipboardData.getData('text').replace(/[^\d]/g,''))"></td><td class="vtop tips2"><ul><?php if(in_plugin_bank_rmb){echo "<li class=\"checked\">";}else{echo "<li>";} ?>金币/每元<input class="checkbox" type="checkbox" name="in_plugin_bank_rmb" id="bank_rmb" value="1"<?php if(in_plugin_bank_rmb){echo " checked";} ?>><label for="bank_rmb">启用</label></li></ul></td></tr>
<tr><td colspan="2" class="td27">积分兑换汇率换算:</td></tr>
<tr><td class="vtop rowform"><input type="text" class="txt" value="<?php echo in_plugin_bank_points_rank; ?>" name="in_plugin_bank_points_rank" onkeyup="this.value=this.value.replace(/[^\d]/g,'')" onbeforepaste="clipboardData.setData('text',clipboardData.getData('text').replace(/[^\d]/g,''))"></td><td class="vtop tips2">经验/每金币</td></tr>
</tbody>
<tr><td colspan="15"><div class="fixsel"><input type="submit" name="submit" class="btn" value="提交" /></div></td></tr>
</table>
</div>
</form>
<?php } function status(){
	global $db;
	$id=intval(SafeRequest("id","get"));
	$status=intval(SafeRequest("status","get"));
	if($status==2){
		$msg=SafeRequest("msg","get");
		$row=$db->getrow("select * from ".tname('plugin_bank')." where in_id=".$id);
		$db->query("update ".tname('user')." set in_points=in_points+".$row['in_points']." where in_userid=".$row['in_uid']);
		$setarr = array(
			'in_uid' => 0,
			'in_uname' => '系统用户',
			'in_uids' => $row['in_uid'],
			'in_unames' => $row['in_uname'],
			'in_content' => '[提现退回]'.$msg,
			'in_isread' => 0,
			'in_addtime' => date('Y-m-d H:i:s')
		);
		inserttable('message', $setarr, 1);
	}
	$sql="update ".tname('plugin_bank')." set in_status=".$status." where in_id=".$id;
	if($db->query($sql)){
		ShowMessage("恭喜您，提现处理成功！",$_SERVER['HTTP_REFERER'],"infotitle2",3000,1);
	}
} function save(){
        if(!submitcheck('submit')){ShowMessage("表单验证不符，无法提交！",$_SERVER['PHP_SELF'],"infotitle3",3000,1);}
        $str=file_get_contents('source/plugin/bank/config.php');
        $str=preg_replace("/'in_plugin_bank_open', '(.*?)'/", "'in_plugin_bank_open', '".SafeRequest("in_plugin_bank_open","post")."'", $str);
        $str=preg_replace("/'in_plugin_bank_rmb', '(.*?)'/", "'in_plugin_bank_rmb', '".(SafeRequest("in_plugin_bank_rmb","post")==1 ? 1 : 0)."'", $str);
        $str=preg_replace("/'in_plugin_bank_rmb_points', '(.*?)'/", "'in_plugin_bank_rmb_points', '".SafeRequest("in_plugin_bank_rmb_points","post")."'", $str);
        $str=preg_replace("/'in_plugin_bank_points_rank', '(.*?)'/", "'in_plugin_bank_points_rank', '".SafeRequest("in_plugin_bank_points_rank","post")."'", $str);
	$ifile = new iFile('source/plugin/bank/config.php', 'w');
	$ifile->WriteFile($str, 3);
	ShowMessage("恭喜您，设置保存成功！",$_SERVER['HTTP_REFERER'],"infotitle2",1000,1);
}
?>