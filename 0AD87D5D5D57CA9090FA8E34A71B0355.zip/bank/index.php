<?php
if(!defined('IN_ROOT')){exit('Access denied');}
global $db,$userlogined,$erduo_in_userid;
if(!$userlogined){header("location:".rewrite_mode('user.php/people/login/'));exit();}
include 'source/plugin/bank/config.php';
$bank = explode("/", $_SERVER['PATH_INFO']);
?>
<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=<?php echo IN_CHARSET; ?>" />
<title>社区银行 - <?php echo IN_NAME; ?></title>
<script type="text/javascript" src="<?php echo IN_PATH; ?>static/pack/layer/jquery.js"></script>
<script type="text/javascript" src="<?php echo IN_PATH; ?>static/pack/layer/lib.js"></script>
<script type="text/javascript" src="<?php echo IN_PATH; ?>static/user/js/lib.js"></script>
<script type="text/javascript" src="<?php echo IN_PATH; ?>source/plugin/bank/lib.js"></script>
<script type="text/javascript">
function $(obj) {return document.getElementById(obj);}
var in_path = '<?php echo IN_PATH; ?>';
</script>
<style type="text/css">
@import url(<?php echo IN_PATH; ?>static/user/css/style.css);
</style>
</head>
<body>
<?php include 'source/user/people/top.php'; ?>
<div id="main">
<?php include 'source/user/people/left.php'; ?>
<div id="mainarea">
<h2 class="title"><img src="<?php echo IN_PATH; ?>source/plugin/bank/icon.jpg">社区银行</h2>
<?php if(in_plugin_bank_open){ ?>
<div class="tabs_header">
<ul class="tabs">
<li class="active"><a href="<?php echo rewrite_mode('plugin.php/bank/index/'); ?>"><span>社区银行</span></a></li>
</ul>
</div>
<div class="l_status c_form">
<a href="<?php echo rewrite_mode('plugin.php/bank/index/'); ?>"<?php if($bank[3] !== 'rmb'){echo ' class="active"';} ?>>积分兑换</a><span class="pipe">|</span>
<a href="<?php echo rewrite_mode('plugin.php/bank/index/rmb/'); ?>"<?php if($bank[3] == 'rmb'){echo ' class="active"';} ?>>金币提现</a>
</div>
<?php if($bank[3] == 'rmb'){ ?>
<form method="get" onsubmit="points_cash();return false;" class="c_form">
<table cellspacing="0" cellpadding="0" class="formtable">
<tr><th style="width:10em;">登录密码:</th><td><input type="password" id="_password" class="t_input" /><br />提交前请先输入登录密码。</td></tr>
<tr><th style="width:10em;">提现金额:</th><td><input type="text" id="_rmb" class="t_input" onkeyup="this.value=this.value.replace(/[^\d]/g,'')" onbeforepaste="clipboardData.setData('text',clipboardData.getData('text').replace(/[^\d]/g,''))" /><br />单位：元，提现一元将花费 <span style="color:red;font-weight:bold;"><?php echo in_plugin_bank_rmb_points; ?></span> 金币。</td></tr>
<tr><th style="width:10em;">提现账户:</th><td><input type="text" id="_account" class="t_input" /></td></tr>
<tr><th style="width:10em;">账户类型:</th><td><select id="_type"><option value="支付宝">支付宝</option><option value="财付通">财付通</option><option value="微信钱包">微信钱包</option><option value="QQ钱包">QQ钱包</option></select></td></tr>
<tr><th style="width:10em;">账户姓名:</th><td><input type="text" id="_nick" class="t_input" /><br />实名认证名字或网名昵称，方便转账时核对。</td></tr>
<tr><th style="width:10em;"></th><td><input type="submit" value="立即提现" class="submit" /></td></tr>
</table>
<br />
<table cellspacing="0" cellpadding="0" class="listtable">
<thead>
<tr class="title">
<td>账户信息</td>
<td align="center">金额</td>
<td align="center">金币</td>
<td align="center">状态</td>
<td align="center">提现时间</td>
</tr>
</thead>
<tr class="line"></tr>
<?php
$Arr = getuserpage("select * from ".tname('plugin_bank')." where in_uid=".$erduo_in_userid." order by in_addtime desc", 20, 4);
$result = $Arr[1];
$count = $Arr[2];
?>
<?php
if($count == 0){
?>
<tr><td>暂无记录</td></tr>
<?php
}
if($result){
while($row = $db->fetch_array($result)){
?>
<tr>
<td><?php echo $row['in_type'].'['.$row['in_nick'].':'.$row['in_account'].']'; ?></td>
<td align="center"><?php echo $row['in_money']; ?></td>
<td align="center"><?php echo $row['in_points']; ?></td>
<td align="center"><?php echo $row['in_status'] > 0 ? $row['in_status'] > 1 ? '<font color="red">退回</font>' : '<font color="green">到账</font>' : '<font color="blue">待处理</font>'; ?></td>
<td align="center"><?php echo datetime($row['in_addtime']); ?></td>
</tr>
<?php
}
}
?>
</table>
</form>
<?php echo $Arr[0]; ?>
<?php }else{ ?>
<form method="get" onsubmit="convert_credit();return false;" class="c_form">
<table cellspacing="0" cellpadding="0" class="formtable">
<tr><th style="width:10em;">登录密码:</th><td><input type="password" id="_password" class="t_input" /><br />提交前请先输入登录密码。</td></tr>
<tr><th style="width:10em;">转换类型:</th><td><select id="_type"><option value="0">经验转换金币</option><option value="1">金币转换经验</option></select></td></tr>
<tr><th style="width:10em;">兑换数量:</th><td><input type="text" id="_num" class="t_input" onkeyup="this.value=this.value.replace(/[^\d]/g,'')" onbeforepaste="clipboardData.setData('text',clipboardData.getData('text').replace(/[^\d]/g,''))" /><br />单位：个，兑换1个金币需要扣除 <span style="color:red;font-weight:bold;"><?php echo in_plugin_bank_points_rank; ?></span> 经验，反之转换汇率同等。金币转换经验将采用向上取整，请谨慎选择！</td></tr>
<tr><th style="width:10em;"></th><td><input type="submit" value="立即兑换" class="submit" /></td></tr>
</table>
</form>
<?php } ?>
<?php }else{ ?>
<div class="showmessage"><div class="ye_r_t"><div class="ye_l_t"><div class="ye_r_b"><div class="ye_l_b">
<caption><h2>信息提示</h2></caption>
<p>抱歉，该插件暂未开启！</p>
</div></div></div></div></div>
<?php } ?>
</div>
<div id="bottom"></div>
</div>
<?php include 'source/user/people/bottom.php'; ?>
</body>
</html>