<?php
define('in_plugin_bank_open', '1');
define('in_plugin_bank_rmb', '1');
define('in_plugin_bank_rmb_points', '100');
define('in_plugin_bank_points_rank', '10');
?>