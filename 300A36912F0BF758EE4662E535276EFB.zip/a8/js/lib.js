(function() {
        lib = {
                egg:function(_id) {
                        var left = parseInt($("span.msg").offset().left), top = parseInt($("span.msg").offset().top), lefts = parseInt($("span.hits").offset().left), tops = parseInt($("span.hits").offset().top);
                        $("span.msg").hide();
                        $("div.play_zhuan").append('<span class="tips">+1</span>');
                        $("span.tips").css({
                                position:"absolute",
                                "z-index":"1",
                                color:"#ff5500",
                                left:left + "px",
                                top:top + "px"
                        }).animate({
                                top:tops,
                                left:lefts
                        }, "slow", function() {
                                $("span.tips").fadeIn("fast").remove();
                                getlove(_id, "good");
                                getlove(_id, "bad");
                        });
                },
                init:function() {
                        this.search({
                                inputid:"#sq",
                                btn:"#hsearch",
                                lid:"#st",
                                selected_a:"#search_option_selected a",
                                list:"#search_option_list"
                        });
                        this.search({
                                inputid:"#footsq",
                                btn:"#fsearch",
                                lid:"#footst",
                                selected_a:"#footsearch_option_selected a",
                                list:"#footsearch_option_list"
                        });
                },
                tab:function(options) {
                        var settings = $.extend({
                                id:"",
                                actcss:"tab_act",
                                nolcss:"tab_nol",
                                idpre:"#tabMenu_Content"
                        }, options || {});
                        var $this = $(settings.id);
                        var $$this = $this.children();
                        return $$this.each(function() {
                                $(this).click(function() {
                                        var idx = $(this).index();
                                        var len = $$this.length;
                                        if ($(this).attr("class") == settings.actcss) return;
                                        $$this.eq(idx).removeClass(settings.nolcss).addClass(settings.actcss).siblings().removeClass(settings.actcss).addClass(settings.nolcss);
                                        for (var i = 0; i < len; i++) {
                                                if (idx == i) {
                                                        $(settings.idpre + i).show();
                                                } else {
                                                        $(settings.idpre + i).hide();
                                                }
                                        }
                                });
                        });
                },
                scroll:function(options) {
                        var settings = $.extend({
                                rightid:"",
                                leftid:"",
                                wndid:"",
                                contid:"",
                                type:"left",
                                ftx:"li",
                                num:3
                        }, options || {});
                        var page = 1;
                        $(settings.rightid).click(function() {
                                var $pictureShow = $(settings.wndid);
                                var downwidth = settings.type == "top" ? $pictureShow.height() :$pictureShow.width();
                                var len = $(settings.contid).find(settings.ftx).length;
                                var page_number = Math.ceil(len / settings.num);
                                if (!$(settings.contid).is(":animated")) {
                                        if (page == page_number) {
                                                if (settings.type == "top") {
                                                        $(settings.contid).animate({
                                                                top:"0px"
                                                        }, "slow");
                                                } else {
                                                        $(settings.contid).animate({
                                                                left:"0px"
                                                        }, "slow");
                                                }
                                                page = 1;
                                        } else {
                                                if (settings.type == "top") {
                                                        $(settings.contid).animate({
                                                                top:"-=" + downwidth
                                                        }, "slow");
                                                } else {
                                                        $(settings.contid).animate({
                                                                left:"-=" + downwidth
                                                        }, "slow");
                                                }
                                                page++;
                                        }
                                }
                        });
                        $(settings.leftid).click(function() {
                                var $pictureShow = $(settings.wndid);
                                var downwidth = settings.type == "top" ? $pictureShow.height() :$pictureShow.width();
                                var len = $(settings.contid).find(settings.ftx).length;
                                var page_number = Math.ceil(len / settings.num);
                                if (!$(settings.contid).is(":animated")) {
                                        if (page == 1) {
                                                if (settings.type == "top") {
                                                        $(settings.contid).animate({
                                                                top:"-=" + downwidth * (page_number - 1)
                                                        }, "slow");
                                                } else {
                                                        $(settings.contid).animate({
                                                                left:"-=" + downwidth * (page_number - 1)
                                                        }, "slow");
                                                }
                                                page = page_number;
                                        } else {
                                                if (settings.type == "top") {
                                                        $(settings.contid).animate({
                                                                top:"+=" + downwidth
                                                        }, "slow");
                                                } else {
                                                        $(settings.contid).animate({
                                                                left:"+=" + downwidth
                                                        }, "slow");
                                                }
                                                page--;
                                        }
                                }
                        });
                },
                select:function(options) {
                        var settings = $.extend({
                                id:"",
                                name:"",
                                value_id:""
                        }, options || {});
                        var $this = $(settings.id);
                        $('input[name="' + settings.name + '"]').each(function() {
                                $(this).click(function() {
                                        var k = i = 0;
                                        var str = _str = "";
                                        $('input[name="' + settings.name + '"]').each(function() {
                                                if ($(this).attr("checked") == "checked") {
                                                        k++;
                                                        _str += $(this).val() + ",";
                                                }
                                                i++;
                                        });
                                        str = _str.substr(0, _str.length - 1);
                                        $this.attr("checked", k == i ? true :false);
                                        $(settings.value_id).val(str);
                                });
                        });
                        return $this.click(function() {
                                var flag = $(this).attr("checked") == "checked" ? true :false;
                                var str = _str = "";
                                $('input[name="' + settings.name + '"]').each(function() {
                                        $(this).attr("checked", flag);
                                        if (flag) _str += $(this).val() + ",";
                                });
                                str = _str.substr(0, _str.length - 1);
                                $(settings.value_id).val(str);
                        });
                },
                search:function(options) {
                        var settings = $.extend({
                                inputid:"",
                                btn:"",
                                lid:"",
                                selected_a:"#search_option_selected a",
                                list:"#search_option_list",
                                css:"selected"
                        }, options || {});
                        $(settings.selected_a).click(function() {
                                $(settings.list).toggle();
                                $(this).blur();
                        });
                        $(settings.list + " li a").click(function() {
                                $(this).blur().parent("li").addClass(settings.css).siblings("li.selected").removeClass(settings.css);
                                $(settings.selected_a).text($(this).text());
                                $(settings.list).hide();
                                $(settings.inputid).focus();
                        });
                        $(settings.inputid).keyup(function(event) {
                                if (event.keyCode == 13) {
                                        $(settings.btn).click();
                                }
                        }).focus(function() {
                                if ($.trim($(this).val()) == "�������ѯ�ؼ��֣�") {
                                        $(this).val("");
                                }
                        }).blur(function() {
                                if ($.trim($(this).val()) == "") {
                                        $(this).val("�������ѯ�ؼ��֣�");
                                }
                        });
                        $(settings.btn).click(function() {
                                var k = $(settings.inputid), v = $(settings.lid).text(), b = {
                                        "����":"music",
                                        "ר��":"special",
                                        "����":"singer",
                                        "��Ƶ":"video"
                                }[v] || "1", d = $.trim(k.val());
                                d = d.replace(/\//g, "");
                                d = d.replace(/\\/g, "");
                                d = d.replace(/\?/g, "");
                                var _url = search_url.replace(/target/g, d);
                                _url = _url.replace(/table/g, b);
                                if (d.length == 0 || d == "�������ѯ�ؼ��֣�") {
                                        k.val("�������ѯ�ؼ��֣�");
                                        k.focus();
                                        return false;
                                }
                                location.href = _url;
                                return true;
                        });
                },
                musicPlayer:function(ids) {
                        ids = ids.replace(/\,/g, "/");
                        ids = play_url.replace(/player/g, ids);
                        window.open(ids);
                },
                playerObj:function(obj) {
                        var mIdSrt = "";
                        $("#" + obj + " :checkbox").each(function() {
                                if ($(this).attr("checked")) {
                                        mIdSrt += $(this).val() + "/";
                                }
                        });
                        if (mIdSrt) {
                                var ids = mIdSrt.substr(0, mIdSrt.length - 1);
                                ids = play_url.replace(/player/g, ids);
                                window.open(ids);
                        } else {
                                asyncbox.tips("�����б�Ϊ�գ�", "wait", 1e3);
                        }
                },
                hover:function(options) {
                        var settings = $.extend({
                                id:".mcln_list li",
                                css:"hover"
                        }, options || {});
                        $(settings.id).hover(function() {
                                $(this).addClass(settings.css);
                        }, function() {
                                $(this).removeClass(settings.css);
                        });
                },
                menu:function(options) {
                        var settings = $.extend({
                                id:"li.mainlevel",
                                nid:".nol_nav"
                        }, options || {});
                        $(settings.id).mousemove(function() {
                                $(this).find("ul").show();
                                $(settings.nid).hide();
                        }).mouseleave(function() {
                                $(this).find("ul").hide();
                                $(settings.nid).show();
                        });
                },
                submit:function(options) {
                        var settings = $.extend({
                                id:"",
                                formid:""
                        }, options || {});
                        $(settings.id).click(function() {
                                $(settings.formid).submit();
                        });
                },
                toggle:function(options) {
                        var settings = $.extend({
                                id:"",
                                lid:"",
                                cid:"",
                                height:"100px",
                                hcss:"itemsHide",
                                scss:"itemsShow"
                        }, options || {});
                        $(settings.id).toggle(function() {
                                $(this).addClass(settings.hcss).removeClass(settings.scss);
                                $(settings.lid).css("height", $(settings.cid).height());
                        }, function() {
                                $(this).addClass(settings.scss).removeClass(settings.hcss);
                                $(settings.lid).css("height", settings.height);
                        });
                }
        };
})();
$(function() {
        lib.init();
        $("a").bind("focus", function() {
                if (this.blur) {
                        this.blur();
                }
        });
});
function processResponse() {
        if (XMLHttpReq.readyState == 4) {
                if (XMLHttpReq.status == 200) {
                        var tips = XMLHttpReq.responseText;
                        if (tips == "return_0") {
                                asyncbox.tips("�ʼ���������δ����������ϵ����Ա��", "wait", 3e3);
                        } else if (tips == "return_5") {
                                $.close("login");
                                uc_syn("login");
                                get_login();
                        } else if (tips == "return_6") {
                                asyncbox.tips("��Ǹ�������ʺ��Ѿ���������", "wait", 3e3);
                        } else if (tips == "return_9") {
                                $.close("login");
                                uc_syn("login");
                                get_login();
                        } else if (tips == "return_10") {
                                asyncbox.tips("�ʺŻ�������������ԣ�", "error", 3e3);
                        } else if (tips == "return_11") {
                                asyncbox.tips("�ʺ��Ѿ���ע�ᣬ�����һ����", "error", 3e3);
                        } else if (tips == "return_12") {
                                asyncbox.tips("�����Ѿ���ռ�ã������һ����", "error", 3e3);
                        } else if (tips == "return_13") {
                                asyncbox.tips("UCenter API: �û������Ϸ���", "error", 3e3);
                        } else if (tips == "return_14") {
                                asyncbox.tips("UCenter API: ����������ע��Ĵ��", "error", 3e3);
                        } else if (tips == "return_15") {
                                asyncbox.tips("UCenter API: �û����Ѿ����ڣ�", "error", 3e3);
                        } else if (tips == "return_16") {
                                asyncbox.tips("UCenter API: Email ��ʽ����", "error", 3e3);
                        } else if (tips == "return_17") {
                                asyncbox.tips("UCenter API: Email ������ע�ᣡ", "error", 3e3);
                        } else if (tips == "return_18") {
                                asyncbox.tips("UCenter API: Email �Ѿ���ע�ᣡ", "error", 3e3);
                        } else if (tips == "return_19") {
                                asyncbox.tips("UCenter API: ����δ���壡", "error", 3e3);
                        } else if (tips == "return_20") {
                                $.close("register");
                                get_login();
                        } else if (tips == "return_21") {
                                asyncbox.tips("��¼�ʺŲ����ڣ���������ԣ�", "error", 3e3);
                        } else if (tips == "return_22") {
                                asyncbox.tips("��֤��Ϣ��ƥ�䣬�����ԣ�", "error", 3e3);
                        } else if (tips == "return_23") {
                                lostRequest(2);
                        } else if (tips == "logout") {
                                uc_syn("logout");
                                get_login();
                        } else {
                                asyncbox.tips("�ڲ����ִ������Ժ����ԣ�", "error", 3e3);
                        }
                } else {
                        asyncbox.tips("ͨѶ�쳣�������������ã�", "error", 3e3);
                }
        }
}
function createXMLHttpRequest() {
	try {
		XMLHttpReq = new ActiveXObject('Msxml2.XMLHTTP');
	} catch(e) {
		try {
			XMLHttpReq = new ActiveXObject('Microsoft.XMLHTTP');
		} catch(e) {
			XMLHttpReq = new XMLHttpRequest();
		}
	}
}
function getHttpObject() {
        var objType = false;
        try {
                objType = new ActiveXObject("Msxml2.XMLHTTP");
        } catch (e) {
                try {
                        objType = new ActiveXObject("Microsoft.XMLHTTP");
                } catch (e) {
                        objType = new XMLHttpRequest();
                }
        }
        return objType;
}
function uc_syn(type) {
        var theHttpRequest = getHttpObject();
        theHttpRequest.onreadystatechange = function() {
                processAJAX();
        };
        theHttpRequest.open("GET", in_path + "source/user/people/syn.php?uc=" + type, true);
        theHttpRequest.send(null);
        function processAJAX() {
                if (theHttpRequest.readyState == 4) {
                        if (theHttpRequest.status == 200) {
				var src = theHttpRequest.responseText.match(/src=".*?"/g);
				if (src) {
					for (i = 0; i < src.length; i++) {
						var ucenter = document.createElement("script");
						ucenter.type = "text/javascript";
						ucenter.src = src[i].match(/src="([^"]*)"/)[1];
						document.getElementsByTagName("head")[0].appendChild(ucenter);
					}
				}
                        }
                }
        }
}
function logout() {
        createXMLHttpRequest();
        XMLHttpReq.open("GET", temp_url + "source/ajax.php?ac=logout", true);
        XMLHttpReq.onreadystatechange = processResponse;
        XMLHttpReq.send(null);
}
function get_login() {
        var theHttpRequest = getHttpObject();
        theHttpRequest.onreadystatechange = function() {
                processAJAX();
        };
        theHttpRequest.open("GET", temp_url + "source/ajax_login.php", true);
        theHttpRequest.send(null);
        function processAJAX() {
                if (theHttpRequest.readyState == 4) {
                        if (theHttpRequest.status == 200) {
                                document.getElementById("getlogin").innerHTML = theHttpRequest.responseText;
                        } else {
                                document.getElementById("getlogin").innerHTML = "�����쳣...";
                        }
                }
        }
}
function QQLogin() {
        $.close("login");
        asyncbox.open({
                id:"popQQLogin",
                title:"QQ��¼",
                url:in_path + "source/pack/connect/login.php",
                width:726,
                height:450,
                modal:true,
                btnsbar:$.btn.close
        });
}
function qzone_return(type) {
        $.close("popQQLogin");
        if (type == 1) {
                uc_syn("login");
                get_login();
        } else {
                location.href = connect_url;
        }
}
function pop_login() {
        asyncbox.open({
                id:"login",
                modal:true,
                drag:true,
                width:480,
                height:260,
                title:"�û���¼",
                html:'<div class="popLoginForm form-box"><div class="fl"><ul><li class="form-item clearfix"><label class="label">�ʺţ�</label><input type="text" class="input" id="login-name" /></li><li class="form-item clearfix"><label class="label">���룺</label><input type="password" class="input" id="login-pwd" /></li><li class="form-item clearfix remember"><label class="label">&nbsp;</label><a onclick="QQLogin();" style="cursor:pointer;"><span style="vertical-align:middle;"><img src="' + temp_url + 'css/connect.gif" width="16" height="16"/></span>&nbsp;QQ��¼</a>&nbsp;&nbsp;&nbsp;<a onclick="pop_lostpasswd();" style="cursor:pointer;">�������룿</a></li></ul><div class="popLoginBtn"><a href="javascript:void(0)" onclick="ginRequest(0);" id="popLoginBtn">��¼</a></div></div></div>'
        });
}
function pop_lostpasswd() {
        $.close("login");
        asyncbox.open({
                id:"lostpasswd",
                modal:true,
                drag:true,
                width:480,
                height:260,
                title:"�һ�����",
                html:'<div class="popLoginForm form-box"><div class="fl"><ul><li class="form-item clearfix"><label class="label">��¼�ʺţ�</label><input type="text" class="input" id="lost-name" /></li><li class="form-item clearfix"><label class="label">�ܱ����䣺</label><input type="text" class="input" id="lost-mail" /></li><li class="form-item clearfix remember"><label class="label">&nbsp;</label><span id="losttips">ע�⣺�����ַ�����͵��ܱ�����</span></li></ul><div class="popLoginBtn"><a href="javascript:void(0)" onclick="lostRequest(1);" id="popLoginBtn">��ʼ��֤</a></div></div></div>'
        });
}
function pop_register() {
        asyncbox.open({
                id:"register",
                modal:true,
                drag:true,
                width:490,
                height:310,
                title:"ע���ʺ�",
                html:'<div class="popLoginForm form-box"><div class="fl"><ul><li class="form-item clearfix"><label class="label">�ʺţ�</label><input type="text" class="input" id="reg-name" /></li><li class="form-item clearfix"><label class="label">���룺</label><input type="text" class="input" id="reg-pwd" /></li><li class="form-item clearfix"><label class="label">���䣺</label><input type="text" class="input" id="reg-mail" /></li><li class="form-item clearfix remember"><label class="label">&nbsp;</label><span id="regtips">����ʹ����ʵ���������ע��</span></li></ul><div class="popLoginBtn"><a href="javascript:void(0)" onclick="regRequest();" id="popLoginBtn">ע��</a></div></div></div>'
        });
}
function ginRequest(type) {
        var _name = document.getElementById("login-name").value;
        var _pwd = document.getElementById("login-pwd").value;
        if (_name == "") {
                document.getElementById("login-name").focus();
                return;
        } else if (_pwd == "") {
                document.getElementById("login-pwd").focus();
                return;
        }
        createXMLHttpRequest();
        XMLHttpReq.open("GET", in_path + "source/user/people/ajax.php?ac=login&qq=" + type + "&name=" + escape(_name) + "&pwd=" + escape(_pwd), true);
        XMLHttpReq.onreadystatechange = processResponse;
        XMLHttpReq.send(null);
}
function lostRequest(type) {
        if (type == 1) {
                var username = document.getElementById("lost-name");
                if (strLen(username.value) < 1) {
                        document.getElementById("losttips").innerHTML = '<font color="#ff5500">�������¼�ʺ�</font>';
                        username.focus();
                        return;
                }
                var mail = document.getElementById("lost-mail");
                if (strLen(mail.value) < 1 || isEmail(mail.value) == false) {
                        document.getElementById("losttips").innerHTML = '<font color="#ff5500">��������ȷ���ܱ�����</font>';
                        mail.focus();
                        return;
                }
                createXMLHttpRequest();
                XMLHttpReq.open("GET", in_path + "source/user/people/ajax.php?ac=lostpasswd&type=1&name=" + escape(username.value) + "&mail=" + escape(mail.value), true);
                XMLHttpReq.onreadystatechange = processResponse;
                XMLHttpReq.send(null);
        } else if (type == 2) {
                createXMLHttpRequest();
                XMLHttpReq.open("GET", in_path + "source/user/people/ajax.php?ac=lostpasswd&type=2", true);
                XMLHttpReq.onreadystatechange = function() {
                        if (XMLHttpReq.readyState == 4) {
                                if (XMLHttpReq.status == 200) {
                                        if (XMLHttpReq.responseText == "return_26") {
                                                asyncbox.tips("�ʼ��Ѿ���������ȴ� 30 ���ſ����·��ͣ�", "wait", 3e3);
                                        } else if (XMLHttpReq.responseText == "return_28") {
                                                document.getElementById("losttips").innerHTML = '<font color="#259b24">��ϲ���ʼ��Ѿ����ͳɹ���</font>';
                                        } else {
                                                document.getElementById("losttips").innerHTML = '<font color="#ff5500">��Ǹ���ʼ�δ�ܷ��ͳɹ���</font>';
                                        }
                                } else {
                                        asyncbox.tips("ͨѶ�쳣�������������ã�", "error", 3e3);
                                }
                        }
                };
                XMLHttpReq.send(null);
        }
}
function regRequest() {
        var _name = document.getElementById("reg-name").value;
        var _pwd = document.getElementById("reg-pwd").value;
        var _mail = document.getElementById("reg-mail").value;
        if (!/^([\S])*$/.test(_name) || !/^([^<>'"\/\\])*$/.test(_name)) {
                document.getElementById("regtips").innerHTML = '<font color="#ff5500">�ʺŲ��ܰ����ո�� < > \' " / \\ ��</font>';
                document.getElementById("reg-name").focus();
                return;
        } else if (strLen(_name) < 3 || strLen(_name) > 15) {
                document.getElementById("regtips").innerHTML = '<font color="#ff5500">�ʺŽ���3��15���ַ�֮��</font>';
                document.getElementById("reg-name").focus();
                return;
        } else if (strLen(_pwd) < 6) {
                document.getElementById("regtips").innerHTML = '<font color="#ff5500">���벻�ܵ���6λ</font>';
                document.getElementById("reg-pwd").focus();
                return;
        } else if (strLen(_mail) < 1 || isEmail(_mail) == false) {
                document.getElementById("regtips").innerHTML = '<font color="#ff5500">��������ȷ������</font>';
                document.getElementById("reg-mail").focus();
                return;
        } else if (reg_open < 1) {
                asyncbox.tips("��վ��δ����ע�ᣬ����ϵ����Ա��", "wait", 3e3);
                return;
        }
        createXMLHttpRequest();
        XMLHttpReq.open("GET", in_path + "source/user/people/ajax.php?ac=register&name=" + escape(_name) + "&pwd=" + escape(_pwd) + "&mail=" + escape(_mail), true);
        XMLHttpReq.onreadystatechange = processResponse;
        XMLHttpReq.send(null);
}
function getplay() {
        var theHttpRequest = getHttpObject();
        theHttpRequest.onreadystatechange = function() {
                processAJAX();
        };
        theHttpRequest.open("GET", temp_url + "source/ajax_play.php", true);
        theHttpRequest.send(null);
        function processAJAX() {
                if (theHttpRequest.readyState == 4) {
                        if (theHttpRequest.status == 200) {
                                document.getElementById("_play").innerHTML = theHttpRequest.responseText;
                        } else {
                                document.getElementById("_play").innerHTML = "�����쳣...";
                        }
                }
        }
}
function getmusician(_id, _type) {
        var theHttpRequest = getHttpObject();
        theHttpRequest.onreadystatechange = function() {
                processAJAX();
        };
        theHttpRequest.open("GET", temp_url + "source/ajax_musician.php?ac=" + _type + "&id=" + _id, true);
        theHttpRequest.send(null);
        function processAJAX() {
                if (theHttpRequest.readyState == 4) {
                        if (theHttpRequest.status == 200) {
                                document.getElementById("_" + _type).innerHTML = theHttpRequest.responseText;
                        } else {
                                document.getElementById("_" + _type).innerHTML = "�����쳣...";
                        }
                }
        }
}
function getlove(_id, _type) {
        var theHttpRequest = getHttpObject();
        theHttpRequest.onreadystatechange = function() {
                processAJAX();
        };
        theHttpRequest.open("GET", temp_url + "source/ajax_love.php?ac=" + _type + "&id=" + _id, true);
        theHttpRequest.send(null);
        function processAJAX() {
                if (theHttpRequest.readyState == 4) {
                        if (theHttpRequest.status == 200) {
                                document.getElementById("_" + _type).innerHTML = theHttpRequest.responseText;
                        } else {
                                document.getElementById("_" + _type).innerHTML = "�����쳣...";
                        }
                }
        }
}
function up_love(_id, _do) {
        createXMLHttpRequest();
        XMLHttpReq.open("GET", temp_url + "source/ajax_love.php?ac=love&id=" + _id + "&do=" + _do, true);
        XMLHttpReq.onreadystatechange = function() {
                if (XMLHttpReq.readyState == 4) {
                        if (XMLHttpReq.status == 200) {
                                if (XMLHttpReq.responseText == "return_1") {
                                        asyncbox.tips("���ֲ����ڻ��ѱ�ɾ����", "error", 3e3);
                                } else if (XMLHttpReq.responseText == "return_2") {
                                        asyncbox.tips("��Ϣ��ɣ����Ѿ�������������", "wait", 3e3);
                                } else if (XMLHttpReq.responseText == "return_3") {
                                        getlove(_id, "good");
                                        getlove(_id, "bad");
                                } else if (XMLHttpReq.responseText == "return_4") {
                                        lib.egg(_id);
                                } else {
                                        asyncbox.tips("�ڲ����ִ������Ժ����ԣ�", "error", 3e3);
                                }
                        } else {
                                asyncbox.tips("ͨѶ�쳣�������������ã�", "error", 3e3);
                        }
                }
        };
        XMLHttpReq.send(null);
}
function create_down(_id) {
        createXMLHttpRequest();
        XMLHttpReq.open("GET", temp_url + "source/ajax.php?ac=down&id=" + _id, true);
        XMLHttpReq.onreadystatechange = function() {
                if (XMLHttpReq.readyState == 4) {
                        if (XMLHttpReq.status == 200) {
                                if (XMLHttpReq.responseText == "return_0") {
                                        pop_login();
                                } else if (XMLHttpReq.responseText == "return_1") {
                                        asyncbox.tips("Ȩ�޲������뿪ͨ���꣡", "wait", 3e3);
                                } else if (XMLHttpReq.responseText == "return_2") {
                                        asyncbox.tips("��Ҳ��㣬���ȳ�ֵ��", "wait", 3e3);
                                } else if (XMLHttpReq.responseText == "return_3") {
                                        asyncbox.tips("���ֲ����ڻ��ѱ�ɾ����", "error", 3e3);
                                } else if (XMLHttpReq.responseText == "return_4") {
                                        location.href = temp_url + "source/audio.php?id=" + _id;
                                } else {
                                        asyncbox.tips("�ڲ����ִ������Ժ����ԣ�", "error", 3e3);
                                }
                        } else {
                                asyncbox.tips("ͨѶ�쳣�������������ã�", "error", 3e3);
                        }
                }
        };
        XMLHttpReq.send(null);
}
function create_fav(_id) {
        createXMLHttpRequest();
        XMLHttpReq.open("GET", temp_url + "source/ajax.php?ac=fav&id=" + _id, true);
        XMLHttpReq.onreadystatechange = function() {
                if (XMLHttpReq.readyState == 4) {
                        if (XMLHttpReq.status == 200) {
                                if (XMLHttpReq.responseText == "return_0") {
                                        pop_login();
                                } else if (XMLHttpReq.responseText == "return_1") {
                                        asyncbox.tips("���ֲ����ڻ��ѱ�ɾ����", "error", 3e3);
                                } else if (XMLHttpReq.responseText == "return_2") {
                                        asyncbox.tips("��ϲ�������ղسɹ���", "success", 1e3);
                                } else {
                                        asyncbox.tips("�ڲ����ִ������Ժ����ԣ�", "error", 3e3);
                                }
                        } else {
                                asyncbox.tips("ͨѶ�쳣�������������ã�", "error", 3e3);
                        }
                }
        };
        XMLHttpReq.send(null);
}
function create_error(_id) {
        createXMLHttpRequest();
        XMLHttpReq.open("GET", temp_url + "source/ajax.php?ac=error&id=" + _id, true);
        XMLHttpReq.onreadystatechange = function() {
                if (XMLHttpReq.readyState == 4) {
                        if (XMLHttpReq.status == 200) {
                                if (XMLHttpReq.responseText == "return_0") {
                                        pop_login();
                                } else if (XMLHttpReq.responseText == "return_1") {
                                        asyncbox.tips("���ֲ����ڻ��ѱ�ɾ����", "error", 3e3);
                                } else if (XMLHttpReq.responseText == "return_2") {
                                        asyncbox.tips("��ϲ�����־ٱ��ɹ���", "success", 1e3);
                                } else {
                                        asyncbox.tips("�ڲ����ִ������Ժ����ԣ�", "error", 3e3);
                                }
                        } else {
                                asyncbox.tips("ͨѶ�쳣�������������ã�", "error", 3e3);
                        }
                }
        };
        XMLHttpReq.send(null);
}
function send_comment(_id) {
        var _content = document.getElementById("_content").value;
        if (strLen(_content) < 6) {
                document.getElementById("_tips").innerHTML = "������������<em>6</em>���ַ���";
                return;
        } else if (strLen(_content) > 128) {
                document.getElementById("_tips").innerHTML = "�����������<em>128</em>���ַ���";
                return;
        } else {
                document.getElementById("_tips").innerHTML = "��<em>����</em>���ԣ�";
        }
        createXMLHttpRequest();
        XMLHttpReq.open("GET", temp_url + "source/ajax.php?ac=comment&id=" + _id + "&content=" + escape(_content), true);
        XMLHttpReq.onreadystatechange = function() {
                if (XMLHttpReq.readyState == 4) {
                        if (XMLHttpReq.status == 200) {
                                if (XMLHttpReq.responseText == "return_0") {
                                        parent.pop_login();
                                } else if (XMLHttpReq.responseText == "return_1") {
                                        asyncbox.tips("���ֲ����ڻ��ѱ�ɾ����", "error", 3e3);
                                } else if (XMLHttpReq.responseText == "return_2") {
                                        document.getElementById("_tips").innerHTML = "ÿ�����ۼ��ʱ��Ϊ<em>30</em>�룡";
                                } else if (XMLHttpReq.responseText == "return_3") {
                                        location.reload();
                                } else {
                                        asyncbox.tips("�ڲ����ִ������Ժ����ԣ�", "error", 3e3);
                                }
                        } else {
                                asyncbox.tips("ͨѶ�쳣�������������ã�", "error", 3e3);
                        }
                }
        };
        XMLHttpReq.send(null);
}
function strLen(str) {
        var charset = document.charset;
        var len = 0;
        for (var i = 0; i < str.length; i++) {
                len += str.charCodeAt(i) < 0 || str.charCodeAt(i) > 255 ? charset == "gbk" ? 3 :2 :1;
        }
        return len;
}
function isEmail(input) {
        if (input.match(/^([a-zA-Z0-9_\.\-])+\@(([a-zA-Z0-9\-])+\.)+([a-zA-Z0-9]{2,4})+$/)) {
                return true;
        }
        return false;
}