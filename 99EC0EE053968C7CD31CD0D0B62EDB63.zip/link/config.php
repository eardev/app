<?php
define('in_plugin_link_open', '1');
?>