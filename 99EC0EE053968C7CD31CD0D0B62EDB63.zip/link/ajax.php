<?php
include '../../system/db.class.php';
header("Expires: Mon, 26 Jul 1997 05:00:00 GMT");
header("Cache-Control: no-cache, must-revalidate");
header("Pragma: no-cache");
header("Content-type: text/html;charset=".IN_CHARSET);
$name = unescape(SafeRequest("name","get"));
$link = unescape(SafeRequest("link","get"));
$type = SafeRequest("type","get");
$cover = checkrename(unescape(SafeRequest("cover","get")), 'attachment/link/cover');
$cookie = 'in_plugin_link';
if(!empty($_COOKIE[$cookie])){
	exit('return_1');
}
setcookie($cookie, 'have', time()+30, IN_PATH);
$setarr = array('in_name' => $name, 'in_url' => $link, 'in_cover' => $cover, 'in_type' => $type, 'in_hide' => 1, 'in_order' => 0);
inserttable('link', $setarr, 1);
echo 'return_2';
?>