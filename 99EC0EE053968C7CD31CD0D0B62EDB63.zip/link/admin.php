<?php
if(!defined('IN_ROOT')){exit('Access denied');}
include 'source/plugin/link/config.php';
include 'source/admincp/include/function.php';
Administrator(1);
$action=SafeRequest("action","get");
?>
<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=<?php echo IN_CHARSET; ?>" />
<meta http-equiv="x-ua-compatible" content="ie=7" />
<title>��������</title>
<link href="<?php echo IN_PATH; ?>static/admincp/css/main.css" rel="stylesheet" type="text/css" />
<script type="text/javascript">function $(obj) {return document.getElementById(obj);}</script>
</head>
<body>
<?php
switch($action){
	case 'save':
		save();
		break;
	default:
		main();
		break;
	}
?>
</body>
</html>
<?php function main(){ ?>
<form method="post" action="<?php echo $_SERVER['PHP_SELF']; ?>?action=save">
<div class="container">
<script type="text/javascript">parent.document.title = 'Ear Music Board �������� - ��������';if(parent.$('admincpnav')) parent.$('admincpnav').innerHTML='��������';</script>
<div class="floattop"><div class="itemtitle"><h3>��������</h3></div></div><div class="floattopempty"></div>
<table class="tb tb2">
<tr><th colspan="15" class="partition">�������</th></tr>
<tr><td colspan="2" class="td27">�������:</td></tr>
<tr><td class="vtop rowform">
<select name="in_plugin_link_open">
<option value="0">�ر�</option>
<option value="1"<?php if(in_plugin_link_open==1){echo " selected";} ?>>����</option>
</select>
</td><td class="vtop tips2">�رպ��޷����ʸò��</td></tr>
<tr><td colspan="15"><div class="fixsel"><input type="submit" name="submit" class="btn" value="�ύ" /></div></td></tr>
</table>
</div>
</form>
<?php } function save(){
        if(!submitcheck('submit')){ShowMessage("������֤�������޷��ύ��",$_SERVER['PHP_SELF'],"infotitle3",3000,1);}
        $str=file_get_contents('source/plugin/link/config.php');
        $str=preg_replace("/'in_plugin_link_open', '(.*?)'/", "'in_plugin_link_open', '".SafeRequest("in_plugin_link_open","post")."'", $str);
	$ifile = new iFile('source/plugin/link/config.php', 'w');
	$ifile->WriteFile($str, 3);
	ShowMessage("��ϲ�������ñ���ɹ���",$_SERVER['HTTP_REFERER'],"infotitle2",1000,1);
}
?>