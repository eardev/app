function plugin_link() {
        var name = $("in_name").value;
        if (name == "") {
                layer.msg("����дվ�����ƣ�", {
                        icon:2
                });
                $("in_name").focus();
                return;
        }
        var link = $("in_link").value;
        if (link == "") {
                layer.msg("����д���ӵ�ַ��", {
                        icon:2
                });
                $("in_link").focus();
                return;
        }
        var type = $("in_type").value;
        var cover = $("in_cover").value;
        var XMLHttpReq = getHttpObject();
        XMLHttpReq.open("GET", in_path + "source/plugin/link/ajax.php?name=" + escape(name) + "&link=" + escape(link) + "&type=" + type + "&cover=" + escape(cover), true);
        XMLHttpReq.onreadystatechange = function() {
                if (XMLHttpReq.readyState == 4) {
                        if (XMLHttpReq.status == 200) {
                                if (XMLHttpReq.responseText == "return_1") {
                                        layer.msg("ÿ���ύ������ܵ���30�룡", {
                                                icon:2
                                        });
                                } else if (XMLHttpReq.responseText == "return_2") {
                                        layer.msg("����ɹ�����ȴ�վ����ˣ�", {
                                                icon:1
                                        });
                                } else {
                                        layer.msg("�ڲ����ִ������Ժ����ԣ�", {
                                                icon:5
                                        });
                                }
                        } else {
                                layer.msg("ͨѶ�쳣�������������ã�", {
                                        icon:3
                                });
                        }
                }
        };
        XMLHttpReq.send(null);
}