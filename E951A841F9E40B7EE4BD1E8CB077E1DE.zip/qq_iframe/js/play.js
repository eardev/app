function player_index(obj, type) {
        var _num = "";
        var _fid = 0;
        var _li = parent.$("#jp-playlist-box li");
        if (_li.length > 0) {
                for (var i = 0; i < _li.length; i++) {
                        var _lid = _li[i].getAttribute("data-id");
                        _num += _lid + ",";
                        if (parent.$("#player_" + _lid).hasClass("play_current")) {
                                _fid = _lid;
                        }
                }
        }
        if (isNaN(obj)) {
                var mIdSrt = "";
                $("#" + obj + " :checkbox").each(function() {
                        if ($(this).attr("checked")) {
                                mIdSrt += $(this).val() + ",";
                        }
                });
                if (mIdSrt) {
                        var _ids = mIdSrt.substr(0, mIdSrt.length - 1);
                        var _nid = _ids.split(",");
                        var _did = _num + _ids;
                        parent.$("#divnulllist").hide();
                        parent.get_player(_did, _fid);
                        player_join(_did);
                        var title = parent.$("#btnfold").attr("title");
                        if (title == "点击展开") {
                                parent.$("#divplayer").addClass("m_player_playing");
                        }
                        parent.$("#spanaddtips").show();
                        for (i = 1; i <= 30; i++) {
                                setTimeout('parent.$("#spanaddtips").css("top", "' + -i + 'px");', i * 30);
                                if (i > 29) {
                                        setTimeout('parent.$("#spanaddtips").hide();', 1500);
                                }
                        }
                        if (type == "ing") {
                                if (isNaN(_ids)) {
                                        parent.player_data(_nid[0]);
                                } else {
                                        parent.player_data(_ids);
                                }
                        }
                } else {
                        var _text = type == "add" ? "添加" :"播放";
                        lib.t_ips("请选择要" + _text + "的歌曲！", 0, 3e3);
                }
        } else {
                var _did = _num + obj;
                parent.$("#divnulllist").hide();
                parent.get_player(_did, _fid);
                player_join(_did);
                var title = parent.$("#btnfold").attr("title");
                if (title == "点击展开") {
                        parent.$("#divplayer").addClass("m_player_playing");
                }
                parent.$("#spanaddtips").show();
                for (i = 1; i <= 30; i++) {
                        setTimeout('parent.$("#spanaddtips").css("top", "' + -i + 'px");', i * 30);
                        if (i > 29) {
                                setTimeout('parent.$("#spanaddtips").hide();', 1500);
                        }
                }
                if (type == "ing") {
                        parent.player_data(obj);
                }
        }
}
function player_join(str) {
        var s = str.split(",");
        var dic = {};
        for (var i = s.length; i--; ) {
                dic[s[i]] = s[i];
        }
        var r = [];
        for (var v in dic) {
                r.push(dic[v]);
        }
        var n = r.join().split(",");
        parent.$("#spansongnums").html(n.length);
}