function plugin_link() {
        var name = $("in_name").value;
        if (name == "") {
                layer.msg("请填写站点名称！", {
                        icon:2
                });
                $("in_name").focus();
                return;
        }
        var link = $("in_link").value;
        if (link == "") {
                layer.msg("请填写链接地址！", {
                        icon:2
                });
                $("in_link").focus();
                return;
        }
        var type = $("in_type").value;
        var cover = $("in_cover").value;
        var XMLHttpReq = getHttpObject();
        XMLHttpReq.open("GET", in_path + "source/plugin/link/ajax.php?name=" + escape(name) + "&link=" + escape(link) + "&type=" + type + "&cover=" + escape(cover), true);
        XMLHttpReq.onreadystatechange = function() {
                if (XMLHttpReq.readyState == 4) {
                        if (XMLHttpReq.status == 200) {
                                if (XMLHttpReq.responseText == "return_1") {
                                        layer.msg("每次提交间隔不能低于30秒！", {
                                                icon:2
                                        });
                                } else if (XMLHttpReq.responseText == "return_2") {
                                        layer.msg("申请成功，请等待站长审核！", {
                                                icon:1
                                        });
                                } else {
                                        layer.msg("内部出现错误，请稍后再试！", {
                                                icon:5
                                        });
                                }
                        } else {
                                layer.msg("通讯异常，请检查网络设置！", {
                                        icon:3
                                });
                        }
                }
        };
        XMLHttpReq.send(null);
}