<?php
if(!defined('IN_ROOT')){exit('Access denied');}
include 'source/plugin/link/config.php';
?>
<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=<?php echo IN_CHARSET; ?>" />
<meta http-equiv="x-ua-compatible" content="ie=7" />
<title>友链申请 - <?php echo IN_NAME; ?></title>
<meta name="Keywords" content="<?php echo IN_KEYWORDS; ?>" />
<meta name="Description" content="<?php echo IN_DESCRIPTION; ?>" />
<link href="<?php echo IN_PATH; ?>static/pack/asynctips/asynctips.css" rel="stylesheet" type="text/css" />
<script type="text/javascript" src="<?php echo IN_PATH; ?>static/pack/asynctips/jquery.min.js"></script>
<script type="text/javascript" src="<?php echo IN_PATH; ?>static/pack/asynctips/asyncbox.v1.4.5.js"></script>
<script type="text/javascript" src="<?php echo IN_PATH; ?>static/pack/layer/jquery.js"></script>
<script type="text/javascript" src="<?php echo IN_PATH; ?>static/pack/layer/lib.js"></script>
<script type="text/javascript" src="<?php echo IN_PATH; ?>static/user/js/lib.js"></script>
<script type="text/javascript" src="<?php echo IN_PATH; ?>source/plugin/link/lib.js"></script>
<script type="text/javascript">
function $(obj) {return document.getElementById(obj);}
var in_path = '<?php echo IN_PATH; ?>';
var guide_url = '<?php echo rewrite_mode('user.php/people/home/'); ?>';
var pop = {
	up: function(scrolling, text, url, width, height, top) {
		layer.open({
			type: 2,
			maxmin: true,
			title: text,
			content: [url, scrolling],
			area: [width, height],
			offset: top,
			shade: false
		});
	}
}
function qzone_return(type){
        layer.closeAll();
        if(type==1){
            uc_syn('login');
            location.href = guide_url;
        }else{
            location.href = '<?php echo rewrite_mode('user.php/people/connect/'); ?>';
        }
}
function update_seccode(){
	$('img_seccode').src = '<?php echo rewrite_mode('user.php/people/seccode/\' + Math.random() + \'/'); ?>';
}
function exchange_type(theForm){
	if (theForm.in_type.value =='2'){
		layer.tips('请填写链接图片！', '#in_cover', {
			tips: [3, '#3595CC'],
			time: 3000
		});
		theForm.in_cover.focus();
		return false;
	}
}
</script>
<style type="text/css">
@import url(<?php echo IN_PATH; ?>static/user/css/style.css);
</style>
</head>
<body>
<?php include 'source/user/people/top.php'; ?>
<div id="main">
<?php include 'source/user/people/left.php'; ?>
<div id="mainarea">
<h2 class="title"><img src="<?php echo IN_PATH; ?>source/plugin/link/icon.jpg">友链申请</h2>
<form method="get" name="form" onsubmit="plugin_link();return false;" class="c_form">
<table cellspacing="0" cellpadding="0" class="formtable"><caption><h2>友情链接自助申请</h2></caption>
<?php if(in_plugin_link_open == 0){ ?>
<tr><td style="font-weight:bold;color:red;">抱歉，该插件暂未开放！</td></tr>
<?php }else{ ?>
<tr><th style="width:10em;">站点名称:</th><td><input type="text" id="in_name" class="t_input" size="20" /></td></tr>
<tr><th style="width:10em;">链接地址:</th><td><input type="text" id="in_link" class="t_input" size="30" /></td></tr>
<tr><th style="width:10em;">链接类型:</th><td>
<select id="in_type" onchange="exchange_type(this.form);">
<option value="1">文字</option>
<option value="2">图片</option>
</select>
</td></tr>
<tr><th style="width:10em;">链接图片:</th><td>
<input type="text" id="in_cover" class="t_input" size="45" />
<input type="button" class="button" value="上传图片" onclick="pop.up('no', '上传图片', in_path+'source/pack/upload/open.php?mode=1&type=link_cover&form=form.in_cover', '406px', '180px', '225px');" />
</td></tr>
<tr><th style="width:10em;"></th><td><input type="submit" value="提交" class="submit" /></td></tr>
<?php } ?>
</table>
</form>
</div>
<div id="bottom"></div>
</div>
<?php include 'source/user/people/bottom.php'; ?>
</body>
</html>