<?php
if(!defined('IN_ROOT')){exit('Access denied');}
include 'source/admincp/include/function.php';
Administrator(1);
ini_set('memory_limit', '-1');
$setup=SafeRequest("setup","get");
?>
<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=<?php echo IN_CHARSET; ?>" />
<meta http-equiv="x-ua-compatible" content="ie=7" />
<title>QQ���ֲɼ�[����]</title>
<link href="<?php echo IN_PATH; ?>static/admincp/css/main.css" rel="stylesheet" type="text/css" />
<link href="<?php echo IN_PATH; ?>static/pack/asynctips/asynctips.css" rel="stylesheet" type="text/css" />
<script type="text/javascript" src="<?php echo IN_PATH; ?>static/pack/asynctips/jquery.min.js"></script>
<script type="text/javascript" src="<?php echo IN_PATH; ?>static/pack/asynctips/asyncbox.v1.4.5.js"></script>
<script type="text/javascript" src="<?php echo IN_PATH; ?>static/pack/layer/jquery.js"></script>
<script type="text/javascript" src="<?php echo IN_PATH; ?>static/pack/layer/lib.js"></script>
<script type="text/javascript">
var pop = {
	up: function(scrolling, text, url, width, height, top) {
		layer.open({
			type: 2,
			maxmin: true,
			title: text,
			content: [url, scrolling],
			area: [width, height],
			offset: top,
			shade: false
		});
	}
}
function is_urlget(url){
	if(url.match(/^(https?:\/\/y\.qq\.com\/n\/yqq\/song\/)+(([a-zA-Z0-9])+\.html)+$/)){
	        return true;
	}
	return false;
}
function CheckForm(){
        if(document.form.in_uname.value==""){
            asyncbox.tips("������Ա����Ϊ�գ�����д��", "wait", 1000);
            document.form.in_uname.focus();
            return false;
        }
        else if(document.form.urlget.value==""){
            asyncbox.tips("������ַ����Ϊ�գ�����д��", "wait", 1000);
            document.form.urlget.focus();
            return false;
        }
        else if(is_urlget(document.form.urlget.value)==false){
            asyncbox.tips("������ַ���淶����������д��", "error", 1000);
            document.form.urlget.focus();
            return false;
        }
        else {
            $("#urlget").val($("#urlget").val().replace(/https/, 'http'));
            return true;
        }
}
var fsize = 0;
var _fsize = 0;
function set_size(filesize, _filesize){
        fsize = filesize;
        _fsize = _filesize;
}
function caiji_local(dlen, status, _dlen){
        if(fsize > 0){
                var _status = status == 1 ? "�ɼ����" : "�ظ�����";
                var percent = Math.round(dlen * 100 / fsize);
                document.getElementById("progressbar").style.width = percent + "%";
                if(percent > 0){
                        document.getElementById("progressbar").innerHTML = _dlen + "/" + _fsize + "[" + _status + "]";
                        document.getElementById("progressText").innerHTML = "";
                }else{
                        document.getElementById("progressText").innerHTML = percent + "%";
                }
                if(percent > 99){
                        document.getElementById("progressbar").innerHTML = "�ɼ���ϣ����Ե�...";
                        setTimeout("location.href='<?php echo $_SERVER['PHP_SELF']; ?>';", 1000);
                }
        }
}
function caiji_remote(status){
        var _status = status == 1 ? "[�ɼ����]" : "[�ظ�����]";
        document.getElementById("progressbar").style.width = "100%";
        document.getElementById("progressbar").innerHTML = "100%" + _status;
        document.getElementById("progressText").innerHTML = "";
        setTimeout("location.href='<?php echo $_SERVER['PHP_SELF']; ?>';", 1000);
}
</script>
</head>
<body>
<div class="container">
<script type="text/javascript">parent.document.title = 'Ear Music Board �������� - QQ���ֲɼ�[����]';if(parent.$('admincpnav')) parent.$('admincpnav').innerHTML='QQ���ֲɼ�[����]';</script>
<div class="floattop"><div class="itemtitle"><h3>QQ���ֲɼ�[����]</h3></div></div><div class="floattopempty"></div>
<?php
switch($setup){
	case 'ing':
		caiji_opening();
		break;
	default:
		caiji_open();
		break;
	}
?>
</div>
</body>
</html>
<?php function caiji_open(){
global $db;
$one = $db->getone("select in_userid from ".tname('user')." where in_username='".$_COOKIE['in_adminname']."'");
$in_uname = $one ? $_COOKIE['in_adminname'] : NULL;
?>
<form action="<?php echo $_SERVER['PHP_SELF']; ?>?setup=ing" method="post" name="form">
<table class="tb tb2">
<tr>
<td>�������֣�<select name="in_singerid" id="in_singerid">
<option value="0">��ѡ��</option>
<?php
$res=$db->query("select * from ".tname('singer')." order by in_addtime desc");
if($res){
        while ($row = $db->fetch_array($res)){
                echo "<option value=\"".$row['in_id']."\">".getlenth($row['in_name'], 10)."</option>";
        }
}
?>
</select>&nbsp;&nbsp;<a href="javascript:void(0)" onclick="pop.up('yes', 'ѡ�����', '<?php echo IN_PATH; ?>source/pack/tag/singer_opt.php?so=form.in_singerid', '500px', '400px', '65px');" class="addtr">ѡ��</a></td>
<td>������Ŀ��<select name="in_classid" id="in_classid">
<?php
$res=$db->query("select * from ".tname('class')." order by in_id asc");
if($res){
        while ($row = $db->fetch_array($res)){
                echo "<option value=\"".$row['in_id']."\">".$row['in_name']."</option>";
        }
}
?>
</select></td>
</tr>
<tr>
<td>����ר����<select name="in_specialid" id="in_specialid">
<option value="0">��ѡ��</option>
<?php
$res=$db->query("select * from ".tname('special')." order by in_addtime desc");
if($res){
        while ($row = $db->fetch_array($res)){
                echo "<option value=\"".$row['in_id']."\">".getlenth($row['in_name'], 10)."</option>";
        }
}
?>
</select>&nbsp;&nbsp;<a href="javascript:void(0)" onclick="pop.up('yes', 'ѡ��ר��', '<?php echo IN_PATH; ?>source/pack/tag/special_opt.php?so=form.in_specialid', '500px', '400px', '65px');" class="addtr">ѡ��</a></td>
<td>������Ա��<input type="text" class="txt" value="<?php echo $in_uname; ?>" name="in_uname" id="in_uname"></td>
</tr>
<tr><td class="longtxt lightnum">������ַ��<input type="text" class="txt" name="urlget" id="urlget"><input class="checkbox" type="checkbox" name="remote" id="remote" value="1"><label for="remote">����</label></td></tr>
</table>
<table class="tb tb2">
<tr><td><input type="submit" class="btn" value="�ύ" onclick="return CheckForm();" /></td></tr>
</table>
</form>
<?php } function caiji_opening(){
        global $db;
        $uname = SafeRequest("in_uname","post");
        if($one = $db->getone("select in_userid from ".tname('user')." where in_username='".$uname."'")){
                $uid = $one;
                $singerid = SafeRequest("in_singerid","post");
                $classid = SafeRequest("in_classid","post");
                $specialid = SafeRequest("in_specialid","post");
                $remote = SafeRequest("remote","post");
        }else{
                exit("<h3>Ear Music ��ʾ</h3><div class=\"infobox\"><br /><h4 class=\"marginbot normal\" style=\"color:#C00\">������Ա�����ڣ���������д��</h4><br /><p class=\"margintop\"><input type=\"button\" class=\"btn\" value=\"���ڷ���...\" disabled=\"disabled\"></p><br /></div></div><script type=\"text/javascript\">setTimeout(\"location.href='".$_SERVER['PHP_SELF']."';\", 3000);</script></body></html>");
        }
        echo "<h3>Ear Music ��ʾ</h3><div class=\"infobox\"><br />";
        echo "<table class=\"tb tb2\" style=\"border:1px solid #09C\">";
        echo "<tr><td><div id=\"progressbar\" style=\"float:left;width:1px;text-align:center;color:#FFFFFF;background-color:#09C\"></div><div id=\"progressText\" style=\"float:left\">0%</div></td></tr>";
        echo "</table>";
        echo "<br /><p class=\"margintop\"><input type=\"button\" class=\"btn\" value=\"����\" onclick=\"history.go(-1);\"></p><br /></div>";
        ob_start();
        @set_time_limit(0);
        $url = @file_get_contents(SafeRequest("urlget","post"));
        $url = IN_CHARSET == 'gbk' ? iconv('UTF-8', 'GBK//IGNORE', $url) : $url;
        preg_match('/var g_SongData = \{"songurl":"","songid":(\d+),"songmid":"(.*?)","songtype":(\d+),"songname":"(.*?)","songtitle"([\s\S]+?)<span class="data__cover">(\s+)<img src="(.*?)" onerror=/', $url, $arr);
        if(!empty($arr)){
		$lyric = 'http://lyric.music.qq.com/fcgi-bin/fcg_query_lyric.fcg?nobase64=1&musicid='.$arr[1];
		$option = array('http' => array('header' => 'Referer:http://y.qq.com/'));
		$ltext = @file_get_contents($lyric, false, stream_context_create($option));
		$ltext = IN_CHARSET == 'gbk' ? iconv('UTF-8', 'GBK//IGNORE', $ltext) : $ltext;
		$ltext = preg_replace_callback('/MusicJsonCallback\(\{(.*?)"lyric":"(.*?)"\}\)/', array(new callback('return $match[2];'), 'matches'), $ltext);
		$lrc = html_entity_decode(str_replace("&#10;", "\r\n", $ltext), ENT_COMPAT, set_chars());
		$w_ord = trim(preg_replace('/\[(.*?)\]/', '', $lrc));
		$n_ame = $arr[4];
                if(!$remote){
                        $a_udio = 'data/attachment/music/audio/qqmusic_'.$arr[2].'.m4a';
                        $c_over = 'data/attachment/music/cover/qqmusic_'.$arr[2].'.jpg';
                        $l_yric = 'data/attachment/music/lyric/qqmusic_'.$arr[2].'.lrc';
                        $adown = 'http://ws.stream.qqmusic.qq.com/C100'.$arr[2].'.m4a?fromtag=38';
                        $cdown = 'http:'.$arr[7];
                }else{
                        $a_udio = 'plugin.php/qqmusic-caiji/proxy/audio/'.$arr[2].'.m4a';
                        $c_over = 'plugin.php/qqmusic-caiji/proxy/cover/'.preg_replace('/\?([\S]+)/', '', substr(strrchr($arr[7], '/'), 1));
                        $l_yric = 'plugin.php/qqmusic-caiji/proxy/lyric/'.$arr[1].'.lrc';
                }
                if($one = $db->getone("select in_id from ".tname('music')." where in_audio='".$a_udio."'")){
                        $status = 0;
                        updatetable('music', array('in_name' => $n_ame,'in_classid' => $classid,'in_specialid' => $specialid,'in_singerid' => $singerid,'in_uid' => $uid,'in_uname' => $uname,'in_text' => $w_ord,'in_addtime' => date('Y-m-d H:i:s')), array('in_id' => $one));
                }else{
                        $status = 1;
                        inserttable('music', array('in_name' => $n_ame,'in_classid' => $classid,'in_specialid' => $specialid,'in_singerid' => $singerid,'in_uid' => $uid,'in_uname' => $uname,'in_audio' => $a_udio,'in_lyric' => $l_yric,'in_text' => $w_ord,'in_cover' => $c_over,'in_hits' => 0,'in_downhits' => 0,'in_favhits' => 0,'in_goodhits' => 0,'in_badhits' => 0,'in_points' => 0,'in_grade' => 3,'in_best' => 0,'in_passed' => 0,'in_wrong' => 0,'in_addtime' => date('Y-m-d H:i:s')), 1);
                }
                if(!$remote){
                        $file = fopen($adown, 'rb');
                        $newf = fopen($a_udio, 'wb');
                        $dlen = 0;
                        $headers = get_headers($adown, 1);
                        if(array_key_exists('Content-Length', $headers)){
                                $head = $headers['Content-Length'];
                                $fsize = is_array($head) ? empty($head[0]) ? $head[1] : $head[0] : $head;
                        }else{
                                $fsize = strlen(@file_get_contents($adown));
                        }
                        echo "<script type=\"text/javascript\">set_size($fsize, '".formatsize($fsize)."');</script>";
                        fwrite(fopen($c_over, 'wb'), @file_get_contents($cdown));
                        fwrite(fopen($l_yric, 'wb+'), $lrc);
                        while(!feof($file)){
                                $data = fread($file, 1024*8);
                                $dlen += strlen($data);
                                fwrite($newf, $data, 1024*8);
                                echo "<script type=\"text/javascript\">caiji_local($dlen, $status, '".formatsize($dlen)."');</script>";
                                ob_flush();
                                flush();
                        }
                        fclose($file);
                        fclose($newf);
                }else{
                        echo "<script type=\"text/javascript\">caiji_remote($status);</script>";
                }
        }
}
?>